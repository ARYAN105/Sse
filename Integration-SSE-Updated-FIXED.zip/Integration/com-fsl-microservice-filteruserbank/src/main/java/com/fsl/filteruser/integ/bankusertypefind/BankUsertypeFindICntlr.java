package com.fsl.filteruser.integ.bankusertypefind;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsl.fwk.controller.FSLBaseRestController;
import com.tcs.fwk.service.MWRestController;
import com.tcs.fwk.service.MWService;

@RestController
@RequestMapping("bank-usertype-find")
public class BankUsertypeFindICntlr extends MWRestController{

	@Autowired
	BankUsertypeFindISvc bankUsertypeFindISvc;
	
	@Override
	public MWService myMWService() {
		return bankUsertypeFindISvc;
	}
	
}
