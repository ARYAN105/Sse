package com.fsl.filteruser.integ.bankusertypefind;

import com.fsl.fwk.controller.model.FSLRequestBody;
import com.tcs.fwk.logger.masking.MaskRule;
import com.tcs.fwk.logger.masking.MaskSensitive;
import com.tcs.fwk.logger.masking.Sensitive;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;



@Data
@NoArgsConstructor
@AllArgsConstructor
@MaskSensitive
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankUsertypeFindIReqBody extends FSLRequestBody {
    private static final long serialVersionUID = "com.fsl.filteruser.integ.bankusertypefind.BankUsertypeFindIReqBody".hashCode();
    
    @Sensitive(rule = MaskRule.ALLMASK)
    @JsonProperty("userType")
    private String userType;
    
    @Sensitive(rule = MaskRule.EXCLUDEFIRST, param = "1")
    @JsonProperty("argentina")
    private String argentina;
    
    @Sensitive(rule = MaskRule.EXCLUDEOUTER, param = "10%")
    @JsonProperty("Goals")
    private Long goals;
    
    @Sensitive(rule = MaskRule.ALLMASK)
    @JsonProperty("WorldCups")
    private String worldCup;
    
    @Sensitive(rule = MaskRule.EXCLUDELAST, param = "1")
    @JsonProperty("players")
    private Integer players;
    
    @Sensitive(rule = MaskRule.EXCLUDEFIRST, param = "2")
    @JsonProperty("GOAT")
    private String GOAT;
    
    @Sensitive(rule = MaskRule.REGEX, param = "^(.{3})(.*)(.{2})$|2")
    @JsonProperty("Stats")
    private String stats;
    
    @Sensitive(rule = MaskRule.ALLMASK)
    @JsonProperty("WillWinTheWC")
    private Boolean willWinTheWC;
}
