package com.fsl.outbound.filteruser.bankusertypefindpost;

import com.tcs.fwk.logger.masking.MaskRule;
import com.tcs.fwk.logger.masking.MaskSensitive;
import com.tcs.fwk.logger.masking.Sensitive;
import com.tcs.fwk.model.BaseModel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonProperty;



@Data
@NoArgsConstructor
@AllArgsConstructor
@MaskSensitive
public class UserObject extends BaseModel {
    private static final long serialVersionUID = "com.fsl.outbound.filteruser.bankusertypefindpost.UserObject".hashCode();
    @Sensitive(rule = MaskRule.EXCLUDEOUTER, param = "1")
    @JsonProperty("id")
    private Integer id;
    
    @Sensitive(rule = MaskRule.EXCLUDEOUTER, param = "1")
    @JsonProperty("name")
    private String name;
    
    @Sensitive(rule = MaskRule.EXCLUDEOUTER, param = "1")
    @JsonProperty("userType")
    private String userType;
    
    @JsonProperty("accountNumber")
    private Long accountNumber;
    
}
