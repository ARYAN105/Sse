package com.fsl.outbound.filteruser.bankusertypefindpost;

import java.util.ArrayList;
import java.util.List;

import com.tcs.fwk.logger.masking.MaskRule;
import com.tcs.fwk.logger.masking.MaskSensitive;
import com.tcs.fwk.logger.masking.Sensitive;
import com.tcs.fwk.model.BaseModel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;



@Data
@NoArgsConstructor
@AllArgsConstructor
@MaskSensitive
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankUsertypeFindIOutput extends BaseModel {
    private static final long serialVersionUID = "com.fsl.outbound.filteruser.bankusertypefindpost.BankUsertypeFindIOutput".hashCode();
    @JsonProperty("userObject")
    private List<UserObject> userObject;
    
    @Sensitive(rule = MaskRule.EXCLUDEFIRST, param = "1")
    @JsonProperty("argentina")
    private String argentina;
    
    @Sensitive(rule = MaskRule.EXCLUDEOUTER, param = "10%")
    @JsonProperty("Goals")
    private Long goals;
    
    @Sensitive(rule = MaskRule.REGEX, param = "^(.{4})(.{2})(.{2})(.+)$|1,3")   //^(.{4})(.{2})(.{2})(.+)$|1,3,   (.{3})(.*)(@.*)$|2
    @JsonProperty("WorldCups")
    private String worldCup;
    
    @Sensitive(rule = MaskRule.EXCLUDELAST, param = "1")
    @JsonProperty("players")
    private Integer players;
    
    @Sensitive(rule = MaskRule.EXCLUDEFIRST, param = "2")
    @JsonProperty("GOAT")
    private String GOAT;
    
    //@Sensitive(rule = MaskRule.ALLMASK)
    @JsonProperty("Stats")
    private String stats;
    
    @Sensitive(rule = MaskRule.ALLMASK)
    @JsonProperty("WillWinTheWC")
    private Boolean willWinTheWC;
    
}
