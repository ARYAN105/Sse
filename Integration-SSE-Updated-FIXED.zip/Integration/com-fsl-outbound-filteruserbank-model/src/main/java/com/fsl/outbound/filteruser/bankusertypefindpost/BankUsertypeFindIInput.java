package com.fsl.outbound.filteruser.bankusertypefindpost;

import com.tcs.fwk.logger.masking.MaskSensitive;
import com.tcs.fwk.model.BaseModel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonProperty;



@Data
@NoArgsConstructor
@AllArgsConstructor
@MaskSensitive
public class BankUsertypeFindIInput extends BaseModel {
    private static final long serialVersionUID = "com.fsl.outbound.filteruser.bankusertypefindpost.BankUsertypeFindIInput".hashCode();
    @JsonProperty("userType")
    private String userType;
    
}
