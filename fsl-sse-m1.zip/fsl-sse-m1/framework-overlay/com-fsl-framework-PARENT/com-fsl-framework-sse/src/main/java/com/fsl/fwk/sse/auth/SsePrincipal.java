package com.fsl.fwk.sse.auth;

/** Identity established by the FSL authentication adapter, not by request parameters. */
public record SsePrincipal(String userId, String sessionId, String channelId, String deviceId) {
    public SsePrincipal {
        if (userId == null || userId.isBlank()) {
            throw new IllegalArgumentException("Authenticated userId is required");
        }
        userId = userId.trim();
        sessionId = normalize(sessionId);
        channelId = normalize(channelId);
        deviceId = normalize(deviceId);
    }

    private static String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
