package com.fsl.fwk.sse.auth;

import jakarta.servlet.http.HttpServletRequest;

/** Authorizes backend microservices that publish events into the SSE service. */
public interface SsePublisherAuthenticator {
    void authorize(HttpServletRequest request);
}
