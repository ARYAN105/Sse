package com.fsl.fwk.sse.model;

/** Counts server-side emitter writes; it is not an acknowledgement from the browser. */
public record SsePublishResult(
        String eventId,
        int matchingConnections,
        int writeSuccessCount,
        int writeFailureCount) {
}
