package com.fsl.fwk.sse.core;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.fsl.fwk.sse.auth.SsePrincipal;
import com.fsl.fwk.sse.model.SseEventEnvelope;
import com.fsl.fwk.sse.model.SsePublishRequest;
import com.fsl.fwk.sse.model.SsePublishResult;
import com.fsl.fwk.sse.model.SseTarget;
import com.fsl.fwk.sse.model.SseTargetType;


/** In-memory connection registry for one SSE service instance. */
public class SseConnectionManager {
    private final FslSseProperties properties;
    private final Object registryLock = new Object();
    private final ConcurrentMap<String, Connection> byConnectionId = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, Set<String>> connectionIdsByUser = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, Set<String>> connectionIdsBySession = new ConcurrentHashMap<>();

    public SseConnectionManager(FslSseProperties properties) {
        this.properties = properties;
        this.properties.validate();
    }

    public SseEmitter openConnection(SsePrincipal principal) {
        if (principal == null) throw new IllegalArgumentException("Authenticated principal is required");
        String connectionId = UUID.randomUUID().toString();
        long timeoutMs = properties.getConnectionTimeout().toMillis();
        SseEmitter emitter = new SseEmitter(timeoutMs);
        Connection connection = new Connection(connectionId, principal, emitter, Instant.now());

        emitter.onCompletion(() -> removeConnection(connectionId));
        emitter.onTimeout(() -> removeConnection(connectionId));
        emitter.onError(error -> removeConnection(connectionId));

        synchronized (registryLock) {
            if (byConnectionId.size() >= properties.getMaxConnections()) {
                throw new SseConnectionLimitException("SSE service instance has reached its connection limit");
            }
            Set<String> userConnections = connectionIdsByUser.computeIfAbsent(
                    principal.userId(), ignored -> ConcurrentHashMap.newKeySet());
            if (userConnections.size() >= properties.getMaxConnectionsPerUser()) {
                if (userConnections.isEmpty()) connectionIdsByUser.remove(principal.userId(), userConnections);
                throw new SseConnectionLimitException("User has reached the maximum number of SSE connections");
            }
            byConnectionId.put(connectionId, connection);
            userConnections.add(connectionId);
            if (principal.sessionId() != null) {
                connectionIdsBySession.computeIfAbsent(
                        principal.sessionId(), ignored -> ConcurrentHashMap.newKeySet()).add(connectionId);
            }
        }

        try {
            emitter.send(SseEmitter.event().id(connectionId).name("connected")
                    .data(Map.of("status", "CONNECTED", "connectionId", connectionId)));
        } catch (IOException | IllegalStateException exception) {
            removeConnection(connectionId);
            emitter.completeWithError(exception);
            throw new IllegalStateException("Unable to initialize SSE connection", exception);
        }
        return emitter;
    }

    public SsePublishResult publish(SsePublishRequest request) {
        if (request == null) throw new IllegalArgumentException("Request body is required");
        request.validate();
        String eventId = request.eventId() == null || request.eventId().isBlank()
                ? UUID.randomUUID().toString() : request.eventId();
        Instant occurredAt = request.occurredAt() == null ? Instant.now() : request.occurredAt();
        SseEventEnvelope envelope = new SseEventEnvelope(eventId, request.eventType(),
                request.sourceService(), request.correlationId(), occurredAt, request.payload());

        List<Connection> targets = resolveTargets(request.target());
        int sent = 0;
        int failed = 0;
        for (Connection connection : targets) {
            try {
                connection.emitter().send(SseEmitter.event()
                        .id(eventId)
                        .name(request.eventType())
                        .data(envelope));
                sent++;
            } catch (IOException | IllegalStateException exception) {
                failed++;
                removeConnection(connection.connectionId());
                connection.emitter().completeWithError(exception);
            }
        }
        return new SsePublishResult(eventId, targets.size(), sent, failed);
    }

    private List<Connection> resolveTargets(SseTarget target) {
        return switch (target.type()) {
            case USER -> connectionsForIds(connectionIdsByUser.get(target.userId()));
            case SESSION -> connectionsForIds(connectionIdsBySession.get(target.sessionId()));
            case CONNECTION -> {
                Connection found = byConnectionId.get(target.connectionId());
                yield found == null ? List.of() : List.of(found);
            }
        };
    }

    private List<Connection> connectionsForIds(Set<String> ids) {
        if (ids == null || ids.isEmpty()) return List.of();
        List<Connection> result = new ArrayList<>(ids.size());
        for (String id : ids) {
            Connection connection = byConnectionId.get(id);
            if (connection != null) result.add(connection);
        }
        return result;
    }

    @Scheduled(fixedDelayString = "${fsl.sse.heartbeat-interval:15s}")
    public void sendHeartbeats() {
        for (Connection connection : byConnectionId.values()) {
            try {
                connection.emitter().send(SseEmitter.event().comment("heartbeat"));
            } catch (IOException | IllegalStateException exception) {
                removeConnection(connection.connectionId());
                connection.emitter().completeWithError(exception);
            }
        }
    }

    public int activeConnectionCount() {
        return byConnectionId.size();
    }

    public int activeConnectionCountForUser(String userId) {
        Set<String> ids = connectionIdsByUser.get(userId);
        return ids == null ? 0 : ids.size();
    }

    public void closeConnection(String connectionId) {
        Connection connection = removeConnection(connectionId);
        if (connection != null) connection.emitter().complete();
    }

    private Connection removeConnection(String connectionId) {
        synchronized (registryLock) {
            Connection removed = byConnectionId.remove(connectionId);
            if (removed == null) return null;
            removeIndex(connectionIdsByUser, removed.principal().userId(), connectionId);
            if (removed.principal().sessionId() != null) {
                removeIndex(connectionIdsBySession, removed.principal().sessionId(), connectionId);
            }
            return removed;
        }
    }

    private static void removeIndex(ConcurrentMap<String, Set<String>> index, String key, String connectionId) {
        if (key == null) return;
        Set<String> ids = index.get(key);
        if (ids == null) return;
        ids.remove(connectionId);
        if (ids.isEmpty()) index.remove(key, ids);
    }

    public void closeAllConnections() {
        List<Connection> snapshot = new ArrayList<>(byConnectionId.values());
        for (Connection connection : snapshot) closeConnection(connection.connectionId());
    }

    private record Connection(String connectionId, SsePrincipal principal,
                              SseEmitter emitter, Instant connectedAt) { }
}
