package com.fsl.fwk.sse.core;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "fsl.sse")
public class FslSseProperties {
    /** Maximum simultaneous connections on this SSE service instance. */
    private int maxConnections = 5000;
    /** Maximum simultaneous connections registered for one user on this instance. */
    private int maxConnectionsPerUser = 5;
    /** Heartbeat interval. Keep below the shortest idle timeout in the network path. */
    private Duration heartbeatInterval = Duration.ofSeconds(15);
    /** Zero means no Spring MVC emitter timeout; proxies still require heartbeat/timeout configuration. */
    private Duration connectionTimeout = Duration.ZERO;
    private String streamPath = "/fsl/sse/stream";
    private String publishPath = "/internal/fsl/sse/events";

    public int getMaxConnections() { return maxConnections; }
    public void setMaxConnections(int maxConnections) { this.maxConnections = maxConnections; }
    public int getMaxConnectionsPerUser() { return maxConnectionsPerUser; }
    public void setMaxConnectionsPerUser(int maxConnectionsPerUser) { this.maxConnectionsPerUser = maxConnectionsPerUser; }
    public Duration getHeartbeatInterval() { return heartbeatInterval; }
    public void setHeartbeatInterval(Duration heartbeatInterval) { this.heartbeatInterval = heartbeatInterval; }
    public Duration getConnectionTimeout() { return connectionTimeout; }
    public void setConnectionTimeout(Duration connectionTimeout) { this.connectionTimeout = connectionTimeout; }
    public String getStreamPath() { return streamPath; }
    public void setStreamPath(String streamPath) { this.streamPath = streamPath; }
    public String getPublishPath() { return publishPath; }
    public void setPublishPath(String publishPath) { this.publishPath = publishPath; }

    public void validate() {
        if (maxConnections < 1) throw new IllegalArgumentException("fsl.sse.max-connections must be >= 1");
        if (maxConnectionsPerUser < 1) throw new IllegalArgumentException("fsl.sse.max-connections-per-user must be >= 1");
        if (heartbeatInterval == null || heartbeatInterval.isZero() || heartbeatInterval.isNegative()) {
            throw new IllegalArgumentException("fsl.sse.heartbeat-interval must be positive");
        }
        if (connectionTimeout == null || connectionTimeout.isNegative()) {
            throw new IllegalArgumentException("fsl.sse.connection-timeout must be zero or positive");
        }
        if (streamPath == null || !streamPath.startsWith("/")) throw new IllegalArgumentException("fsl.sse.stream-path must start with '/'");
        if (publishPath == null || !publishPath.startsWith("/")) throw new IllegalArgumentException("fsl.sse.publish-path must start with '/'");
        if (streamPath.equals(publishPath)) throw new IllegalArgumentException("SSE stream and publish paths must be different");
    }
}
