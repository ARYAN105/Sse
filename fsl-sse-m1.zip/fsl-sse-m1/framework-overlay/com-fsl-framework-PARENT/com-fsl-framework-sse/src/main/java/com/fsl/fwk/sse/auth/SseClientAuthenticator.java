package com.fsl.fwk.sse.auth;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Resolves the authenticated FSL user/session for a new SSE connection.
 * Implementations must derive identity from validated credentials or trusted
 * gateway context. Never trust a userId supplied as a query parameter.
 */
public interface SseClientAuthenticator {
    SsePrincipal authenticate(HttpServletRequest request);
}
