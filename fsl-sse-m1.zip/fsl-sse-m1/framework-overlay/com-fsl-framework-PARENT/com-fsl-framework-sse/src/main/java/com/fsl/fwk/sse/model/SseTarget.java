package com.fsl.fwk.sse.model;

/** Exactly one target selector is used according to type. */
public record SseTarget(SseTargetType type, String userId, String sessionId, String connectionId) {
    public void validate() {
        if (type == null) {
            throw new IllegalArgumentException("target.type is required");
        }
        String value = switch (type) {
            case USER -> userId;
            case SESSION -> sessionId;
            case CONNECTION -> connectionId;
        };
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Target identifier is required for " + type);
        }
        if ((type != SseTargetType.USER && userId != null)
                || (type != SseTargetType.SESSION && sessionId != null)
                || (type != SseTargetType.CONNECTION && connectionId != null)) {
            throw new IllegalArgumentException("Only the identifier matching target.type may be supplied");
        }
    }
}
