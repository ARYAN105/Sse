package com.fsl.fwk.sse.model;

public enum SseTargetType {
    USER,
    SESSION,
    CONNECTION
}
