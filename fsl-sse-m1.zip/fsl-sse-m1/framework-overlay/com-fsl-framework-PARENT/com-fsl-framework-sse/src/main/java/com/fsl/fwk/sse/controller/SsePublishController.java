package com.fsl.fwk.sse.controller;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fsl.fwk.sse.auth.SsePublisherAuthenticator;
import com.fsl.fwk.sse.core.SseConnectionManager;
import com.fsl.fwk.sse.model.SsePublishRequest;
import com.fsl.fwk.sse.model.SsePublishResult;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@ConditionalOnProperty(prefix = "fsl.sse", name = "enabled", havingValue = "true")
public class SsePublishController {
    private final SsePublisherAuthenticator authenticator;
    private final SseConnectionManager connectionManager;

    public SsePublishController(SsePublisherAuthenticator authenticator,
                                SseConnectionManager connectionManager) {
        this.authenticator = authenticator;
        this.connectionManager = connectionManager;
    }

    @PostMapping(path = "${fsl.sse.publish-path:/internal/fsl/sse/events}", consumes = "application/json", produces = "application/json")
    public ResponseEntity<?> publish(@RequestBody SsePublishRequest request,
                                                    HttpServletRequest servletRequest) {
        authenticator.authorize(servletRequest);
        try {
            return ResponseEntity.status(HttpStatus.ACCEPTED).body(connectionManager.publish(request));
        } catch (IllegalArgumentException exception) {
            return ResponseEntity.badRequest().body(Map.of("error", exception.getMessage()));
        }
    }
}
