package com.fsl.fwk.sse.model;

import java.time.Instant;

/** Data delivered to the browser for every generic SSE event. */
public record SseEventEnvelope(
        String eventId,
        String eventType,
        String sourceService,
        String correlationId,
        Instant occurredAt,
        Object payload) {
}
