package com.fsl.fwk.sse.core;

public class SseConnectionLimitException extends RuntimeException {
    public SseConnectionLimitException(String message) {
        super(message);
    }
}
