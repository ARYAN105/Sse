package com.fsl.fwk.sse.model;

import java.time.Instant;

/** Generic event contract. Business-specific payload stays opaque to the SSE framework. */
public record SsePublishRequest(
        String eventId,
        String eventType,
        String sourceService,
        String correlationId,
        Instant occurredAt,
        SseTarget target,
        Object payload) {

    public void validate() {
        if (eventType == null || !eventType.matches("[A-Za-z0-9_.-]{1,128}")) {
            throw new IllegalArgumentException("eventType must contain only letters, digits, dot, underscore or hyphen (max 128)");
        }
        if (eventId != null && !eventId.isBlank()
                && (eventId.length() > 256 || eventId.indexOf('\n') >= 0
                    || eventId.indexOf('\r') >= 0 || eventId.indexOf('\0') >= 0)) {
            throw new IllegalArgumentException("eventId must be at most 256 characters and contain no CR, LF or NUL");
        }
        if (sourceService == null || sourceService.isBlank() || sourceService.length() > 128
                || sourceService.indexOf('\n') >= 0 || sourceService.indexOf('\r') >= 0) {
            throw new IllegalArgumentException("sourceService is required");
        }
        if (target == null) {
            throw new IllegalArgumentException("target is required");
        }
        target.validate();
    }
}
