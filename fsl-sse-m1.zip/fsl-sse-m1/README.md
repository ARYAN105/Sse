# FSL SSE framework extension — Milestone 1 implementation baseline

## Scope and deployment model

This adds an optional FSL framework module named `com-fsl-framework-sse` for the FSL 0.0.9 / TCS 0.0.9 line. It is intended to be included in **one dedicated SSE Connection Service**. Business microservices (Login, UPI, CAR, Fraud, etc.) do not host their own SSE connection registries; they publish generic events to the Connection Service over the existing service-to-service integration path.

```text
Login / UPI / CAR / Fraud microservices
          |
          | existing FSL/TCS integration (HTTP/Feign)
          v
  Dedicated SSE Connection Service
          |
          | long-lived HTTP text/event-stream connections
          v
        UI clients
```

The module is business-neutral. It contains no DEH, UPI, Login, CAR or Fraud logic. The DEH concurrent-login callback should be integrated later as an event producer and should not be embedded in this module.

## Source analysis that drove this design

The supplied source archives show:

1. The FSL 0.0.9 parent is `com-fsl-framework-PARENT/pom-vt.xml`; the dependency parent is `com-fsl-framework-dependency-PARENT/pom-vt.xml`. FSL modules use separate `pom.xml`, `pom-new.xml` and `pom-vt.xml` tracks. This addition targets the 0.0.9 track only.
2. `FwkSpringStarter` scans `com.fsl.*` and `com.tcs.*`, so the `com.fsl.fwk.sse` package is in the standard scan path used by the supplied framework starter.
3. FSL `FSLRestController` extends `FSLBaseRestController`, which extends TCS `MWRestController`. In the supplied TCS source, `MWRestController` exposes a `@PostMapping` and returns the standard `MWResponse`; that standard endpoint is not an SSE streaming endpoint. The SSE GET therefore has its own Spring MVC controller and an explicit FSL authentication adapter.
4. FSL `FSLControllerHelper` has user/device/session security checks and checks the existing concurrent-session termination flag. Those checks are not blindly reused for a streaming GET: `SseClientAuthenticator` must derive identity from a validated gateway/session context. A client-supplied `userId` query parameter is never trusted.
5. FSL `RawJsonFilter` wraps the request to inspect/cache request JSON; it does not wrap the response. The TCS `MyFilter` is a component filter that wraps every response in `ContentCachingResponseWrapper` and calls `copyBodyToResponse()` after the chain. That response-copy pattern must be bypassed for the long-lived stream.
6. The supplied FSL source did not contain a reusable SSE controller, connection registry, `SecurityFilterChain`, `WebMvcConfigurer` or async streaming configuration that could simply be reused.

The implementation therefore provides an SSE-specific controller and manager, plus a filter registration intended to replace TCS `MyFilter` while preserving its allowed-hostname check and ordinary response-copy behaviour. This filter-registration replacement is a high-priority runtime verification item in the actual FSL application.

## Module contents

- `SseConnectionController`: authenticated GET endpoint returning `text/event-stream`.
- `SseConnectionManager`: in-memory registry and dispatch to user, session or connection targets.
- `SsePublishController`: service-to-service POST endpoint returning HTTP 202 after attempting local emitter writes.
- `SseClientAuthenticator`: host-application extension point for authenticating UI connections.
- `SsePublisherAuthenticator`: host-application extension point for authorizing producer microservices.
- `SsePrincipal`: trusted identity returned by the client authenticator.
- `SseAwareResponseCachingFilter`: skips response caching for the SSE stream while retaining the TCS hostname restriction and response caching for ordinary endpoints.

## Authentication integration required from the host service

When `fsl.sse.enabled=true`, the host application must provide **both** interfaces:

1. `SseClientAuthenticator`: validates the real UI/gateway credentials and derives `userId`, `sessionId`, `channelId` and `deviceId` from trusted context.
2. `SsePublisherAuthenticator`: authenticates/authorizes backend callers of the internal publish endpoint. It must not accept an ordinary end-user credential as sufficient producer authentication.

No permissive default implementation is supplied. Missing beans should fail startup rather than expose unauthenticated stream or publish endpoints.

This is not yet a complete drop-in authentication integration: the exact gateway headers/cookie/token handling must be wired and tested against the deployment's real RIB/iMobile path. Native browser `EventSource` cannot set arbitrary Authorization headers; if the existing UI flow requires a custom bearer header, use an approved secure cookie/gateway design or a fetch-based SSE client supported by the application.

## Configuration

```yaml
fsl:
  sse:
    enabled: true
    max-connections: 5000
    max-connections-per-user: 5
    heartbeat-interval: 15s
    connection-timeout: 0s
    stream-path: /fsl/sse/stream
    publish-path: /internal/fsl/sse/events
```

- `connection-timeout: 0s` configures no Spring MVC emitter timeout. It does not disable proxy, load-balancer or container timeouts.
- Tune the connection limits only after load testing the actual container and deployment resources.
- Heartbeats must be more frequent than the shortest idle timeout across gateway, ingress, load balancer and proxy.
- Disable response buffering for the stream route at the gateway/proxy. The controller sets `X-Accel-Buffering: no` for compatible proxies, but infrastructure configuration is still required.

## HTTP contracts

### Open a stream

`GET /fsl/sse/stream` (authenticated by `SseClientAuthenticator`). The server resolves the principal; the client does not provide a user ID selector. On connect, the client receives a `connected` event whose payload contains a `connectionId`.

### Publish an event

`POST /internal/fsl/sse/events` (authorized by `SsePublisherAuthenticator`):

```json
{
  "eventId": "optional-event-id",
  "eventType": "SESSION_CONFLICT",
  "sourceService": "LoginService",
  "correlationId": "trace-123",
  "occurredAt": "2026-11-16T10:00:00Z",
  "target": {
    "type": "USER",
    "userId": "user-101"
  },
  "payload": {
    "conflictId": "conflict-123",
    "existingChannel": "RIB",
    "requestingChannel": "IMOBILE"
  }
}
```

Target types:

- `USER`: deliver to all active connections for the user on this SSE service instance.
- `SESSION`: deliver to all active connections registered under that session ID on this instance.
- `CONNECTION`: deliver to one connection ID. The ID is returned in the initial `connected` event; the producer still requires backend authorization to publish to it.

The publish response is HTTP 202 with the event ID and write counts. A successful emitter write is **not** a browser acknowledgement and does not prove that the user saw or acted on the event.

## Runtime constraints and safety requirements

- **Single-instance baseline only:** the registry is local to one JVM. If more than one SSE instance is deployed, an event may reach a different instance from the one holding the user's connection. Do not horizontally scale this baseline until a cross-instance routing/fan-out design is implemented and tested. Sticky sessions alone do not guarantee that producer POSTs reach the correct instance.
- **No durable replay:** events are not persisted and `Last-Event-ID` replay is not implemented. Important state (for example, a pending session-conflict decision) must be stored by the owning business/session component and be retrievable after reconnect.
- **One-way transport:** UI decisions must use a separate authenticated HTTP endpoint. SSE is not the channel for submitting the user's selection.
- **Privacy:** send only the minimum data needed for the UI notification. Do not include access tokens, UPI PINs, credentials or unnecessary personal/financial information in event payloads.
- **Idempotency:** this module does not persist/deduplicate event IDs. Business producers and consumers must make important workflows idempotent.
- **Backpressure:** publish currently writes synchronously to matching emitters. Load testing is required to evaluate slow clients, large fan-outs and producer request latency before production rollout.

## Add to the FSL 0.0.9 framework build

The `framework-overlay` directory contains:

- New module at `com-fsl-framework-PARENT/com-fsl-framework-sse`.
- Updated FSL 0.0.9 parent `pom-vt.xml` with the module declaration.
- Updated dependency-parent 0.0.9 `pom-vt.xml` with dependency management.
- Updated SIT workflow with the module excluded from the parent-only step and a separate `pom-vt.xml` build step.

The `pom.xml` and `pom-vt.xml` for the new module both target 0.0.9; this module is only included by the FSL 0.0.9 parent POM. Do not add it to the 0.0.7 or 0.0.8 parent tracks without a separate compatibility build.

## Validation status

- Source-level framework inspection completed for the core FSL web layer and the TCS `MyFilter` implementation used by it.
- The source tree and POM XML can be checked locally, but **this module has not been Maven-compiled or run** in this environment: Maven and the internal FSL/TCS Maven artifacts are unavailable here.
- Before merge, build it in the internal FSL 0.0.9 environment and test: the `MyFilter` disable/replacement registration, authentication adapters, stream delivery through the real gateway, proxy idle timeouts, reconnect behaviour, connection limits, multi-tab users and slow-client fan-out.

### Add the module to the dedicated SSE Connection Service

After publishing `com-fsl-framework-sse:0.0.9` to the internal Maven repository, add this dependency to the dedicated SSE service's POM (its 0.0.9 dependency parent manages the version):

```xml
<dependency>
    <groupId>com-fsl-framework-PARENT</groupId>
    <artifactId>com-fsl-framework-sse</artifactId>
</dependency>
```

Do not add this dependency to every producer microservice. They should call the SSE service's internal publish endpoint through the existing FSL integration/Feign route.
