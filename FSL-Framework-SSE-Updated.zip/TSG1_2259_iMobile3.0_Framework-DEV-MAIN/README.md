# TSG1_2259_iMobile3.0_FSL_Framework
- Rebuild for enc update
- Rebuild for date
- Rebuild for fastag
- Rebuild for hash testing 
