package com.fsl.framework.parallelorchestration;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.tcs.fwk.constants.ResponseStatus;
import com.tcs.fwk.integration.MWOrchestratedParallelService;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.orchestration.parallel.PrepareRequestParallel;
import com.tcs.fwk.orchestration.vo.ServiceData;
import com.tcs.fwk.orchestration.vo.TouchedServiceInfoVO;
import com.tcs.fwk.service.IEmbeddedOrchInnerMWService;
import com.tcs.fwk.service.MWService;

public abstract class FSLOrchestratedParallelService extends MWOrchestratedParallelService implements IEmbeddedOrchInnerMWService {

	@Autowired
	FSLParallelDynaEmbOuterCSvc fslParallelDynaEmbOuterCSvc;

	@Override
	public MWService getOrchOuterMWService() {
		return fslParallelDynaEmbOuterCSvc;
	}
	protected abstract Map<String, PrepareRequestParallel> prepareParallelRequests();
	protected abstract MWResponse<?> prepareMWResponse(ISessionVO sessVO, Map<String, ServiceData> mapServiceData,
			Map<String, TouchedServiceInfoVO> mapInstruDataVOServiceKeysTouched, ResponseStatus statusDerivedByFwk,
			IMWRequest<?> mwRequestOrch, IMWRequestAddOn mwRequestAddOn, BaseModel extraData);
	@Override
	protected final Map<String, PrepareRequestParallel> prepare_ParallelRequests() {
		return prepareParallelRequests();
	}

	@Override
	protected final MWResponse<?> prepare_MW_response(ISessionVO sessVO, Map<String, ServiceData> mapServiceData,
			Map<String, TouchedServiceInfoVO> mapInstruDataVOServiceKeysTouched, ResponseStatus statusDerivedByFwk,
			IMWRequest<?> mwRequestOrch, IMWRequestAddOn mwRequestAddOn, BaseModel extraData) {
		return prepareMWResponse(sessVO,mapServiceData,mapInstruDataVOServiceKeysTouched,statusDerivedByFwk,mwRequestOrch, 
				mwRequestAddOn,extraData);
	}
}
