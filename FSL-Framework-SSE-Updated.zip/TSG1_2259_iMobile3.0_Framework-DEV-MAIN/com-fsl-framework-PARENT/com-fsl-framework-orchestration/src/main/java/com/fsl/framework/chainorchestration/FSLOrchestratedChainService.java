package com.fsl.framework.chainorchestration;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.tcs.fwk.constants.ResponseStatus;
import com.tcs.fwk.integration.MWOrchestratedChainService;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.orchestration.chain.PrepareRequestChain;
import com.tcs.fwk.orchestration.vo.ServiceData;
import com.tcs.fwk.orchestration.vo.TouchedServiceInfoVO;
import com.tcs.fwk.service.IEmbeddedOrchInnerMWService;
import com.tcs.fwk.service.MWService;

public abstract class FSLOrchestratedChainService extends MWOrchestratedChainService
		implements IEmbeddedOrchInnerMWService {

	@Autowired FSLChainDynaEmbOuterCSvc fslChainDynaEmbOuterCSvc;

	@Override
	public MWService getOrchOuterMWService() {
		return fslChainDynaEmbOuterCSvc;
	}

	protected abstract Map<String, PrepareRequestChain> prepareChainRequest();
	protected abstract MWResponse<?> prepareMWResponse(ISessionVO sessVO, Map<String, ServiceData> mapServiceData,
			Map<String, TouchedServiceInfoVO> mapInstruDataVOServiceKeysTouched, ResponseStatus statusDerivedByFwk,
			IMWRequest<?> mwRequestOrch, IMWRequestAddOn mwRequestAddOn, BaseModel extraData);
	
	@Override
	protected final Map<String, PrepareRequestChain> prepare_ChainRequest() {
		return  prepareChainRequest();
	}

	@Override
	protected final MWResponse<?> prepare_MW_response(ISessionVO sessVO, Map<String, ServiceData> mapServiceData,
	Map<String, TouchedServiceInfoVO> mapInstruDataVOServiceKeysTouched, ResponseStatus statusDerivedByFwk,
	IMWRequest<?> mwRequestOrch, IMWRequestAddOn mwRequestAddOn, BaseModel extraData) {
		return prepareMWResponse(sessVO,mapServiceData,mapInstruDataVOServiceKeysTouched,statusDerivedByFwk,mwRequestOrch, 
				mwRequestAddOn,extraData);
	}
}
