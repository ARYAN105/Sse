package com.fsl.framework.comporchestration;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.tcs.fwk.constants.ResponseStatus;
import com.tcs.fwk.integration.MWOrchestratedService;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.orchestration.comp.PrepareRequestCompOrch;
import com.tcs.fwk.orchestration.vo.ServiceData;
import com.tcs.fwk.orchestration.vo.TouchedServiceInfoVO;
import com.tcs.fwk.service.IEmbeddedOrchInnerMWService;
import com.tcs.fwk.service.MWService;

public abstract class FSLOrchestratedService extends MWOrchestratedService implements IEmbeddedOrchInnerMWService {

	@Autowired
	FSLDynaEmbOuterCSvc FSLDynaEmbOuterCSvc;

	@Override
	public MWService getOrchOuterMWService() {
		return FSLDynaEmbOuterCSvc;
	}
	protected abstract Map<String, PrepareRequestCompOrch> prepareServiceRequests();
	protected abstract MWResponse<?> prepareMWResponse(ISessionVO sessVO, Map<String, ServiceData> mapServiceData,
			Map<String, TouchedServiceInfoVO> mapInstruDataVOServiceKeysTouched, ResponseStatus statusDerivedByFwk,
			IMWRequest<?> mwRequestOrch, IMWRequestAddOn mwRequestAddOn, BaseModel extraData);
	@Override
	protected final Map<String, PrepareRequestCompOrch> prepare_ServiceRequests() {
		return prepareServiceRequests();
	}

	@Override
	protected final MWResponse<?> prepare_MW_response(ISessionVO sessVO, Map<String, ServiceData> mapServiceData,
			Map<String, TouchedServiceInfoVO> mapInstruDataVOServiceKeysTouched, ResponseStatus statusDerivedByFwk,
			IMWRequest<?> mwRequestOrch, IMWRequestAddOn mwRequestAddOn, BaseModel extraData) {
		return prepareMWResponse(sessVO,mapServiceData,mapInstruDataVOServiceKeysTouched,statusDerivedByFwk,mwRequestOrch,
				mwRequestAddOn, extraData);
	}
}
