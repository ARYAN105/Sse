package com.fsl.fwk.orch.constants;

public interface OauthTokenGenerateEmbOrchOuterCConstants {
  
  public static final String OAUTH_TKN_ORCH_SVC            = "OauthTokenGetC";
  public static final String OauthTokenGenerateEmbOrch_Svc = "OauthTokenGenerateEmbOrchOuterC";
  public static final String OAUTHCHK                      = "oauthChk";
  public static final String SUCCESS                       = "success";
  public static final String WTOOAUTH                      = "wtoOauth";
  
}
