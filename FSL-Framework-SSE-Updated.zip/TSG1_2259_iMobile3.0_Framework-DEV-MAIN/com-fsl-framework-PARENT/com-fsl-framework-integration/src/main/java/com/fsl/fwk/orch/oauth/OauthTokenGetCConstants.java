package com.fsl.fwk.orch.oauth;

public class OauthTokenGetCConstants {

	public static final String CACHE_CHECK="1";
	public static final String OAUTH_TKN_SVC="OauthTokenFetchI";
	public static final String OAUTH_ORCH_SVC="OauthTokenGetC";
	public static final String SUCCESS="100";
	public static final String CACHE_KEY="oauthTkn";
	public static final String CACHE_REFRESH="1";
}
