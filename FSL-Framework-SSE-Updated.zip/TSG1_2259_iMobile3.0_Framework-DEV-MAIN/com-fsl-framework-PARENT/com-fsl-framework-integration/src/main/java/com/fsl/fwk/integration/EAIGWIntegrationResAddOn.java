/*
* Copyright @ Technology Solutions (INDIA), Tata Consultancy Services Ltd.
*/
package com.fsl.fwk.integration;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.ISessionVO;

import jakarta.validation.constraints.NotNull;

/**
 * The Additional Info like Response Headers, REsponseStatus, OutputPayload etc
 * received from an integration endpoint <br>
 *
 * @author Tata Consultancy Services
 * @author 110228
 */
public class EAIGWIntegrationResAddOn<T> extends BaseModel {
	// this class is exactly same as IntegrationResponseAddOn .. except that the
	// constructor is public here & outputpayload is renamed to data

	private static final long serialVersionUID = "com.tcs.fwk.integration.IntegrationResponseAddOn".hashCode();

	@NotNull
	private ISessionVO sessionVO = null; // traceID

	@NotNull
	private T data;

	public void setData(T data) {
		this.data = data;
	}

	@NotNull
	private String statusCode;

	@NotNull
	private String errorReason;

	@JsonInclude(Include.NON_NULL)
	private Headers headers = null;

	private BaseModel extraData = null;

	private EAIGWIntegrationResAddOn() { // empty contructor reqd for Jackson serialization/deserialization
	}

	protected EAIGWIntegrationResAddOn(ISessionVO sessVO, T data, String statusCode) {
		super();
		this.sessionVO = sessVO;
		this.data = data;
		this.statusCode = statusCode;
	}

	// ===============================================
	@JsonRootName(value = "headers")
	public class Headers {

		public Headers() {
			super();
		}

		@JsonInclude(Include.NON_EMPTY)
		private Map<String, String> headersMap = null;

		@JsonAnyGetter
		protected Map<String, String> getHeadersMap() {
			return headersMap;
		}

		protected void setHeadersMap(Map<String, String> map) {
			headersMap = map;
		}

		@JsonAnySetter
		public void addHeader(String headerName, String vals) {
			if (null == headersMap)
				headersMap = new HashMap<String, String>();
			headersMap.put(headerName, vals);
		}

	}

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "headers")
	protected Headers getHeaders() {
		return headers;
	}

	public void addHeader(String headerName, String vals) {
		if (null == headers)
			this.headers = new Headers();
		;
		headers.addHeader(headerName, vals);
	}

	public void setHeadersMap(Map<String, String> headerMap) {
		if (null == headerMap || headerMap.isEmpty())
			return;
		if (null == headers)
			this.headers = new Headers();
		;
		headers.setHeadersMap(headerMap);
	}

	@JsonIgnore
	public Map<String, String> getHeadersMap() {
		return (null == headers ? null : headers.getHeadersMap());
	}

	// ======================================================

	public ISessionVO getSessionVO() {
		return sessionVO;
	}

	public T getData() {
		return data;
	}

	public BaseModel getExtraData() {
		return extraData;
	}

	/**
	 * Any additional data parameters that are otherwise not available in the
	 * input/request parameters or MWRequest, but may be required in the
	 * prepare_MW_response. Such additional data parameters may be retrieved from DB
	 * or any other Backing resource in the prepare_EAI_request and set the the
	 * IntegrationRequestAddOn which will eventually be passed in the
	 * prepare_MW_response
	 *
	 * @param extraData - a BaseModel object containing the additional data
	 */
	public void setExtraData(BaseModel extraData) {
		this.extraData = extraData;
	}

	public String getErrorReason() {
		return errorReason;
	}

	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}

	public String getStatusCode() {
		return statusCode;
	}
}
