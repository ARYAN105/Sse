package com.fsl.fwk.integration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.fsl.fwk.orch.FslEAIGWIntegrationDynaEmbOrchOuterCSvc;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.constants.ResponseStatus;
import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.integration.IntegrationRequestAddOn;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.service.IEmbeddedOrchInnerMWService;
import com.tcs.fwk.service.MWService;

/**
 * @author Dineshkumar Panchalingam
 * @author Tata Consultancy Services
 */
public abstract class FSLEAIGWIntegrationService extends EAIGWIntegrationService
    implements IEmbeddedOrchInnerMWService {
  
  @Autowired
  FslEAIGWIntegrationDynaEmbOrchOuterCSvc fslEAIGWIntegrationDynaEmbOrchOuterCSvc;
  
  @Override
  public String integrationEndpointID(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn addOn) {
    return "EAIGW" + myServiceID();
  }
  
  @Override
  public MWService getOrchOuterMWService() {
    return fslEAIGWIntegrationDynaEmbOrchOuterCSvc;
  }
  
  protected abstract IntegrationRequestAddOn<?> prepareEAIGWRequest(ISessionVO sessVO,
      IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn, BaseModel extraData)
      throws BusinessException;
  
  protected abstract MWResponse<?> prepareEAIGWMWResponse(ISessionVO sessVO,
      EAIGWIntegrationResAddOn<?> baseIntegResAddOn, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn,
      IntegrationRequestAddOn<?> baseIntegReqAddOn);
  
  protected MWResponse<?> prepareEAIGWMWResponseOnFailure(ISessionVO sessVO,
      EAIGWIntegrationResAddOn<?> baseIntegResAddOn, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn,
      IntegrationRequestAddOn<?> baseIntegReqAddOn, ResponseStatus responseStatus, List<String> listSysMsgs) {
    return new MWResponse<>(sessVO, responseStatus, listSysMsgs);
  }
  
  @Override
  protected final IntegrationRequestAddOn<?> prepare_EAIGW_request(ISessionVO sessVO, IMWRequest<?> mwRequest,
      IMWRequestAddOn mwRequestAddOn, BaseModel extraData)
      throws BusinessException {
    IntegrationRequestAddOn<?> baseIntegReqAddOn = prepareEAIGWRequest(sessVO, mwRequest, mwRequestAddOn,
        extraData);
    
    if (null == baseIntegReqAddOn)
      throw new SystemException(FwkResponseStatus.CODING_CONFIG_ERROR, "baseIntegrationRequestAddOn is null");
    
    // Adding default requestSource as serviceID
    if (baseIntegReqAddOn.getRequestSource() == null) {
      baseIntegReqAddOn.setRequestSource(myServiceID());
    }
        
    baseIntegReqAddOn.setOutboundServiceType(baseIntegReqAddOn.getRequestSource());
    
    return baseIntegReqAddOn;
  }
  
  @Override
  protected final MWResponse<?> prepare_EAIGW_MWResponse_OnFailure(ISessionVO sessVO,
      EAIGWIntegrationResAddOn<?> eaiGWIntegResAddOn, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn,
      IntegrationRequestAddOn<?> integrationRequestAddOn, ResponseStatus responseStatus,
      List<String> listSysMsgs) {
    return prepareEAIGWMWResponseOnFailure(sessVO, eaiGWIntegResAddOn, mwRequest, mwRequestAddOn,
        integrationRequestAddOn, responseStatus, listSysMsgs);
  }
  
  @Override
  protected final MWResponse<?> prepare_EAIGW_MWResponse(ISessionVO sessVO,
      EAIGWIntegrationResAddOn<?> eaiGWIntegResAddOn, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn,
      IntegrationRequestAddOn<?> integrationRequestAddOn) {
    return prepareEAIGWMWResponse(sessVO, eaiGWIntegResAddOn, mwRequest, mwRequestAddOn,
        integrationRequestAddOn);
  }
  
}
