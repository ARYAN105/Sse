package com.fsl.fwk.integration.oauth;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tcs.fwk.logger.masking.MaskRule;
import com.tcs.fwk.logger.masking.MaskSensitive;
import com.tcs.fwk.logger.masking.Sensitive;
import com.tcs.fwk.model.BaseModel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@MaskSensitive(enabled = "1")
public class OauthTokenFetchIOutput extends BaseModel {
	private static final long serialVersionUID = "com.fsl.fwk.integration.oauth.OauthTokenFetchIOutput".hashCode();
	@JsonProperty("refresh_token_expires_in")
	private String refresh_token_expires_in;

	@JsonProperty("token_type")
	private String token_type;

	@JsonProperty("issued_at")
	private String issued_at;

	@Sensitive(rule = MaskRule.ALLMASK)
	@JsonProperty("client_id")
	private String client_id;

	@JsonProperty("access_token")
	private String access_token;

	@JsonProperty("application_name")
	private String application_name;

	@JsonProperty("scope")
	private String scope;

	@JsonProperty("refresh_count")
	private String refresh_count;

	@JsonProperty("status")
	private String status;

	@JsonProperty("startTime")
	private String startTime;

	@JsonProperty("expiryTime")
	private String expiryTime;

}
