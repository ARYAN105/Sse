package com.fsl.fwk.integration;

import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequest;
import com.tcs.fwk.model.MWRequestAddOn;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.service.BackingService;

/**
 * @author Nikhil Bhumkar
 * @author Tata Consultancy Services
 */
public abstract class EAIGWIntegrationBackingService extends EAIGWIntegrationService implements BackingService {

	public final MWResponse<?> invokeBacking(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn addOn) {
		MWResponse<?> mwResponse = invoke(sessVO, (IMWRequest<?>) mwRequest, (MWRequest) mwRequest, addOn,
				(MWRequestAddOn) addOn);
		return mwResponse;
	}

}
