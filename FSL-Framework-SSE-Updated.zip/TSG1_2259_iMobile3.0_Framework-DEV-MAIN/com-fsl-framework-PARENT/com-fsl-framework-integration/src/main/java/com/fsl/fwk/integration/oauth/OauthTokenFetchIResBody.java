package com.fsl.fwk.integration.oauth;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fsl.fwk.controller.model.FSLResponseBody;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OauthTokenFetchIResBody extends FSLResponseBody {
	private static final long serialVersionUID = "com.fsl.fwk.integration.oauth.OauthTokenFetchIResBody".hashCode();

	@JsonProperty("refreshTokenExpiresIn")
	private String refreshTokenExpiresIn;

	@JsonProperty("tokenType")
	private String tokenType;

	@JsonProperty("issuedAt")
	private String issuedAt;

	@JsonProperty("clientId")
	private String clientId;

	@JsonProperty("accessToken")
	private String accessToken;

	@JsonProperty("applicationName")
	private String applicationName;

	@JsonProperty("scope")
	private String scope;

	@JsonProperty("refreshCount")
	private String refreshCount;

	@JsonProperty("status")
	private String status;

	@JsonProperty("startTime")
	private String startTime;

	@JsonProperty("expiryTime")
	private String expiryTime;
}
