package com.fsl.fwk.integration.oauth;

public class OauthTokenFetchIConstants {

	public static final String OAUTHTOKEN_AUTH_HEADER_NAME = "Authorization";
	public static final String OAUTHTOKEN_CONTENT_TYPE_VALUE = "application/x-www-form-urlencoded";
	public static final String OAUTHTOKEN_CONTENT_TYPE_STR = "Content-Type";
	public static final String OAUTHTOKNENFETCHI_SVC = "OauthTokenFetchI";
	public static final String OAUTH_CACHE_KEY = "oauthTkn";
	public static final String OAUTH_GRANTTYPE = "grant_type";
	public static final String OAUTH_CLIENT_CRED = "client_credentials";
}
