package com.fsl.fwk.integration.oauth;

import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fsl.fwk.constants.FSLResponseStatus;
import com.fsl.fwk.constants.FSLStatusConstants.ValidationStatus;
import com.fsl.fwk.integration.EAIGWIntegrationResAddOn;
import com.fsl.fwk.integration.EAIGWIntegrationService;
import com.fsl.fwk.integration.constants.EAIGWActionType;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.constants.ResponseStatus;
import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.integration.IntegrationRequestAddOn;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.service.exception.CustomValidationException;
import com.tcs.fwk.util.GenericUtil;

/**
 * Oauth token fetch
 *
 * @author Tata Consultancy Services
 * @author ban474608
 */
@Service
public class OauthTokenFetchISvc extends EAIGWIntegrationService {
  
  @Autowired
  Environment env;
  
  @Override
  protected EAIGWActionType restType() {
    return EAIGWActionType.HTTP_POST_URLFORMENCODED;
  }
  
  @Override
  public BaseModel customValidations(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn mwReqAddOn)
      throws CustomValidationException {
    return null;
  }
  
  @Override
  protected IntegrationRequestAddOn<?> prepare_EAIGW_request(ISessionVO sessVO, IMWRequest<?> mwRequest,
      IMWRequestAddOn mwRequestAddOn, BaseModel extraData)
      throws BusinessException {
    IntegrationRequestAddOn<?> integrationReqAddOn = new IntegrationRequestAddOn<>();
    
    String clientId     = env.getProperty("FSL.EAIGATEWAY.CORPOAUTH.CLIENT.ID");
    String clientSecret = env.getProperty("FSL.EAIGATEWAY.CORPOAUTH.CLIENT.SECRET");
    
    String authorization              = null;
    String base64EncodedAuthorization = null;
    
    if (GenericUtil.isNeitherNullNorEmpty(clientId) && GenericUtil.isNeitherNullNorEmpty(clientSecret)) {
      authorization              = String.join(":", clientId, clientSecret);
      base64EncodedAuthorization = Base64.getEncoder().encodeToString(authorization.getBytes());
    }
    else {
      throw new SystemException(FwkResponseStatus.CODING_CONFIG_ERROR,
          "Oauth client id & client secret not configured");
    }
    
    AppLogger.debug(sessVO, "Base64 Authorization: " + base64EncodedAuthorization);
    
    integrationReqAddOn.addHeader(OauthTokenFetchIConstants.OAUTHTOKEN_AUTH_HEADER_NAME,
        "Basic " + base64EncodedAuthorization);
    integrationReqAddOn.addHeader(OauthTokenFetchIConstants.OAUTHTOKEN_CONTENT_TYPE_STR,
        OauthTokenFetchIConstants.OAUTHTOKEN_CONTENT_TYPE_VALUE);
    
    Map<String, Object> formData = new HashMap<>();
    formData.put(OauthTokenFetchIConstants.OAUTH_GRANTTYPE, OauthTokenFetchIConstants.OAUTH_CLIENT_CRED);
    
    integrationReqAddOn.setMapFormData(formData);
    
    return integrationReqAddOn;
  }
  
  @Override
  protected MWResponse<?> prepare_EAIGW_MWResponse(ISessionVO sessVO,
      EAIGWIntegrationResAddOn<?> integResAddOn, IMWRequest<?> mwRequest, IMWRequestAddOn mwReqAddOn,
      IntegrationRequestAddOn<?> integReqAddOn) {
    MWResponse<Object> mwResponse = new MWResponse<>(sessVO, FwkResponseStatus.SUCCESS, null);
    
    OauthTokenFetchIOutput oauthTokenFetchIOutput = (OauthTokenFetchIOutput) integResAddOn.getData();
    
    OauthTokenFetchIResBody oauthTokenFetchIResBody = null;
    
    if (oauthTokenFetchIOutput != null) {
      oauthTokenFetchIResBody = new OauthTokenFetchIResBody();
      oauthTokenFetchIResBody.setRefreshTokenExpiresIn(oauthTokenFetchIOutput.getRefresh_token_expires_in());
      oauthTokenFetchIResBody.setTokenType(oauthTokenFetchIOutput.getToken_type());
      oauthTokenFetchIResBody.setIssuedAt(oauthTokenFetchIOutput.getIssued_at());
      oauthTokenFetchIResBody.setClientId(oauthTokenFetchIOutput.getClient_id());
      oauthTokenFetchIResBody.setAccessToken(oauthTokenFetchIOutput.getAccess_token());
      oauthTokenFetchIResBody.setApplicationName(oauthTokenFetchIOutput.getApplication_name());
      oauthTokenFetchIResBody.setScope(oauthTokenFetchIOutput.getScope());
      oauthTokenFetchIResBody.setRefreshCount(oauthTokenFetchIOutput.getRefresh_count());
      oauthTokenFetchIResBody.setStatus(oauthTokenFetchIOutput.getStatus());
      oauthTokenFetchIResBody.setStartTime(oauthTokenFetchIOutput.getStartTime());
      oauthTokenFetchIResBody.setExpiryTime(oauthTokenFetchIOutput.getExpiryTime());
      
      mwResponse.setBody(oauthTokenFetchIResBody);
    }
    else {
      mwResponse = getOauthErrorResponse(sessVO, "Corp Oauth Response Missing");
    }
    
    return mwResponse;
  }
  
  @Override
  protected MWResponse<?> prepare_EAIGW_MWResponse_OnFailure(ISessionVO sessVO,
      EAIGWIntegrationResAddOn<?> eaiGWIntegResAddOn, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn,
      IntegrationRequestAddOn<?> integrationRequestAddOn, ResponseStatus responseStatus,
      List<String> listSysMsgs) {
    String errorResDataStr = (String) eaiGWIntegResAddOn.getData();
    
    AppLogger.error(sessVO, "Oauth Request Failed: [ " + errorResDataStr + " ]", null);
    
    return getOauthErrorResponse(sessVO, errorResDataStr);
  }
  
  private MWResponse<Object> getOauthErrorResponse(ISessionVO sessVO, String errorDescription) {
    MWResponse<Object> mwRes = new MWResponse<>(sessVO, FSLResponseStatus.FSL_SECURITY_VALIDATION_FAILED,
        Arrays.asList(errorDescription));
    mwRes.setMsgCds(Arrays.asList(ValidationStatus.CORP_OAUTH_FAILURE.getErrString()));
    return mwRes;
  }
    
  @Override
  protected Class<? extends BaseModel> eaiOutputDataType() {
    return OauthTokenFetchIOutput.class;
  }
  
  @Override
  protected Class<? extends BaseModel> myRequestBodyType() {
    return null;
  }
  
}
