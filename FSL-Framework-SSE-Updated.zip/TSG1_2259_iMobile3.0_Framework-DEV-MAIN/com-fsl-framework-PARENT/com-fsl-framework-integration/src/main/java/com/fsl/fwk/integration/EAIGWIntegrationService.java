package com.fsl.fwk.integration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.UnaryOperator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.controller.model.FSLUserProfile;
import com.fsl.fwk.integration.constants.EAIGWActionType;
import com.fsl.fwk.model.FSLFalconHeaders;
import com.fsl.fwk.utils.OAuthUtil;
import com.tcs.fwk.constants.FwkConstants;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.constants.ResponseStatus;
import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.integration.IntegrationAdapters.ADAPTERS;
import com.tcs.fwk.integration.IntegrationRequestAddOn;
import com.tcs.fwk.integration.IntegrationResponseAddOn;
import com.tcs.fwk.integration.MWIntegrationService;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.util.GenericUtil;
import com.tcs.fwk.util.JSONUtil;

/**
 * @author Nikhil Bhumkar
 * @author Tata Consultancy Services
 */
public abstract class EAIGWIntegrationService extends MWIntegrationService {
  
  @Value("${FWK.MWRESPONSE.HTTPSTATUS.CUSTOM.allow}")
  protected String allowCustomHttpStatus = "0";
  
  @Value("${FWK.LOGGER.DEFAULT.eaiPayload.headers.excludes:}")
  private List<String> excludeLogHeaders = null;
  
  @Value("${FSL.EAIGATEWAY.CORP.OAUTH.EXCLUDE.SYSTEMS:}")
  List<String> excludeCorpOauthSystems;
  
  @Autowired
  OAuthUtil oAuthUtil;
  
  @Autowired
  EAIGWPayloadHelper eaigwPayloadHelper;
  
  @Override
  public final ADAPTERS myIntegrationAdapter() {
    return restType().value;
  }
  
  private UnaryOperator<String> eaiPayloadPrint = svcId -> GenericUtil.isNullOrEmpty(svcId)
      ? "FWK.LOGGER.DEFAULT.eaiPayload.print"
      : "FWK.LOGGER." + svcId + ".eaiPayload.print";
  
  private UnaryOperator<String> eaiPayloadHeadersPrint = svcId -> GenericUtil.isNullOrEmpty(svcId)
      ? "FWK.LOGGER.DEFAULT.eaiPayload.headers.print"
      : "FWK.LOGGER." + svcId + ".eaiPayload.headers.print";
  
  private UnaryOperator<String> mtlsEnabled = svcId -> GenericUtil.isNullOrEmpty(svcId)
      ? "FWK.EAI.DEFAULT.ENABLE.mTLS"
      : "FWK.EAI." + svcId + ".ENABLE.mTLS";
  
  public boolean isFeatureEnabled(UnaryOperator<String> isPropertyEnabled, String defaultVal) {
    String defaultEnableProp = isPropertyEnabled.apply(null);
    String srvEnableProp     = isPropertyEnabled.apply(myServiceID());
    
    String propValue = GenericUtil.isNullOrEmpty(env.getProperty(srvEnableProp))
        ? env.getProperty(defaultEnableProp, defaultVal)
        : env.getProperty(srvEnableProp);
    
    return "1".equals(propValue);
  }
  
  protected EAIGWActionType restType() {
    return isFeatureEnabled(mtlsEnabled, "0") ? EAIGWActionType.HTTP_POST_SSL : EAIGWActionType.HTTP_POST;
  }
  
  @Override
  protected final IntegrationRequestAddOn<?> prepare_EAI_request(ISessionVO sessVO, IMWRequest<?> mwRequest,
      IMWRequestAddOn mwRequestAddOn, BaseModel extraData)
      throws BusinessException {
    /*TODO: 
       We are adding fslUserProfile manually as a temporary fix to resolve a ClassCastException occurring when fetching the user profile in an asynchronous service consumer.
       When the Envelope is passed via a message broker (Kafka/ActiveMQ), the object is serialized. Upon deserialization, the additionalAttribs map contains a LinkedHashMap instead of the strongly typed FSLUserProfile object, causing the casting to fail:
       FSLUserProfile fslUserProfile = (FSLUserProfile) mwRequestAddOn.getUser().getAddtionalAttribs().get("fslUserProfile");
       This resulted in a ClassCastException because the value retrieved was a LinkedHashMap.
       */
    if (GenericUtil.isNeitherNullNorEmpty(mwRequestAddOn.getUser())
        && GenericUtil.isNeitherNullNorEmpty(mwRequestAddOn.getUser().getAddtionalAttribs())) {
      Object profile = mwRequestAddOn.getUser().getAddtionalAttribs().get("fslUserProfile");
      if (GenericUtil.isNeitherNullNorEmpty(profile) && !(profile instanceof FSLUserProfile)) {
        FSLUserProfile fslUserProfile = jsonUtil.convert_Object_To_BaseModel(sessVO, profile,
            FSLUserProfile.class);
        mwRequestAddOn.getUser().getAddtionalAttribs().put("fslUserProfile", fslUserProfile);
      }
    }
    
    // =========================================
    IntegrationRequestAddOn<?> integReqAddOn = prepare_EAIGW_request(sessVO, mwRequest, mwRequestAddOn,
        extraData);
    // =========================================
    if (null == integReqAddOn)
      throw new SystemException(FwkResponseStatus.CODING_CONFIG_ERROR, "fslIntegReqAddOn is null");
    
    // Adding default requestSource as serviceID
    if (integReqAddOn.getRequestSource() == null)
      integReqAddOn.setRequestSource(myServiceID());
    
    if (integReqAddOn.isBypassInvoke())
      return integReqAddOn;
    
    // Prepare EAIGateway Payload wtih encrypted data etc
    integReqAddOn = eaigwPayloadHelper.prepare_EAIGW_OB_request(sessVO, integReqAddOn, myServiceID());
    
    if (GenericUtil.isNeitherNullNorEmpty(mwRequestAddOn.getHeadersMap())
        && GenericUtil.isNeitherNullNorEmpty(mwRequestAddOn.getHeadersMap().get("internaltest"))) {
      AppLogger.debug(sessVO, "EAIIntService - InternalTest header found");
      integReqAddOn.addHeader("InternalTest", mwRequestAddOn.getHeadersMap().get("internaltest").get(0));
    }
    // Additional header added for Ipay Integ Services
    if (GenericUtil.isNeitherNullNorEmpty(mwRequestAddOn.getHeadersMap())
        && GenericUtil.isNeitherNullNorEmpty(mwRequestAddOn.getHeadersMap().get("ipay"))) {
      AppLogger.debug(sessVO, "EAIIpayService - Ipay header found");
      integReqAddOn.addHeader("ipay", mwRequestAddOn.getHeadersMap().get("ipay").get(0));
    }
    
    // INTDMZ , DEH - no need to add corp OAuth
    if (!excludeCorpOauthSystems.contains(integReqAddOn.getRequestSource())) {
      
      String corpOauthEnableFlag = oAuthUtil.checkOAuthEnabled(myServiceID());
      
      Map<String, List<String>> headersMap = mwRequestAddOn.getHeadersMap();
      
      if ("1".equalsIgnoreCase(corpOauthEnableFlag) && GenericUtil.isNeitherNullNorEmpty(headersMap)
          && GenericUtil.isNeitherNullNorEmpty(headersMap.get(FSLConstants.HEADER_OAUTH_TOKEN))) {
        integReqAddOn.addHeader(FSLConstants.HEADER_AUTH,
            headersMap.get(FSLConstants.HEADER_OAUTH_TOKEN).get(0));
        
        AppLogger.debug(sessVO, "Oauth token appended");
        
      }
    }
    
    return integReqAddOn;
  }
  
  @Override
  protected final MWResponse<?> prepare_MW_response(ISessionVO sessVO,
      IntegrationResponseAddOn<?> responseAddOn, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn,
      IntegrationRequestAddOn<?> integrationRequestAddOn) {
    EAIGWIntegrationResAddOn<?> eaigwIntegResAddOn = null;
    if (!integrationRequestAddOn.isBypassInvoke()) {
      if (null == responseAddOn || null == responseAddOn.getOutputPayload()) {
        return new MWResponse<>(sessVO, FwkResponseStatus.NO_DATA_IN_EAI_RESPONSE,
            Arrays.asList("EAIGateway API returned null responseBody."));
      }
      
      // decrypt the data in the ApiGee OutputPayload
      try {
        eaigwIntegResAddOn = eaigwPayloadHelper.prepare_EAIGW_OB_response(sessVO, responseAddOn,
            integrationRequestAddOn, eaiOutputDataType());
        
        boolean isEaiPayloadEnabled = isFeatureEnabled(eaiPayloadPrint, "1");
        boolean isEaiPayloadHeaders = isFeatureEnabled(eaiPayloadHeadersPrint, "1");
        
        if (isEaiPayloadEnabled || isEaiPayloadHeaders)
          logOutboundPayload(sessVO, integrationRequestAddOn, eaigwIntegResAddOn, isEaiPayloadEnabled, isEaiPayloadHeaders);
      }
      catch (SystemException ex) {
        return new MWResponse<>(sessVO, ex.getStatus(), Arrays.asList(ex.getErrorMessage()));
      }
    }
    MWResponse<?> mwRes = prepare_EAIGW_MWResponse(sessVO, eaigwIntegResAddOn, mwRequest, mwRequestAddOn,
        integrationRequestAddOn);
    // TBD-NIKHIL: Please test & uncomment this code for Handling for Istio .. for
    // all types of MWService
    /*
     * if (allowCustomHttpStatus.equals("1")) { if
     * (mwRes.getStatusCd()==(FwkResponseStatus.CIRCUIT_BREAKER_TIMEOUT.getCode()))
     * mwRes.setHttpStatusCd(HttpStatus.GATEWAY_TIMEOUT) ; //504 else if
     * (mwRes.getStatusCd()==(FwkResponseStatus.EAI_INVOCATION_FAILED.getCode()))
     * mwRes.setHttpStatusCd(HttpStatus.SERVICE_UNAVAILABLE) ; //503 }
     */
    return mwRes;
  }
  
  protected abstract IntegrationRequestAddOn<?> prepare_EAIGW_request(ISessionVO sessVO,
      IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn, BaseModel extraData)
      throws BusinessException;
  
  protected abstract MWResponse<?> prepare_EAIGW_MWResponse(ISessionVO sessVO,
      EAIGWIntegrationResAddOn<?> eaiGWIntegResAddOn, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn,
      IntegrationRequestAddOn<?> integrationRequestAddOn);
  
  protected MWResponse<?> prepare_EAIGW_MWResponse_OnFailure(ISessionVO sessVO,
      EAIGWIntegrationResAddOn<?> eaiGWIntegResAddOn, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn,
      IntegrationRequestAddOn<?> integrationRequestAddOn, ResponseStatus responseStatus,
      List<String> listSysMsgs) {
    return new MWResponse<>(sessVO, responseStatus, listSysMsgs);
  }
  
  // this is NOT mandatory. If left null, the data will be set as String
  protected abstract Class<? extends BaseModel> eaiOutputDataType();
  
  @SuppressWarnings({ "unused", "serial" })
  private class DataVO extends BaseModel {
    DataVO(String data) {
      super();
      this.data = data;
    }
    
    String data;
    
    public String getData() {
      return data;
    }
    
  }
  
  @Override
  protected final MWResponse<?> prepare_MW_response_OnFailure(ISessionVO sessVO,
      IntegrationResponseAddOn<?> integrationResponseAddOn, IMWRequest<?> mwRequest,
      IMWRequestAddOn mwRequestAddOn, IntegrationRequestAddOn<?> integrationRequestAddOn,
      ResponseStatus responseStatus, List<String> listSysMsgs) {
    EAIGWIntegrationResAddOn<?> eaigwIntegResAddOn = null;
    if (GenericUtil.isNeitherNullNorEmpty(integrationResponseAddOn)) {
      
      try {
        eaigwIntegResAddOn = eaigwPayloadHelper.prepare_EAIGW_OB_response_OnFailure(sessVO,
            integrationResponseAddOn, integrationRequestAddOn);
        
      }
      catch (SystemException ex) {
        return new MWResponse<>(sessVO, ex.getStatus(), Arrays.asList(ex.getErrorMessage()));
      }
    }
    boolean isEaiPayloadEnabled = isFeatureEnabled(eaiPayloadPrint, "1");
    boolean isEaiPayloadHeaders = isFeatureEnabled(eaiPayloadHeadersPrint, "1");
    
    if (isEaiPayloadEnabled || isEaiPayloadHeaders)
      logOutboundPayload(sessVO, integrationRequestAddOn, eaigwIntegResAddOn, isEaiPayloadEnabled, isEaiPayloadHeaders);
//    logOutboundPayload(sessVO, integrationRequestAddOn, eaigwIntegResAddOn);
    
    return prepare_EAIGW_MWResponse_OnFailure(sessVO, eaigwIntegResAddOn, mwRequest, mwRequestAddOn,
        integrationRequestAddOn, responseStatus, listSysMsgs);
  }
  
  protected final FSLFalconHeaders getFalconHeaders(IMWRequestAddOn mwRequestAddOn) {
    FSLFalconHeaders          falconHeaders = null;
    Map<String, List<String>> headers       = mwRequestAddOn.getHeadersMap();
    
    if (GenericUtil.isNeitherNullNorEmpty(headers.get(FSLConstants.HEADER_POSTALCODE.toLowerCase()))
        || GenericUtil.isNeitherNullNorEmpty(headers.get(FSLConstants.HEADER_STREET))
        || GenericUtil.isNeitherNullNorEmpty(headers.get(FSLConstants.HEADER_CITY))
        || GenericUtil.isNeitherNullNorEmpty(headers.get(FSLConstants.HEADER_IPADDRESS.toLowerCase()))
        || GenericUtil.isNeitherNullNorEmpty(headers.get(FSLConstants.HEADER_OSTYPE.toLowerCase()))) {
      falconHeaders = new FSLFalconHeaders();
      
      String       deviceId    = (GenericUtil
          .isNullOrEmpty(headers.get(FwkConstants.HEADER_DEVICEID.toLowerCase())) ? ""
              : headers.get(FwkConstants.HEADER_DEVICEID.toLowerCase()).get(0));
      List<String> defaultList = new ArrayList<>(1);
      defaultList.add("");
      
      falconHeaders.setPostalCode(
          GenericUtil.isNullOrEmpty(headers.get(FSLConstants.HEADER_POSTALCODE.toLowerCase())) ? ""
              : headers.get(FSLConstants.HEADER_POSTALCODE.toLowerCase()).get(0));
      if (GenericUtil.isNullOrEmpty(headers.get(FSLConstants.HEADER_STREET))
          || GenericUtil.isNullOrEmpty(headers.get(FSLConstants.HEADER_STREET).get(0)))
        falconHeaders.setStreet("0,0");
      else
        falconHeaders.setStreet(headers.get(FSLConstants.HEADER_STREET).get(0));
      falconHeaders.setCity(GenericUtil.isNullOrEmpty(headers.get(FSLConstants.HEADER_CITY)) ? ""
          : headers.get(FSLConstants.HEADER_CITY).get(0));
      falconHeaders.setDeviceId(deviceId);
      falconHeaders.setUserData09(""); // Currently set as empty until further discussion
      falconHeaders.setUserData11(""); // Currently set as empty until further discussion
      falconHeaders.setUserData12(""); // Currently set as empty until further discussion
      falconHeaders.setUserData18(""); // Currently set as empty until further discussion
      falconHeaders
          .setUserId(GenericUtil.isNullOrEmpty(headers.get(FwkConstants.HEADER_USERID.toLowerCase())) ? ""
              : headers.get(FwkConstants.HEADER_USERID.toLowerCase()).get(0));
      falconHeaders.setDeviceIP(
          GenericUtil.isNullOrEmpty(headers.get(FSLConstants.HEADER_IPADDRESS.toLowerCase())) ? ""
              : headers.get(FSLConstants.HEADER_IPADDRESS.toLowerCase()).get(0));
      
      falconHeaders.setDeviceType("MOB");
      falconHeaders
          .setDeviceOS(GenericUtil.isNullOrEmpty(headers.get(FSLConstants.HEADER_OSTYPE.toLowerCase())) ? ""
              : headers.get(FSLConstants.HEADER_OSTYPE.toLowerCase()).get(0));
      falconHeaders.setCapability("101020");
      falconHeaders
          .setAppId(GenericUtil.isNullOrEmpty(headers.get(FSLConstants.HEADER_NPCIAPPID.toLowerCase())) ? ""
              : headers.get(FSLConstants.HEADER_NPCIAPPID.toLowerCase()).get(0));
      FSLUserProfile fslUserProfile = (FSLUserProfile) mwRequestAddOn.getUser().getAddtionalAttribs()
          .get("fslUserProfile");
      if (GenericUtil.isNeitherNullNorEmpty(fslUserProfile)) {
        falconHeaders
            .setOnlineAccountOpenDate(GenericUtil.isNullOrEmpty(fslUserProfile.getUsrCreatedDate()) ? ""
                : fslUserProfile.getUsrCreatedDate());
        falconHeaders
            .setUserdTouchMFAEnable(GenericUtil.isNullOrEmpty(fslUserProfile.getUserdTouchMFAEnable()) ? ""
                : fslUserProfile.getUserdTouchMFAEnable());
      }
      falconHeaders.setCustomerApplicationVersion(
          GenericUtil.isNullOrEmpty(mwRequestAddOn.getHeadersMap().get("version")) ? ""
              : mwRequestAddOn.getHeadersMap().get("version").get(0));
    }
    
    return falconHeaders;
  }
  
  private void logOutboundPayload(ISessionVO sessVO, IntegrationRequestAddOn<?> integReqAddOn,
      EAIGWIntegrationResAddOn<?> eaigwIntegResAddOn, boolean isEaiPayloadEnabled, boolean isEaiPayloadHeaders) {
    try {
      if (GenericUtil.isNeitherNullNorEmpty(integReqAddOn)) {
        StringBuilder eaiReqPayload = new StringBuilder();
        
        if (isEaiPayloadEnabled) {
          eaiReqPayload.append("{ \"eaiReqPayload\":");
          eaiReqPayload.append(GenericUtil.isNullOrEmpty(integReqAddOn.getInputPayload()) ? "\"\""
              : JSONUtil.staticMaskedSerializeJSONObj(sessVO, integReqAddOn.getInputPayload()));
        }
        
        if (isEaiPayloadHeaders && GenericUtil.isNeitherNullNorEmpty(integReqAddOn.getHeadersMap())) {
          if(isEaiPayloadEnabled) eaiReqPayload.append(", \"eaiReqHeaders\":");
          else eaiReqPayload.append("{ \"eaiReqHeaders\":");
          
          eaiReqPayload.append(JSONUtil.staticMaskedSerializeJSONObj(sessVO, integReqAddOn.getHeadersMap()));
        }
        
        eaiReqPayload.append("}");
        AppLogger.info(sessVO, eaiReqPayload.toString());
      }
      else
        AppLogger.debug(sessVO, "EAI Req Payload Printing Skipped: reqAddOn is null");
      
      if (GenericUtil.isNeitherNullNorEmpty(eaigwIntegResAddOn)) {
        
        StringBuilder eaiResPayload = new StringBuilder();
        
        if(isEaiPayloadEnabled) {
          eaiResPayload.append("{ \"eaiResPayload\":");
          eaiResPayload.append(GenericUtil.isNullOrEmpty(eaigwIntegResAddOn.getData()) ? " "
              : JSONUtil.staticMaskedSerializeJSONObj(sessVO, eaigwIntegResAddOn.getData()));
        }
        
        if (isEaiPayloadHeaders && GenericUtil.isNeitherNullNorEmpty(eaigwIntegResAddOn.getHeadersMap())) {
          if (isEaiPayloadEnabled) eaiResPayload.append(", \"eaiResHeaders\":");
          else eaiResPayload.append("{ \"eaiResHeaders\":");
          
          eaiResPayload.append(JSONUtil.staticMaskedSerializeJSONObj(sessVO, eaigwIntegResAddOn.getHeadersMap()));
        }
        
        eaiResPayload.append("}");
        AppLogger.info(sessVO, eaiResPayload.toString());
      }
      else
        AppLogger.debug(sessVO, "EAI Res Payload Printing Skipped: resAddOn is null");
    }
    catch (Exception e) {
      AppLogger.error(sessVO, "Exception while print EAI Payload::" + e.getMessage(), null);
    }
  }
  
}