package com.fsl.fwk.orch.oauth;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fsl.fwk.controller.model.FSLResponseBody;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OauthTokenGetCResBody extends FSLResponseBody {

	private static final long serialVersionUID = "com.fsl.fwk.orch.oauth.OauthTokenGetCResBody".hashCode();

	@JsonProperty("accessToken")
	private String accessToken;

	@JsonProperty("expiryTime")
	private String expiryTime;

}
