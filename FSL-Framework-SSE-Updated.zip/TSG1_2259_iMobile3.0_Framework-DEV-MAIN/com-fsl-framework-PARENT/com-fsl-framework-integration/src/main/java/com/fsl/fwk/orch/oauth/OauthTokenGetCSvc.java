package com.fsl.fwk.orch.oauth;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fsl.fwk.constants.FSLResponseStatus;
import com.fsl.fwk.constants.FSLStatusConstants.ValidationStatus;
import com.fsl.fwk.integration.oauth.OauthTokenFetchIResBody;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.constants.ResponseStatus;
import com.tcs.fwk.integration.MWOrchestratedChainService;
import com.tcs.fwk.integration.OrchestrationHelper;
import com.tcs.fwk.integration.ServiceRequestAddOn;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequest;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.orchestration.chain.PrepareRequestChain;
import com.tcs.fwk.orchestration.chain.ServiceEvaluation;
import com.tcs.fwk.orchestration.vo.ServiceData;
import com.tcs.fwk.orchestration.vo.TouchedServiceInfoVO;
import com.tcs.fwk.service.exception.CustomValidationException;
import com.tcs.fwk.service.model.MWResponseBodyType;
import com.tcs.fwk.service.model.PayloadType;
import com.tcs.fwk.util.GenericUtil;

/**
 * Oauth token get orchestration
 *
 * @author Tata Consultancy Services
 * @author ban474608
 */
@Service
public class OauthTokenGetCSvc extends MWOrchestratedChainService {
  
  @Autowired
  OrchestrationHelper orchHelper;
  
  @Autowired
  Environment env;
  
  @Override
  public BaseModel customValidations(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn addOn)
      throws CustomValidationException {
    return null;
  }
  
  @Override
  protected Map<String, ServiceEvaluation> eval() {
    Map<String, ServiceEvaluation> chainRequestMap = new HashMap<>();
    
    chainRequestMap.put(OauthTokenGetCConstants.OAUTH_ORCH_SVC,(sessionVO, orchInputParams) -> 
    {
      String evalsTo = null;
      
      String refreshFlag = orchInputParams.mwRequestOrch.getHead().getRefresh();
      
      if (GenericUtil.isNeitherNullNorEmpty(refreshFlag) && "1".equalsIgnoreCase(refreshFlag)) {
        evalsTo = OauthTokenGetCConstants.SUCCESS;
      }
      
      return evalsTo;
    });
    
    return chainRequestMap;
  }

  @Override
  protected Map<String, PrepareRequestChain> prepare_ChainRequest() {
    Map<String, PrepareRequestChain> chainRequestMap = new HashMap<>();
    
    chainRequestMap.put(OauthTokenGetCConstants.OAUTH_TKN_SVC, (sessVO, dynaSuffix, orchInputParams) -> {
      return new ServiceRequestAddOn<>(new MWRequest<>());
    });
    
    return chainRequestMap;
  }
  
  private MWResponse<Object> getOauthErrorResponse(ISessionVO sessVO, String errorDescription) {
    MWResponse<Object> mwRes = new MWResponse<>(sessVO, FSLResponseStatus.FSL_SECURITY_VALIDATION_FAILED,
        Arrays.asList(errorDescription));
    mwRes.setMsgCds(Arrays.asList(ValidationStatus.CORP_OAUTH_FAILURE.getErrString()));
    return mwRes;
  }
  
  @Override
  protected MWResponse<?> prepare_MW_response(ISessionVO sessVO, Map<String, ServiceData> mapServiceData,
      Map<String, TouchedServiceInfoVO> mapInstruDataVoServiceKeysTouched, ResponseStatus statusDerivedByFwk,
      IMWRequest<?> mwRequestOrch, IMWRequestAddOn mwRequestAddOn, BaseModel extraData) {
    MWResponse<Object> mwResponse = new MWResponse<>(sessVO, statusDerivedByFwk, null);
    
    if(mapInstruDataVoServiceKeysTouched.isEmpty()) {
      mwResponse = getOauthErrorResponse(sessVO, "Corp Oauth Token is not available");
      AppLogger.error(sessVO, "OAuth token is unavailable", null);
    }
    else {
      
      TouchedServiceInfoVO oauthTokenFetchIResBodyLGNTouchedInfo = mapInstruDataVoServiceKeysTouched
          .get(orchHelper.getServiceKey(OauthTokenGetCConstants.OAUTH_TKN_SVC, null, null));
      if (oauthTokenFetchIResBodyLGNTouchedInfo != null) {
        
        MWResponse<Object> oauthTokenFetchIMWResponse = orchHelper
            .getMWResponse_from_MapSvcData(mapServiceData, OauthTokenGetCConstants.OAUTH_TKN_SVC, null, null);
        
        OauthTokenGetCResBody resBody = new OauthTokenGetCResBody();
        
        if (FwkResponseStatus.SUCCESS.getCode() == oauthTokenFetchIMWResponse.getStatusCd()
            && GenericUtil.isNeitherNullNorEmpty(oauthTokenFetchIMWResponse.getBody())) {
          
          OauthTokenFetchIResBody oauthTokenFetchIResBody = (OauthTokenFetchIResBody) oauthTokenFetchIMWResponse
              .getBody();
          
          resBody.setAccessToken(oauthTokenFetchIResBody.getAccessToken());
          resBody.setExpiryTime(oauthTokenFetchIResBody.getExpiryTime());
          mwResponse.setStatusCd(FwkResponseStatus.SUCCESS);
          mwResponse.setBody(resBody);
          
        }
        else {
          mwResponse = oauthTokenFetchIMWResponse;
        }
      }
    }
    
    return mwResponse;
  }
  
  @Override
  protected String[] cacheKey(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn) {
    return new String[] { OauthTokenGetCConstants.CACHE_KEY };
  }
  
  @Override
  protected Class<? extends BaseModel> myRequestBodyType() {
    return null;
  }
  
  @Override
  protected Map<String, PayloadType> innerServiceOutputPayloadTypes() {
    Map<String, PayloadType> innerSvcOutputPayloadTypes = new HashMap<>();
    
    innerSvcOutputPayloadTypes.put(OauthTokenGetCConstants.OAUTH_TKN_SVC,
        new MWResponseBodyType(OauthTokenFetchIResBody.class));
    
    return innerSvcOutputPayloadTypes;
  }
  
}
