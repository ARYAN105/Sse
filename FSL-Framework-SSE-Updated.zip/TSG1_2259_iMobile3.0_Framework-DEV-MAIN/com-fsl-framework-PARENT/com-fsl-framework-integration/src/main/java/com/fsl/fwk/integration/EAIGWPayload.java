package com.fsl.fwk.integration;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tcs.fwk.model.BaseModel;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

/**
 * @author Nikhil Bhumkar
 * @author Tata Consultancy Services
 */
@XmlRootElement(name = "EAIGWPayload")
@XmlAccessorType(XmlAccessType.FIELD)
public class EAIGWPayload extends BaseModel {

	private static final long serialVersionUID = "com.fsl.fwk.integration.EAIGWPayload".hashCode();

	@XmlElement(name = "encryptedData")
	private String encryptedData = "";
	@XmlElement(name = "requestId")
	private String requestId = "";
	@XmlElement(name = "encryptedKey")
	private String encryptedKey = "";
	@XmlElement(name = "service")
	private String service = "";
	@XmlElement(name = "oaepHashingAlgorithm")
	private String oaepHashingAlgorithm = "";
	@XmlElement(name = "clientInfo")
	private String clientInfo = "";
	@XmlElement(name = "iv")
	private String iv = "";
	@XmlElement(name = "optionalParam")
	private String optionalParam = "";

	public EAIGWPayload(String requestId, String encryptedData, String encryptedKey, String service) {
		super();
		this.requestId = requestId;
		this.encryptedData = encryptedData;
		this.encryptedKey = encryptedKey;
		this.service = service;
	}

	public EAIGWPayload() {

	}

	public String getOaepHashingAlgorithm() {
		return oaepHashingAlgorithm;
	}

	public void setOaepHashingAlgorithm(String oaepHashingAlgorithm) {
		this.oaepHashingAlgorithm = oaepHashingAlgorithm;
	}

	public String getClientInfo() {
		return clientInfo;
	}

	public void setClientInfo(String clientInfo) {
		this.clientInfo = clientInfo;
	}

	public String getIv() {
		return iv;
	}

	public void setIv(String iv) {
		this.iv = iv;
	}

	public String getOptionalParam() {
		return optionalParam;
	}

	public void setOptionalParam(String optionalParam) {
		this.optionalParam = optionalParam;
	}

	@JsonProperty(value = "encryptedData")
	public String getEncryptedData() {
		return encryptedData;
	}

	@JsonProperty(value = "requestId")
	public String getRequestId() {
		return requestId;
	}

	@JsonProperty(value = "encryptedKey")
	public String getEncryptedKey() {
		return encryptedKey;
	}

	@JsonProperty(value = "service")
	public String getService() {
		return service;
	}

}
