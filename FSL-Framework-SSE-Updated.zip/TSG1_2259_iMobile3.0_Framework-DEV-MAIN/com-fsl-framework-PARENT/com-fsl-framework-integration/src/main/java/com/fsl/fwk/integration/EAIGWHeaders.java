package com.fsl.fwk.integration;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author Nikhil Bhumkar
 * @author Tata Consultancy Services
 */
public class EAIGWHeaders implements Serializable {
	private static final long serialVersionUID = "com.tcs.fwk.integration.EAIGWHeaders".hashCode();

	public EAIGWHeaders() {
		super();
	}

	@JsonInclude(Include.NON_EMPTY)
	private Map<String, String> headersMap = null;

	@JsonAnyGetter
	public Map<String, String> getHeadersMap() {
		return headersMap;
	}

	public void setHeadersMap(Map<String, String> map) {
		headersMap = map;
	}

	@JsonAnySetter
	public void addHeader(String headerName, String vals) {
		if (null == headersMap)
			headersMap = new HashMap<String, String>();
		headersMap.put(headerName, vals);
	}

}