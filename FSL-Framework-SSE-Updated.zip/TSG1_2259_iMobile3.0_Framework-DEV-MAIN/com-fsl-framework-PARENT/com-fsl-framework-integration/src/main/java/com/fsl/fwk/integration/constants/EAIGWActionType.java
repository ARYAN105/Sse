package com.fsl.fwk.integration.constants;

import com.tcs.fwk.integration.IntegrationAdapters.ADAPTERS;

public enum EAIGWActionType {

	HTTP_POST(ADAPTERS.http_rest_post),
	HTTP_POST_SSL(ADAPTERS.http_rest_post_SSL),
	HTTP_POST_URLFORMENCODED(ADAPTERS.http_rest_post_urlformencoded),
	HTTP_FILE(ADAPTERS.http_rest_file_post);

	public final ADAPTERS value;

	private EAIGWActionType(ADAPTERS value) {
		this.value = value;
	}

}
