package com.fsl.fwk.integration;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.fsl.fwk.integration.constants.EAIGWConstants;
import com.fsl.fwk.utils.EncrypDecrypUtils;
import com.fsl.fwk.utils.OAuthUtil;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.integration.IntegrationRequestAddOn;
import com.tcs.fwk.integration.IntegrationResponseAddOn;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.EncDecModel;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.util.GenericUtil;
import com.tcs.fwk.util.JSONUtil;

/**
 * @author Nikhil Bhumkar
 * @author Tata Consultancy Services
 */
@Component
public class EAIGWPayloadHelper implements Serializable {
	private static final long serialVersionUID = "com.tcs.fwk.integration.EAIGWPayloadHelper".hashCode();

	@Autowired
	Environment env;

	@Autowired
	JSONUtil jsonUtil;

	@Autowired
	OAuthUtil oAuthUtil;
	
  @Value("${FSL.EAIGATEWAY.CORP.OAUTH.EXCLUDE.SYSTEMS:}")
  private List<String> excludeCorpOauthSystems;

	protected IntegrationRequestAddOn<?> prepare_EAIGW_OB_request(ISessionVO sessVO,
			IntegrationRequestAddOn<?> integAddOnReq, String svcId) {

		IntegrationRequestAddOn<?> integReqAddOn = integAddOnReq;
		String payloadEncPropPref = "FSL.EAIGATEWAY.ENCRYPTION." + integReqAddOn.getRequestSource();
		String isEncryptionEnabled = env.getProperty(payloadEncPropPref + ".FLAG", "");

		// changes for Empty InputPayload: To avoid create encryption body in case null
		// requestBody
		if (GenericUtil.isNeitherNullNorEmpty(integReqAddOn.getInputPayload())
				&& "1".equalsIgnoreCase(isEncryptionEnabled)) {
			String data = jsonUtil.serializeJSONObj(sessVO, integReqAddOn.getInputPayload());
			String encryptionType = env.getProperty(payloadEncPropPref + ".TYPE", "");
			if (EAIGWConstants.HSYMMETRIC_ENCRYPTION.value.equalsIgnoreCase(encryptionType)) {
				String publicKey = env.getProperty(payloadEncPropPref + ".HSYM.PUBLICKEY");
				EncDecModel encDecModel = EncrypDecrypUtils.encryptH(data, publicKey);
				String encryptedData = encDecModel.getContent();
				String encryptedKey = encDecModel.getKey();
				String requestId = sessVO.getTrcID();
				EAIGWPayload eaiGatewayInputPayload = new EAIGWPayload(requestId, encryptedData, encryptedKey,
						integAddOnReq.getOutboundServiceType());
				integReqAddOn.setInputPayload(eaiGatewayInputPayload);
			} else if (EAIGWConstants.SYMMETRIC_ENCRYPTION.value.equalsIgnoreCase(encryptionType)) {
				String sKey = env.getProperty(payloadEncPropPref + ".SYM.KEY");
				String iv = env.getProperty(payloadEncPropPref + ".SYM.IV");
				String encryptedData = EncrypDecrypUtils.encryptS(data, sKey, iv);
				EAIGWAPayloadSym eaigwaPayloadSym = new EAIGWAPayloadSym(encryptedData);
				integReqAddOn.setInputPayload(eaigwaPayloadSym);
			} else if (EAIGWConstants.HASYMMETRIC_ENCRYPTION.value.equalsIgnoreCase(encryptionType)) {
				String publicKey = env.getProperty(payloadEncPropPref + ".HASYM.PUBLICKEY");
				EncDecModel encDecModel = EncrypDecrypUtils.encryptHA(data, publicKey);
				String encryptedData = encDecModel.getContent();
				String encryptedKey = encDecModel.getKey();
				String requestId = sessVO.getTrcID();
				EAIGWPayload eaiGatewayInputPayload = new EAIGWPayload(requestId, encryptedData, encryptedKey,
						integAddOnReq.getOutboundServiceType());
				AppLogger.debug(sessVO,
						"Encrypted req data: " + jsonUtil.serializeJSONObj(sessVO, eaiGatewayInputPayload));
				integReqAddOn.setInputPayload(eaiGatewayInputPayload);
			}
		} else {
			integReqAddOn.setInputPayload(integReqAddOn.getInputPayload());
		}

		String isApiKeyEnabled = env.getProperty("FSL.EAIGATEWAY.APIKEY." + integReqAddOn.getRequestSource() + ".FLAG");

		if (GenericUtil.isNeitherNullNorEmpty(isApiKeyEnabled) && isApiKeyEnabled.equalsIgnoreCase("1")) {
			String apiKeyName = env.getProperty("FSL.EAIGATEWAY." + integReqAddOn.getRequestSource() + ".APIKEY.name");
			apiKeyName = GenericUtil.isNeitherNullNorEmpty(apiKeyName) ? apiKeyName : "apikey";

			String apiKeyValue = env.getProperty("FSL.EAIGATEWAY." + integReqAddOn.getRequestSource() + ".APIKEY");
			
      if (!excludeCorpOauthSystems.contains(integReqAddOn.getRequestSource())) {
        String checkOAuthEnabled = GenericUtil.isNullOrEmpty(svcId) ? "" : oAuthUtil.checkOAuthEnabled(svcId);
        
        if ("1".equalsIgnoreCase(checkOAuthEnabled)) {
          apiKeyValue = env.getProperty("FSL.EAIGATEWAY." + svcId + ".APIKEY");
          
          if (GenericUtil.isNullOrEmpty(apiKeyValue)) {
            apiKeyValue = env.getProperty("FSL.EAIGATEWAY." + integReqAddOn.getRequestSource() + ".APIKEY");
            
          }
        }
      }

      integReqAddOn.addHeader(apiKeyName, apiKeyValue);
    }
		
		integReqAddOn.setBypassInvoke(integReqAddOn.isBypassInvoke());
		integReqAddOn.setDynamicUrl(integReqAddOn.getDynamicUrl());

		return integReqAddOn;
	}
	
	private String prepare_EAIGW_OB_response_helper(ISessionVO sessVO,
			IntegrationResponseAddOn<?> responseAddOn, IntegrationRequestAddOn<?> integrationRequestAddOn){
		
		String payloadEncPropPref = "FSL.EAIGATEWAY.ENCRYPTION." + integrationRequestAddOn.getRequestSource();
		String isEncryptionEnabled = env.getProperty(payloadEncPropPref + ".FLAG");
		String plainRespData = null;

		if ("1".equalsIgnoreCase(isEncryptionEnabled)) {
			String encryptionType = env.getProperty(payloadEncPropPref + ".TYPE", "");
			AppLogger.debug(sessVO, "Encrypted res data: " + responseAddOn.getOutputPayload().toString());
			AppLogger.debug(sessVO, "Decrypting payload with type " + encryptionType);

			if (EAIGWConstants.HSYMMETRIC_ENCRYPTION.value.equalsIgnoreCase(encryptionType)) {
				EAIGWPayload eaigatewayOutputPayload = null;

				try {
					eaigatewayOutputPayload = jsonUtil.convert_String_to_BaseModel(sessVO,
							responseAddOn.getOutputPayload().toString(), EAIGWPayload.class);
				} catch (SystemException e) {
					AppLogger.error(sessVO, e.getErrorMessage(), e);
					throw new SystemException(FwkResponseStatus.ERROR_IN_EAI_RESPONSE,
							"EAIGateway API return invalid responsePayload: " + e.getErrorMessage());
				}

				if (!eaigatewayOutputPayload.getRequestId()
						.equals(((EAIGWPayload) integrationRequestAddOn.getInputPayload()).getRequestId())) {
					throw new SystemException(FwkResponseStatus.ERROR_IN_EAI_RESPONSE,
							"RequestId in EAIGateway responseBody does not match with the request");
				}

				String privateKey = env.getProperty(payloadEncPropPref + ".HSYM.PRIVATEKEY");
				EncDecModel encDecModel = EncrypDecrypUtils.decryptH(privateKey,
						eaigatewayOutputPayload.getEncryptedKey(), eaigatewayOutputPayload.getEncryptedData());
				plainRespData = encDecModel.getContent();
				// outputData = eaiOutputDataType == null ? null
				// : jsonUtil.convert_String_to_ListofBaseModel_OR_BaseModel(sessVO,
				// decryptedData, eaiOutputDataType);
			} else if (EAIGWConstants.SYMMETRIC_ENCRYPTION.value.equalsIgnoreCase(encryptionType)) {
				EAIGWAPayloadSym eaigatewayOutputPayloadSym = null;
				try {
					eaigatewayOutputPayloadSym = jsonUtil.convert_String_to_BaseModel(sessVO,
							responseAddOn.getOutputPayload().toString(), EAIGWAPayloadSym.class);
				} catch (SystemException e) {
					AppLogger.error(sessVO, e.getErrorMessage(), e);
					throw new SystemException(FwkResponseStatus.ERROR_IN_EAI_RESPONSE,
							"EAIGateway API return invalid responsePayload: " + e.getErrorMessage());

					// new
					// MWResponse<>(sessVO,FwkResponseStatus.ERROR_IN_EAI_RESPONSE,Arrays.asList("EAIGateway
					// API return invalid responsePayload: " +e.getErrorMessage()));
				}

				String sKey = env.getProperty(payloadEncPropPref + ".SYM.KEY");
				String iv = env.getProperty(payloadEncPropPref + ".SYM.IV");
				plainRespData = EncrypDecrypUtils.decryptS(eaigatewayOutputPayloadSym.getData(), sKey, iv);
				// outputData = eaiOutputDataType == null ? null
				// : jsonUtil.convert_String_to_ListofBaseModel_OR_BaseModel(sessVO,
				// decryptedData, eaiOutputDataType);
			} else if (EAIGWConstants.HASYMMETRIC_ENCRYPTION.value.equalsIgnoreCase(encryptionType)) {
				EAIGWPayload eaigatewayOutputPayload = null;

				try {
					eaigatewayOutputPayload = jsonUtil.convert_String_to_BaseModel(sessVO,
							responseAddOn.getOutputPayload().toString(), EAIGWPayload.class);
				} catch (SystemException e) {
					AppLogger.error(sessVO, e.getErrorMessage(), e);
					throw new SystemException(FwkResponseStatus.ERROR_IN_EAI_RESPONSE,
							"EAIGateway API return invalid responsePayload: " + e.getErrorMessage());
				}

				/*
				 * if (!eaigatewayOutputPayload.getRequestId() .equals(((EAIGWPayload)
				 * integrationRequestAddOn.getInputPayload()).getRequestId())) { throw new
				 * SystemException(FwkResponseStatus.ERROR_IN_EAI_RESPONSE,
				 * "RequestId in EAIGateway responseBody does not match with the request"); }
				 */

				String privateKey = env.getProperty(payloadEncPropPref + ".HASYM.PRIVATEKEY");
				EncDecModel encDecModel = EncrypDecrypUtils.decryptHA(privateKey,
						eaigatewayOutputPayload.getEncryptedKey(), eaigatewayOutputPayload.getEncryptedData());
				plainRespData = encDecModel.getContent();
				// outputData = eaiOutputDataType == null ? null
				// : jsonUtil.convert_String_to_ListofBaseModel_OR_BaseModel(sessVO,
				// decryptedData, eaiOutputDataType);
			}
		} else {
			plainRespData = responseAddOn.getOutputPayload().toString();
			// outputData = eaiOutputDataType == null ? null
			// : jsonUtil.convert_String_to_ListofBaseModel_OR_BaseModel(sessVO,
			// responseAddOn.getOutputPayload().toString(),
			// eaiOutputDataType);
		}
		AppLogger.debug(sessVO, "Plain Resp Data: " + plainRespData);
		
		return plainRespData;
		
	}
	
	protected EAIGWIntegrationResAddOn<?> prepare_EAIGW_OB_response_OnFailure(ISessionVO sessVO,
			IntegrationResponseAddOn<?> responseAddOn, IntegrationRequestAddOn<?> integrationRequestAddOn) {
		
		EAIGWIntegrationResAddOn<?> eaigwIntegResAddOn=null;
		
		String plainRespData = prepare_EAIGW_OB_response_helper(sessVO, responseAddOn, integrationRequestAddOn);

		eaigwIntegResAddOn = new EAIGWIntegrationResAddOn<>(sessVO, plainRespData, responseAddOn.getStatusCode());
		
		
		if (GenericUtil.isNeitherNullNorEmpty(responseAddOn.getErrorReason())) {
			eaigwIntegResAddOn.setErrorReason(responseAddOn.getErrorReason());
		}
		if (GenericUtil.isNeitherNullNorEmpty(responseAddOn.getHeadersMap())) {
			eaigwIntegResAddOn.setHeadersMap(responseAddOn.getHeadersMap());
		}

		return eaigwIntegResAddOn;
	}

	protected EAIGWIntegrationResAddOn<?> prepare_EAIGW_OB_response(ISessionVO sessVO,
			IntegrationResponseAddOn<?> responseAddOn, IntegrationRequestAddOn<?> integrationRequestAddOn,
			Class<? extends BaseModel> eaiOutputDataType) {
		
		Object outputData = null;
		EAIGWIntegrationResAddOn<?> eaigwIntegResAddOn=null;
		
		String plainRespData = prepare_EAIGW_OB_response_helper(sessVO, responseAddOn, integrationRequestAddOn);
		
    if (GenericUtil.isNeitherNullNorEmpty(eaiOutputDataType)) {
      try {
        outputData = jsonUtil.convert_String_to_ListofBaseModel_OR_BaseModel(sessVO, plainRespData, eaiOutputDataType);
      }
      catch (Exception ex) {
        AppLogger.error(sessVO, "Exception occurred during the eaiOutputDataType conversion", ex);
      }
    }
		eaigwIntegResAddOn = new EAIGWIntegrationResAddOn<>(sessVO, outputData, responseAddOn.getStatusCode());
		eaigwIntegResAddOn.setErrorReason(responseAddOn.getErrorReason());
		eaigwIntegResAddOn.setHeadersMap(responseAddOn.getHeadersMap());

		return eaigwIntegResAddOn;
	}
}
