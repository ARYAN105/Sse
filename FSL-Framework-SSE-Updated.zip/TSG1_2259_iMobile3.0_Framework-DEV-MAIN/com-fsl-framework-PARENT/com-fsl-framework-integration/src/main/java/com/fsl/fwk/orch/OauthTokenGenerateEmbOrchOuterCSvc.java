package com.fsl.fwk.orch;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.integration.oauth.OauthTokenFetchIResBody;
import com.fsl.fwk.orch.constants.OauthTokenGenerateEmbOrchOuterCConstants;
import com.fsl.fwk.orch.oauth.OauthTokenGetCResBody;
import com.fsl.fwk.utils.OAuthUtil;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.constants.ResponseStatus;
import com.tcs.fwk.integration.MWOrchestratedChainService;
import com.tcs.fwk.integration.OrchestrationHelper;
import com.tcs.fwk.integration.ServiceRequestAddOn;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequest;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.orchestration.OrchestrationConstants;
import com.tcs.fwk.orchestration.chain.PrepareRequestChain;
import com.tcs.fwk.orchestration.chain.ServiceEvaluation;
import com.tcs.fwk.orchestration.vo.ServiceData;
import com.tcs.fwk.orchestration.vo.TouchedServiceInfoVO;
import com.tcs.fwk.service.IEmbeddedOrchOUTERMWService;
import com.tcs.fwk.service.exception.CustomValidationException;
import com.tcs.fwk.service.model.MWResponseBodyType;
import com.tcs.fwk.service.model.PayloadType;
import com.tcs.fwk.util.GenericUtil;

/**
 * Base framework
 *
 * @author Tata Consultancy Services
 * @author ban474608
 */
@Service
public class OauthTokenGenerateEmbOrchOuterCSvc extends MWOrchestratedChainService
    implements IEmbeddedOrchOUTERMWService, OauthTokenGenerateEmbOrchOuterCConstants, FSLConstants,
    OrchestrationConstants {
  
  @Autowired
  OrchestrationHelper orchHelper;
  
  @Autowired
  OAuthUtil oAuthUtil;
  
  @Override
  public BaseModel customValidations(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn addOn)
      throws CustomValidationException {
    return null;
  }
  
  private boolean checkOauthTokenHeader(IMWRequestAddOn mwRequestAddOn) {
    return GenericUtil.isNeitherNullNorEmpty(mwRequestAddOn.getHeadersMap().get(HEADER_OAUTH_TOKEN));
  }
  
  @Override
  protected Map<String, ServiceEvaluation> eval() {
    Map<String, ServiceEvaluation> serviceEvalMap = new HashMap<>();
    
    serviceEvalMap.put(OauthTokenGenerateEmbOrch_Svc, (sessVO, orchInputParams) -> {
      String evalsTo = null;
      
      // added for find out whether in fwk already oauthTokenCall happen or not if yes no need to call again
      if (checkOauthTokenHeader(orchInputParams.mwRequestAddOn)) {
        evalsTo = WTOOAUTH;
      }
      else {
        String serviceId       = getEmbOrchInnerMWServiceID(orchInputParams.mwRequestAddOn);
        String oauthEnableFlag = oAuthUtil.checkOAuthEnabled(serviceId);
        
        evalsTo = ("1".equalsIgnoreCase(oauthEnableFlag)) ? OAUTHCHK : WTOOAUTH;
      }
      
      return evalsTo;
    });
    
    serviceEvalMap.put(OAUTH_TKN_ORCH_SVC, (sessVO, orchInputParams) -> {
      String evalsTo = null;
      
      MWResponse<OauthTokenFetchIResBody> oauthTokenGetCResBody = orchHelper.getMWResponse_from_MapSvcData(
          orchInputParams.mapServiceData, OAUTH_TKN_ORCH_SVC, orchInputParams.svcSuffix, null);
      
      if (FwkResponseStatus.SUCCESS.getCode() == oauthTokenGetCResBody.getStatusCd()) {
        evalsTo = SUCCESS;
      }
      
      return evalsTo;
    });
    
    return serviceEvalMap;
  }
  
  @Override
  protected Map<String, PrepareRequestChain> prepare_ChainRequest() {
    Map<String, PrepareRequestChain> chainRequestMap = new HashMap<>();
    
    chainRequestMap.put(OAUTH_TKN_ORCH_SVC, (sessVO, dynaSuffix, orchInputParams) -> {
      return new ServiceRequestAddOn<>(new MWRequest<>());
    });
    
    chainRequestMap.put(OrchestrationConstants.EMBEDDED_ORCH_SVC_STR,
        (sessVO, dynaSuffix, orchInputParams) -> {
          ServiceRequestAddOn<?> serviceReqAddOn = null;
          
          MWRequest<Object> embOrchSvcReq = new MWRequest<>();
          embOrchSvcReq.setBody(orchInputParams.mwRequestOrch.getBody());
          
          //REFRESH_FLAG - In case refresh head added to any service, REFRESH_FLAG_IGNORE - bypass the refresh head for fwk internal services
          if (!orchInputParams.mwRequestAddOn.getHeadersMap().containsKey(FSLConstants.REFRESH_FLAG_IGNORE) &&
              orchInputParams.mwRequestAddOn.getHeadersMap().containsKey(FSLConstants.REFRESH_FLAG)) {
            embOrchSvcReq.getHead().setRefresh(orchInputParams.mwRequestAddOn.getHeadersMap().get(FSLConstants.REFRESH_FLAG).get(0));
            orchInputParams.mwRequestAddOn.getHeadersMap().remove(FSLConstants.REFRESH_FLAG);
          }
         
          serviceReqAddOn = new ServiceRequestAddOn<>(embOrchSvcReq);
          
          if (orchInputParams.enteringSvcSuffix.equalsIgnoreCase(SUCCESS)) {
            serviceReqAddOn.addHeader(FSLConstants.HEADER_OAUTH_TOKEN,
                FSLConstants.BEARER_PFX + ((OauthTokenGetCResBody) orchHelper.getMWResPayload_from_MapSvcData(
                    orchInputParams.mapServiceData, orchInputParams.exitingSvcId,
                    orchInputParams.exitingSvcSuffix, null)).getAccessToken());
          }
          
          return serviceReqAddOn;
        });
    
    return chainRequestMap;
  }
  
  @Override
  protected MWResponse<?> prepare_MW_response(ISessionVO sessVO, Map<String, ServiceData> mapServiceData,
      Map<String, TouchedServiceInfoVO> mapInstruDataVoServiceKeysTouched, ResponseStatus statusDerivedByFwk,
      IMWRequest<?> mwRequestOrch, IMWRequestAddOn mwRequestAddOn, BaseModel extraData) {
    MWResponse<Object> mwResponse          = new MWResponse<>(sessVO, statusDerivedByFwk, null);
    String             embOrchInnerMWSvcID = getEmbOrchInnerMWServiceID(mwRequestAddOn);
    
    if (statusDerivedByFwk == FwkResponseStatus.ORCH_ALL_FAILED) {
      mwResponse = new MWResponse<>(sessVO, statusDerivedByFwk, null);
    }
    
    TouchedServiceInfoVO oauthTokenGetCResBodyLGNTouchedInfo = mapInstruDataVoServiceKeysTouched
        .get(orchHelper.getServiceKey(OAUTH_TKN_ORCH_SVC, null, null));
    if (oauthTokenGetCResBodyLGNTouchedInfo != null) {
      mwResponse = orchHelper.getMWResponse_from_MapSvcData(mapServiceData, OAUTH_TKN_ORCH_SVC, null,
          null);
      if (mwResponse.getStatusCd() != FwkResponseStatus.SUCCESS.getCode()) {
        mwResponse.setMsgCds(null);
        mwResponse.setStatusCd(FwkResponseStatus.EAI_LOGIN_FAILED);
      }
    }
    
    TouchedServiceInfoVO dynaSvcResBody1TouchedInfo = mapInstruDataVoServiceKeysTouched
        .get(orchHelper.getServiceKey(embOrchInnerMWSvcID, SUCCESS, null));
    if (dynaSvcResBody1TouchedInfo != null) {
      mwResponse = orchHelper.getMWResponse_from_MapSvcData(mapServiceData, embOrchInnerMWSvcID, SUCCESS,
          null);
      
    }
    
    TouchedServiceInfoVO dynaSvcResBody2TouchedInfo = mapInstruDataVoServiceKeysTouched
        .get(orchHelper.getServiceKey(embOrchInnerMWSvcID, WTOOAUTH, null));
    
    if (dynaSvcResBody2TouchedInfo != null) {
      mwResponse = orchHelper.getMWResponse_from_MapSvcData(mapServiceData, embOrchInnerMWSvcID, WTOOAUTH,
          null);
      
    }
    
    return mwResponse;
  }
  
  @Override
  protected Class<? extends BaseModel> myRequestBodyType() {
    return null;
  }
  
  @Override
  protected Map<String, PayloadType> innerServiceOutputPayloadTypes() {
    Map<String, PayloadType> innerSvcOutputPayloadTypes = new HashMap<>();
    
    innerSvcOutputPayloadTypes.put(OAUTH_TKN_ORCH_SVC, new MWResponseBodyType(OauthTokenGetCResBody.class));
    
    return innerSvcOutputPayloadTypes;
  }
  
}
