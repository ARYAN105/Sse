package com.fsl.fwk.orch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.constants.FSLResponseStatus;
import com.fsl.fwk.constants.FSLStatusConstants;
import com.fsl.fwk.constants.FSLStatusConstants.ValidationStatus;
import com.fsl.fwk.controller.model.FSLError;
import com.fsl.fwk.utils.FSLHelper;
import com.fsl.fwk.utils.HashUtil;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.constants.ResponseStatus;
import com.tcs.fwk.integration.MWOrchestratedChainService;
import com.tcs.fwk.integration.OrchestrationHelper;
import com.tcs.fwk.integration.ServiceRequestAddOn;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequest;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.orchestration.chain.PrepareRequestChain;
import com.tcs.fwk.orchestration.chain.ServiceEvaluation;
import com.tcs.fwk.orchestration.vo.ServiceData;
import com.tcs.fwk.orchestration.vo.TouchedServiceInfoVO;
import com.tcs.fwk.service.IEmbeddedOrchOUTERMWService;
import com.tcs.fwk.service.exception.CustomValidationException;
import com.tcs.fwk.service.model.PayloadType;
import com.tcs.fwk.util.GenericUtil;

/**
 * @author Dineshkumar Panchalingam
 * @author Tata Consultancy Services
 */
@Service
public class FslEAIGWIntegrationDynaEmbOrchOuterCSvc extends MWOrchestratedChainService
		implements IEmbeddedOrchOUTERMWService {

	@Autowired
	OrchestrationHelper orchHelper;
	
	@Autowired
  HashUtil hashutil;
	
	@Autowired
	FSLHelper fslHelper;

	private static final String FslEAIGWIntegrationDynaEmbOrchOuterC_STR = "FslEAIGWIntegrationDynaEmbOrchOuterC";
	private static final String OauthTokenGenerateEmbOrchOuterC_STR="OauthTokenGenerateEmbOrchOuterC";
	private static final String FslSecurityCheckG_STR = "FslSecurityCheckG";
	private static final String INTERNAL = "INTERNAL";
	private static final String APP = "APP";
	private static final String APP_VALIDATED = "APP_VALIDATED";
	
	@Override
	public BaseModel customValidations(ISessionVO arg0, IMWRequest<?> arg1, IMWRequestAddOn arg2)
			throws CustomValidationException {
		return null;
	}
	
	@Override
	protected Map<String, ServiceEvaluation> eval() {

		Map<String, ServiceEvaluation> serviceEvalMap = new HashMap<>();
		serviceEvalMap.put(FslEAIGWIntegrationDynaEmbOrchOuterC_STR, (sessVO, evalOrchInputParams) -> {
			
      String refreshFlag = evalOrchInputParams.mwRequestOrch.getHead().getRefresh();
			
			if(GenericUtil.isNeitherNullNorEmpty(refreshFlag)) {
				evalOrchInputParams.mwRequestAddOn.getHeadersMap().put(FSLConstants.REFRESH_FLAG, List.of(evalOrchInputParams.mwRequestOrch.getHead().getRefresh()));				
				evalOrchInputParams.mwRequestOrch.getHead().setRefresh(null);
			}
      String hashFlagEnabled = hashutil.checkHashReplayEnabled(getEmbOrchInnerMWServiceID(evalOrchInputParams.mwRequestAddOn));
			Map<String, List<String>> headersMap = evalOrchInputParams.mwRequestAddOn.getHeadersMap();
			if (GenericUtil.isNeitherNullNorEmpty(headersMap.get(FSLConstants.IS_VALIDATED))
					|| GenericUtil.isNeitherNullNorEmpty(headersMap.get(FSLConstants.TXN_ID.toLowerCase()))) {
				return INTERNAL;
			} else {
				if (GenericUtil.isNeitherNullNorEmpty(headersMap.get(FSLConstants.HEADER_HASH)) && FSLConstants.HASH_ENABLED.equals(hashFlagEnabled) 
				        && Boolean.TRUE.equals(hashutil.isValidAppVersionFormat(headersMap.get(FSLConstants.HEADER_VERSION.toLowerCase()).get(0),sessVO)
				        && Boolean.TRUE.equals(hashutil.isValidAppVersion(headersMap.get(FSLConstants.HEADER_VERSION.toLowerCase()).get(0),headersMap.get(FSLConstants.HEADER_OSTYPE.toLowerCase()).get(0), sessVO)))){
					return APP;
				}
				return INTERNAL;
			}
		});

		serviceEvalMap.put(FslSecurityCheckG_STR, (sessVO, evalOrchInputParams) -> {
			MWResponse<Object> resp = orchHelper.getMWResponse_from_MapSvcData(evalOrchInputParams.mapServiceData, FslSecurityCheckG_STR, null, null);
			String isCachedResp = resp.getHead().getCache();
			
			if(GenericUtil.isNeitherNullNorEmpty(isCachedResp) && "1".equals(isCachedResp)) {
				AppLogger.error(sessVO, "Duplicate Request Identified with trcID : " + sessVO.getTrcID(), null);
				return null;
			}
			
			AppLogger.info(sessVO, "Valid Request Identified with tcrID : "+sessVO.getTrcID());
			
			return APP_VALIDATED;
		});

		return serviceEvalMap;
	}

	@Override
	protected Map<String, PrepareRequestChain> prepare_ChainRequest() {
		Map<String, PrepareRequestChain> chainRequestMap = new HashMap<>();
		
		chainRequestMap.put(FslSecurityCheckG_STR, (sessVO, dynaSuffix, orchInputParams) ->  new ServiceRequestAddOn<>(new MWRequest<>()));
		
		chainRequestMap.put(OauthTokenGenerateEmbOrchOuterC_STR, (sessVO, dynaSuffix, orchInputParams) -> {
			
			MWRequest<Object> mwRequest = new MWRequest<>();
			mwRequest.setBody(orchInputParams.mwRequestOrch.getBody());
			
			if(orchInputParams.enteringSvcSuffix.equals(APP)) {
				orchInputParams.mwRequestAddOn.getHeadersMap().put(FSLConstants.IS_VALIDATED, List.of("true"));
			}
			
		  return new ServiceRequestAddOn<>(mwRequest);
			
		});
		
		return chainRequestMap;
	}


	@Override
	protected MWResponse<?> prepare_MW_response(ISessionVO sessVO, Map<String, ServiceData> mapServiceData, Map<String, TouchedServiceInfoVO> mapInstruDataVO_serviceKeysTouched, 
			ResponseStatus status_derivedByFwk, IMWRequest<?> mwRequestOrch, IMWRequestAddOn mwRequestAddOn, BaseModel extraData) {
		
		MWResponse<Object> mwResponse = new MWResponse<>(sessVO, status_derivedByFwk, null);
	
		TouchedServiceInfoVO genericSecurityCheckTouchedInfo = mapInstruDataVO_serviceKeysTouched.get(orchHelper.getServiceKey(FslSecurityCheckG_STR, null, null));
		if (GenericUtil.isNeitherNullNorEmpty(genericSecurityCheckTouchedInfo)) {
			mwResponse = orchHelper.getMWResponse_from_MapSvcData(mapServiceData, FslSecurityCheckG_STR, null, null);
			if("1".equals(mwResponse.getHead().getCache())) {
				mwResponse = new MWResponse<>(sessVO, FSLResponseStatus.FSL_SECURITY_VALIDATION_FAILED, null);
				mwResponse.setMsgCds(List.of(ValidationStatus.DUPLICATE_REQUEST.getErrString()));
			}
		}

		TouchedServiceInfoVO dynamicSvc1TouchedInfo = mapInstruDataVO_serviceKeysTouched.get(orchHelper.getServiceKey(OauthTokenGenerateEmbOrchOuterC_STR, APP, null));
		if (GenericUtil.isNeitherNullNorEmpty(dynamicSvc1TouchedInfo)) {
			mwResponse = orchHelper.getMWResponse_from_MapSvcData(mapServiceData, OauthTokenGenerateEmbOrchOuterC_STR, APP, null);
		}
		
		TouchedServiceInfoVO dynamicSvc2TouchedInfo = mapInstruDataVO_serviceKeysTouched.get(orchHelper.getServiceKey(OauthTokenGenerateEmbOrchOuterC_STR, INTERNAL, null));
		if (GenericUtil.isNeitherNullNorEmpty(dynamicSvc2TouchedInfo)) {
			mwResponse = orchHelper.getMWResponse_from_MapSvcData(mapServiceData, OauthTokenGenerateEmbOrchOuterC_STR, INTERNAL, null);
		}
		
    Map<String, Object> meta = new HashMap<>();
    
    if (GenericUtil.isNeitherNullNorEmpty(mwResponse)
        && GenericUtil.isNeitherNullNorEmpty(mwResponse.getMsgCds()) && (!mwResponse.getMsgCds().isEmpty())) {
      List<String> msgCdStringList = mwResponse.getMsgCds();
      if (mwResponse.getStatusCd() == FwkResponseStatus.INPUT_VALIDATION_CUSTOM_FAILED.getCode()) {
        msgCdStringList = fslHelper.parseMsgCds(msgCdStringList);
      }
      fslHelper.updateResMeta(sessVO, msgCdStringList, meta);
      mwResponse.setMsgCds(null);
    }
    if (!meta.isEmpty()) {
      
      List<FSLError> fslErrorList = (List<FSLError>) meta.get(FSLStatusConstants.ERRORS_MSG_KEY);
      
      List<Map<String, String>> convertValue = mapper.convertValue(fslErrorList,
          new TypeReference<List<Map<String, String>>>() {
          });
      
      meta.put(FSLStatusConstants.ERRORS_MSG_KEY, convertValue);
      mwResponse.setMeta(meta);
    }
    
		return mwResponse;
	}
	

	@Override
	protected Class<? extends BaseModel> myRequestBodyType() {
		return null;
	}
	
	@Override
	protected Map<String, PayloadType> innerServiceOutputPayloadTypes() {
		return new HashMap<>();
	}
}
