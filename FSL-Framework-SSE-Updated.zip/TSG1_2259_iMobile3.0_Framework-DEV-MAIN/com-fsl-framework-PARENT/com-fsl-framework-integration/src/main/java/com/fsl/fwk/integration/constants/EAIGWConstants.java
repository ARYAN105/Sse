package com.fsl.fwk.integration.constants;

public enum EAIGWConstants {

	RESOURCE_DEH("DEH"), 
	RESOURCE_UPI("UPI"),
	RESOURCE_DEFAULT("PLAIN"),
	SYMMETRIC_ENCRYPTION("SYM"),
	ASYMMETRIC_ENCRYPTION("ASYM"),
	HSYMMETRIC_ENCRYPTION("HSYM"),
    HASYMMETRIC_ENCRYPTION("HASYM"),
	RESOURCE_PRIME("PRIME"),
	RESOURCE_ICORE("ICORE");

	public final String value;

	private EAIGWConstants(String value) {
		this.value = value;
	}
	
}
