package com.fsl.fwk.integration;

import com.tcs.fwk.model.BaseModel;

/**
 * @author Nikhil Bhumkar
 * @author Tata Consultancy Services
 */
public class EAIGWAPayloadSym extends BaseModel {

	private static final long serialVersionUID = "com.fsl.fwk.integration.EAIGWAPayloadSym".hashCode();

	private String data = null;

	public EAIGWAPayloadSym(String data) {
		super();
		this.setData(data);
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

}
