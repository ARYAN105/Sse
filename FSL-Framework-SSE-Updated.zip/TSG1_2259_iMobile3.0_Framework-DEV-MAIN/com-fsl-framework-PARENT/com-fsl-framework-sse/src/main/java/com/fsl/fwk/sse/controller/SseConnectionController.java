package com.fsl.fwk.sse.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.fsl.fwk.sse.manager.SseConnectionManager;

/** HTTP entry point used by UI clients to establish an SSE stream. */
@RestController
@RequestMapping(SseConnectionController.BASE_PATH)
public class SseConnectionController {

    public static final String BASE_PATH = "/fsl/sse";
    public static final String STREAM_PATH = BASE_PATH + "/stream";

    private final SseConnectionManager connectionManager;

    public SseConnectionController(SseConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public ResponseEntity<SseEmitter> stream() {
        SseEmitter emitter = connectionManager.openConnection();
        return ResponseEntity.ok()
                .header(HttpHeaders.CACHE_CONTROL, "no-cache")
                .header("X-Accel-Buffering", "no")
                .body(emitter);
    }
}
