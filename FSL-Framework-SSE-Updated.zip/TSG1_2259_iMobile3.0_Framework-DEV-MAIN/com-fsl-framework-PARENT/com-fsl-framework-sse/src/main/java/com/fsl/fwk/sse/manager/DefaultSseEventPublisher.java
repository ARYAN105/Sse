package com.fsl.fwk.sse.manager;

import java.util.Objects;

import com.fsl.fwk.sse.api.SseEvent;
import com.fsl.fwk.sse.api.SseEventPublisher;

/** Default publisher backed by the local connection manager. */
public class DefaultSseEventPublisher implements SseEventPublisher {

    private final SseConnectionManager connectionManager;

    public DefaultSseEventPublisher(SseConnectionManager connectionManager) {
        this.connectionManager = Objects.requireNonNull(connectionManager, "connectionManager");
    }

    @Override
    public void publish(SseEvent event) {
        connectionManager.publish(event);
    }
}
