package com.fsl.fwk.sse.api;

import java.util.Objects;
import java.util.UUID;

/**
 * Immutable event sent to all SSE connections held by this application instance.
 * Keep payloads free of secrets and personal data unless recipient-level routing
 * and authorization have been implemented by the hosting application.
 */
public final class SseEvent {

    private final String id;
    private final String name;
    private final Object data;

    public SseEvent(String name, Object data) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("SSE event name must not be blank");
        }
        this.id = UUID.randomUUID().toString();
        this.name = name;
        this.data = Objects.requireNonNull(data, "SSE event data must not be null");
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Object getData() {
        return data;
    }
}
