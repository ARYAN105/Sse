package com.fsl.fwk.sse.api;

/**
 * In-process publishing contract for FSL services.
 * Implementations publish to SSE clients connected to the same application instance.
 */
public interface SseEventPublisher {

    void publish(SseEvent event);
}
