package com.fsl.fwk.sse.manager;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.http.MediaType;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.fsl.fwk.sse.api.SseEvent;

/**
 * Holds the SSE connections for this JVM. Each application replica has its own
 * connection map; this class deliberately does not introduce distributed state.
 */
public class SseConnectionManager {

    private final Map<String, SseEmitter> connections = new ConcurrentHashMap<>();

    public SseEmitter openConnection() {
        String connectionId = UUID.randomUUID().toString();
        SseEmitter emitter = new SseEmitter(0L);

        connections.put(connectionId, emitter);

        emitter.onCompletion(() -> removeConnection(connectionId, emitter));
        emitter.onTimeout(() -> removeConnection(connectionId, emitter));
        emitter.onError(error -> removeConnection(connectionId, emitter));

        try {
            emitter.send(SseEmitter.event()
                    .name("CONNECTED")
                    .data(Map.of("connectionId", connectionId), MediaType.APPLICATION_JSON));
        } catch (IOException | IllegalStateException exception) {
            removeConnection(connectionId, emitter);
            try {
                emitter.completeWithError(exception);
            } catch (IllegalStateException ignored) {
                // The emitter may already have completed while the send was failing.
            }
        }

        return emitter;
    }

    public void publish(SseEvent event) {
        if (event == null) {
            throw new IllegalArgumentException("SSE event must not be null");
        }

        for (Map.Entry<String, SseEmitter> connection : connections.entrySet()) {
            String connectionId = connection.getKey();
            SseEmitter emitter = connection.getValue();

            try {
                emitter.send(SseEmitter.event()
                        .id(event.getId())
                        .name(event.getName())
                        .data(event.getData(), MediaType.APPLICATION_JSON));
            } catch (IOException | IllegalStateException exception) {
                removeConnection(connectionId, emitter);
                try {
                    emitter.completeWithError(exception);
                } catch (IllegalStateException ignored) {
                    // A concurrent completion is harmless; the connection is already removed.
                }
            }
        }
    }

    public int getActiveConnectionCount() {
        return connections.size();
    }

    private void removeConnection(String connectionId, SseEmitter emitter) {
        connections.remove(connectionId, emitter);
    }
}
