package com.fsl.fwk.sse.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fsl.fwk.sse.api.SseEventPublisher;
import com.fsl.fwk.sse.controller.SseConnectionController;
import com.fsl.fwk.sse.manager.DefaultSseEventPublisher;
import com.fsl.fwk.sse.manager.SseConnectionManager;

/** Registers the reusable SSE components in the host microservice context. */
@Configuration(proxyBeanMethods = false)
public class SseConnectionConfig {

    @Bean
    public SseConnectionManager sseConnectionManager() {
        return new SseConnectionManager();
    }

    @Bean
    public SseEventPublisher sseEventPublisher(SseConnectionManager connectionManager) {
        return new DefaultSseEventPublisher(connectionManager);
    }

    @Bean
    public SseConnectionController sseConnectionController(SseConnectionManager connectionManager) {
        return new SseConnectionController(connectionManager);
    }
}
