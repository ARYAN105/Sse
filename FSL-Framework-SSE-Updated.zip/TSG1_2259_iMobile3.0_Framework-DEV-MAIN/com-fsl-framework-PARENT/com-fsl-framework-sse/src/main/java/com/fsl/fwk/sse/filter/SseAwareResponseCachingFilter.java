package com.fsl.fwk.sse.filter;

import java.io.IOException;
import java.util.List;

import org.springframework.web.util.ContentCachingResponseWrapper;

import com.fsl.fwk.sse.controller.SseConnectionController;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Preserves the TCS MyFilter hostname check and response-copy behavior for normal
 * requests, but does not cache the long-lived SSE response.
 */
public class SseAwareResponseCachingFilter implements Filter {

    private final List<String> allowedHostnames;
    private final String streamPath;

    public SseAwareResponseCachingFilter(List<String> allowedHostnames, String streamPath) {
        this.allowedHostnames = List.copyOf(allowedHostnames);
        this.streamPath = streamPath;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        if (isSseStreamRequest(httpRequest)) {
            // Do not wrap/cache this response. SSE must be written to the client as events arrive.
            String hostname = request.getServerName();
            if (!allowedHostnames.contains("*") && !allowedHostnames.contains(hostname)) {
                httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN);
            }
            chain.doFilter(request, response);
            return;
        }

        // Retain the same wrapper/check/copy sequence used by the original TCS MyFilter.
        ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(httpResponse);
        String hostname = request.getServerName();
        if (!allowedHostnames.contains("*") && !allowedHostnames.contains(hostname)) {
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN);
        }
        chain.doFilter(request, responseWrapper);
        responseWrapper.copyBodyToResponse();
    }

    private boolean isSseStreamRequest(HttpServletRequest request) {
        String requestUri = request.getRequestURI();
        return requestUri != null && requestUri.endsWith(streamPath);
    }
}
