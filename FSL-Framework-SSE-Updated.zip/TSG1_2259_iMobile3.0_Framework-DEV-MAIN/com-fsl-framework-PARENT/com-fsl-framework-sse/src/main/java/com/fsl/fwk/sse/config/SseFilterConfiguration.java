package com.fsl.fwk.sse.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.env.Environment;

import com.fsl.fwk.sse.controller.SseConnectionController;
import com.fsl.fwk.sse.filter.SseAwareResponseCachingFilter;

import jakarta.servlet.Filter;

/**
 * The TCS MyFilter wraps responses in ContentCachingResponseWrapper and only copies
 * the body after the filter chain returns. That prevents a long-lived SSE response
 * from being flushed incrementally. Replace only its servlet registration with an
 * SSE-aware equivalent; the original MyFilter bean itself remains in the context.
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnClass(name = "com.tcs.fwk.service.MyFilter")
@ConditionalOnBean(name = "myFilter")
public class SseFilterConfiguration {

    @Bean
    public FilterRegistrationBean<Filter> disableTcsMyFilterServletRegistration(
            @Qualifier("myFilter") Filter tcsMyFilter) {
        FilterRegistrationBean<Filter> registration = new FilterRegistrationBean<>();
        registration.setName("disableTcsMyFilterAutoRegistration");
        registration.setFilter(tcsMyFilter);
        registration.setEnabled(false);
        return registration;
    }

    @Bean
    public FilterRegistrationBean<SseAwareResponseCachingFilter> sseAwareTcsMyFilterRegistration(
            Environment environment) {
        String[] configuredHostnames = environment.getProperty(
                "FWK.SERVICE.allowed.hostnames", String[].class, new String[] { "*" });
        List<String> allowedHostnames = Arrays.asList(configuredHostnames);
        String streamPath = environment.getProperty(
                "fsl.sse.stream-path", SseConnectionController.STREAM_PATH);

        SseAwareResponseCachingFilter filter = new SseAwareResponseCachingFilter(
                allowedHostnames, streamPath);

        FilterRegistrationBean<SseAwareResponseCachingFilter> registration = new FilterRegistrationBean<>();
        registration.setName("sseAwareTcsMyFilter");
        registration.setFilter(filter);
        registration.addUrlPatterns("/*");
        registration.setAsyncSupported(true);
        registration.setOrder(Ordered.LOWEST_PRECEDENCE);
        return registration;
    }
}
