package com.fsl.fwk.cache.genericmaster.transformers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fsl.fwk.cache.master.transformers.BillerMstrApiResTransformer;
import com.tcs.fwk.cache.master.transformer.config.IMasterApiResponseTransformer;

@Component("TMFGENERIC_BILLERMSTR_TRANSFORMER")
public class TmfgenericBillerMstrApiResTransformer implements IMasterApiResponseTransformer {

	@Autowired BillerMstrApiResTransformer billerMstrApiResTransformer;
	@Override
	public JsonNode transformMasterJson(String masterName, JsonNode masterJsonNode) {
		return billerMstrApiResTransformer.transformMasterJson(masterName, masterJsonNode);
	}
}
