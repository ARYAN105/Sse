package com.fsl.fwk.cache.genericmaster.transformers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fsl.fwk.cache.master.transformers.BranchMstrApiResTransformer;
import com.tcs.fwk.cache.master.transformer.config.IMasterApiResponseTransformer;

@Component("TMFGENERIC_BRANCHMSTR_TRANSFORMER")
public class TmfgenericBranchMstrApiResTransformer implements IMasterApiResponseTransformer {

	@Autowired
	BranchMstrApiResTransformer branchMstrApiResTransformer;

	@Override
	public JsonNode transformMasterJson(String masterName, JsonNode masterJsonNode) {
		return branchMstrApiResTransformer.transformMasterJson(masterName, masterJsonNode);
	}
}
