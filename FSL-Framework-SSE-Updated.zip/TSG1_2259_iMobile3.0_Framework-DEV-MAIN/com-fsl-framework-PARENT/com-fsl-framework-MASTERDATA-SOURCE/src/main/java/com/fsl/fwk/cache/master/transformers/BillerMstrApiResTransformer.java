package com.fsl.fwk.cache.master.transformers;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.tcs.fwk.cache.master.transformer.config.IMasterApiResponseTransformer;

@Component("BILLERMSTR_TRANSFORMER")
public class BillerMstrApiResTransformer implements IMasterApiResponseTransformer {

	@Override
	public JsonNode transformMasterJson(String masterName, JsonNode masterJsonNode) {
		if(!masterJsonNode.has("billerType")) ((ObjectNode)masterJsonNode).put("billerType", "");
		if(!masterJsonNode.has("tag")) ((ObjectNode)masterJsonNode).put("tag", "");
		return masterJsonNode;	
	}
}