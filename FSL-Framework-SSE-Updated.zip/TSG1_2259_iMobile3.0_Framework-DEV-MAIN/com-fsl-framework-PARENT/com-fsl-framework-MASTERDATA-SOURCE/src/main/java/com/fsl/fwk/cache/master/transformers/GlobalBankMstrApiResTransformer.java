package com.fsl.fwk.cache.master.transformers;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.tcs.fwk.cache.master.transformer.config.IMasterApiResponseTransformer;

@Component("GLOBALBANKMSTR_TRANSFORMER")
public class GlobalBankMstrApiResTransformer implements IMasterApiResponseTransformer {
	
	@Override
	public JsonNode transformMasterJson(String masterName, JsonNode masterJsonNode) {
		
		((ObjectNode)masterJsonNode).put("code_type", "GBKL");
		((ObjectNode)masterJsonNode).put("INSTITUTION_NAME", masterJsonNode.hasNonNull("INSTITUTION_NAME")? masterJsonNode.get("INSTITUTION_NAME").asText().trim().toUpperCase() : null);   
	    return masterJsonNode;
	}	 
		 
}



