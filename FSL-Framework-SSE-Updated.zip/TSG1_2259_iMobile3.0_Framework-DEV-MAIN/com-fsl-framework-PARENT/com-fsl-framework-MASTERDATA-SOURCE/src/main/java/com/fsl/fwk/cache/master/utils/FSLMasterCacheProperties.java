package com.fsl.fwk.cache.master.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.exception.SystemException;

@Component
public class FSLMasterCacheProperties {

	@Autowired private Environment env;
	private static String propPrefix = "FSL.EAIGATEWAY.MASTER.";
	
	public String getPropVal_OrDefault(String dynaID, String key) {
		String propKey = propPrefix + dynaID + key ;
		String defaultPropKey = propPrefix + key ;
		String propVal = env.getProperty(propKey);
		if ((null==propVal)  || propVal.isBlank()) {
			String defaultPropVal = env.getProperty(defaultPropKey.replace("..", "."));
			if ((null==defaultPropVal) || defaultPropVal.isBlank())
				throw new SystemException(FwkResponseStatus.CODING_CONFIG_ERROR, defaultPropKey + " NOT configured");
			return defaultPropVal ;
		} else {
			return propVal;	
		}
	}
	
}
