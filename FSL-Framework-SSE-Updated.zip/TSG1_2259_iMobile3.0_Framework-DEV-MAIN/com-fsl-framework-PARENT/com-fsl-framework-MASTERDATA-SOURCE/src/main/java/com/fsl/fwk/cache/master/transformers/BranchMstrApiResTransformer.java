package com.fsl.fwk.cache.master.transformers;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.tcs.fwk.cache.master.transformer.config.IMasterApiResponseTransformer;

@Component("BRANCHMSTR_TRANSFORMER")
public class BranchMstrApiResTransformer implements IMasterApiResponseTransformer {

	@Override
	public JsonNode transformMasterJson(String masterName, JsonNode masterJsonNode) {
 
		String rn = "", skip = "N";
		if (masterJsonNode.has("routingNumberDetails")) {
			for (JsonNode node : masterJsonNode.get("routingNumberDetails")) {
				if (node != null && !node.has("routingNumber"))
					continue;
				else if (node.has("networkType") && node.get("networkType").has("cmCode")
						&& node.get("networkType").get("cmCode") != null
						&& !node.get("networkType").get("cmCode").asText().equals("MIC")) {
					rn = node.get("routingNumber").asText();
					skip = "N";
					break;
				} else
					skip = "Y";
			}
		}

		skip = ("Y".equals(skip) ? skip : ((rn.length() <= 4) ? "Y" : "N"));
		((ObjectNode) masterJsonNode).put("rn", rn);
		((ObjectNode) masterJsonNode).put("skip", skip);

		return masterJsonNode;
	}

}
