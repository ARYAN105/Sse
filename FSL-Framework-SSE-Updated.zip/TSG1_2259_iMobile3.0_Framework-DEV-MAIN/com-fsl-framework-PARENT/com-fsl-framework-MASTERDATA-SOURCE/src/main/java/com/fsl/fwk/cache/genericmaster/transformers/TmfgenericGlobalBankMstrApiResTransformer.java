package com.fsl.fwk.cache.genericmaster.transformers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fsl.fwk.cache.master.transformers.GlobalBankMstrApiResTransformer;
import com.tcs.fwk.cache.master.transformer.config.IMasterApiResponseTransformer;

@Component("TMFGENERIC_GLOBALBANKMSTR_TRANSFORMER")
public class TmfgenericGlobalBankMstrApiResTransformer implements IMasterApiResponseTransformer {

	@Autowired
	GlobalBankMstrApiResTransformer globalBankMstrApiResTransformer;

	@Override
	public JsonNode transformMasterJson(String masterName, JsonNode masterJsonNode) {
		return globalBankMstrApiResTransformer.transformMasterJson(masterName, masterJsonNode);
	}
}

