package com.fsl.fwk.cache.master.transformers;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.tcs.fwk.cache.master.transformer.config.IMasterApiResponseTransformer;

@Component("POPBANKMSTR_TRANSFORMER")
public class PopBankMstrApiResTransformer implements IMasterApiResponseTransformer {

	@Override
	public JsonNode transformMasterJson(String masterName, JsonNode masterJsonNode) {

		String accountProviderID = null;
		
	    String[] cdDescArr = masterJsonNode.get("codeDescription") != null ? masterJsonNode.get("codeDescription").asText().split("-") : null;
	    accountProviderID = cdDescArr != null && cdDescArr.length > 2 ?  cdDescArr[2] : "";

	    ((ObjectNode)masterJsonNode).put("accountProviderID", accountProviderID);
	    
	    return masterJsonNode;
	}
	
//	public static void main(String[] args) {
//		String jsonString = "[\n"
//				+ "    {\n"
//				+ "        \"codeType\": \"MBBL\",\n"
//				+ "        \"cmCode\": \"BDBL0001907\",\n"
//				+ "        \"codeDescription\": \"BANDHAN BANK LIMITED-BDBL\"\n"
//				+ "    },\n"
//				+ "    {\n"
//				+ "        \"codeType\": \"MBBL\",\n"
//				+ "        \"cmCode\": \"CTCB0000002\",\n"
//				+ "        \"codeDescription\": \"CTBC BANK CO LTD-CTCB\"\n"
//				+ "    },\n"
//				+ "    {\n"
//				+ "        \"codeType\": \"POPB\",\n"
//				+ "        \"cmCode\": \"UTIB0000004\",\n"
//				+ "        \"codeDescription\": \"AXIS BANK LTD-UTIB-2\"\n"
//				+ "    },\n"
//				+ "    {\n"
//				+ "        \"codeType\": \"POPB\",\n"
//				+ "        \"cmCode\": \"HDFC0999999\",\n"
//				+ "        \"codeDescription\": \"HDFC BANK LTD-HDFC-9\"\n"
//				+ "    },\n"
//				+ "    {\n"
//				+ "        \"codeType\": \"POPB\",\n"
//				+ "        \"cmCode\": \"ICIC0007212\",\n"
//				+ "        \"codeDescription\": \"ICICI BANK LTD-ICIC-10\"\n"
//				+ "    },\n"
//				+ "    {\n"
//				+ "        \"codeType\": \"POPB\",\n"
//				+ "        \"cmCode\": \"INDB0000018\",\n"
//				+ "        \"codeDescription\": \"INDUSIND BANK LTD-INDB-11\"\n"
//				+ "    },\n"
//				+ "    {\n"
//				+ "        \"codeType\": \"POPB\",\n"
//				+ "        \"cmCode\": \"KKBK0RTGSMI\",\n"
//				+ "        \"codeDescription\": \"KOTAK MAHINDRA BANK-KKBK-70\"\n"
//				+ "    },\n"
//				+ "    {\n"
//				+ "        \"codeType\": \"POPB\",\n"
//				+ "        \"cmCode\": \"PUNB0006600\",\n"
//				+ "        \"codeDescription\": \"PUNJAB NATIONAL BANK-PUNB-14\"\n"
//				+ "    },\n"
//				+ "    {\n"
//				+ "        \"codeType\": \"POPB\",\n"
//				+ "        \"cmCode\": \"SBIN0000539\",\n"
//				+ "        \"codeDescription\": \"STATE BANK OF INDIA-SBIN-89\"\n"
//				+ "    },\n"
//				+ "    {\n"
//				+ "        \"codeType\": \"POPB\",\n"
//				+ "        \"cmCode\": \"YESB0000001\",\n"
//				+ "        \"codeDescription\": \"YES BANK LTD-YESB-19\"\n"
//				+ "    }\n"
//				+ "]";
//		
//			ObjectMapper mapper = new ObjectMapper();
//			try
//			{
//				JsonNode popBankMstrData = mapper.readTree(jsonString);
//				ArrayNode popBankMstrDataTransformed = mapper.createArrayNode();
//				
//				PopBankMstrApiResTransformer transformer = new PopBankMstrApiResTransformer();
//				if(popBankMstrData.isArray())
//				{
//					for(JsonNode node : popBankMstrData)
//					{
//						JsonNode transformedData = transformer.transformMasterJson("TMFGENERIC_POPBANKMSTR", node);
//						popBankMstrDataTransformed.add(transformedData);
//					}
//				}
//				
//				System.out.println(popBankMstrDataTransformed.toPrettyString());
//			}
//			catch(Exception e) {
//				e.printStackTrace();
//			}
//	}
}
