package com.fsl.fwk.cache.genericmaster.pullsvc.reqfilters;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fsl.fwk.cache.master.pullsvc.reqfilters.BranchMasterApiRequestFilter;
import com.tcs.fwk.cache.master.filters.config.IMasterApiRequestFilter;
import com.tcs.fwk.model.ISessionVO;

@Component("TMFGENERIC_BRANCHMSTR_REQFILTER")
public class TmfgenericBranchMasterApiRequestFilter implements IMasterApiRequestFilter {

	@Autowired BranchMasterApiRequestFilter branchMasterApiRequestFilter;
	
	@Override
	public List<Map<String, Object>> getRequestBodyFilters(ISessionVO sessVO) {
		return branchMasterApiRequestFilter.getRequestBodyFilters(sessVO);
	}
	
}
