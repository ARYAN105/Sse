package com.fsl.fwk.cache.genericmaster.transformers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fsl.fwk.cache.master.transformers.PopBankMstrApiResTransformer;
import com.tcs.fwk.cache.master.transformer.config.IMasterApiResponseTransformer;

@Component("TMFGENERIC_POPBANKMSTR_TRANSFORMER")
public class TmfgenericPopBankMstrApiResTransformer implements IMasterApiResponseTransformer {

	@Autowired PopBankMstrApiResTransformer popBankMstrTransformer;
	
	@Override
	public JsonNode transformMasterJson(String masterName, JsonNode masterJsonNode) {
	    return popBankMstrTransformer.transformMasterJson(masterName, masterJsonNode);
	}
	
	@Override
	public String getPk(String masterName, JsonNode masterJsonNode) {
		return popBankMstrTransformer.getPk(masterName, masterJsonNode);
	}
}
