package com.fsl.fwk.cache.master.pullsvc.reqfilters;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tcs.fwk.cache.master.client.MasterDataCacheClient;
import com.tcs.fwk.cache.master.filters.config.IMasterApiRequestFilter;
import com.tcs.fwk.cache.master.model.IMasterEntity;
import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.util.GenericUtil;

@Component("BRANCHMSTR_REQFILTER")
public class BranchMasterApiRequestFilter implements IMasterApiRequestFilter {

	@Autowired MasterDataCacheClient masterDataCacheClient;
	
	@Override
	public List<Map<String, Object>> getRequestBodyFilters(ISessionVO sessVO) {
		List<Map<String, Object>> reqBodyFilters = new LinkedList<>(); // to store list of bank names
		try {
			IMasterEntity masterEntity = masterDataCacheClient.getBasicMaster(sessVO, "GLOBALBANKMSTR");
			reqBodyFilters = masterEntity.getRows().values().stream()
			.filter(masterRowEntity -> GenericUtil.isNeitherNullNorEmpty(masterRowEntity.getPk()))
			.map(masterRowEntity -> {
				Map<String, Object> reqBodyFilter = new HashMap<String, Object>();
				reqBodyFilter.put("bankName", masterRowEntity.getPk());
				
				return reqBodyFilter;
			}).collect(Collectors.toList());

		} catch (BusinessException e) {
			AppLogger.error(sessVO, "BusinessException while fetching GLOBALBANKMSTR Data: ", e);
		} catch (Exception e) {
			AppLogger.error(sessVO, "Exception while fetching GLOBALBANKMSTR Data: ", e);
		}
		
		AppLogger.debug(sessVO, "ReqBodyFilter size: " + (reqBodyFilters != null ? reqBodyFilters.size() : 0));
		
		return reqBodyFilters;
	}
	
}
