package com.fsl.framework.db;

import org.springframework.beans.factory.annotation.Autowired;

import com.tcs.fwk.db.service.MWDBService;
import com.tcs.fwk.service.IEmbeddedOrchInnerMWService;
import com.tcs.fwk.service.MWService;


public abstract class FSLDbService extends MWDBService implements IEmbeddedOrchInnerMWService {

	@Autowired FSLDbDynaEmbOrchOuterCSvc fSLDbDynaEmbOrchOuterCSvc;

	@Override
	public final MWService getOrchOuterMWService() {
		return fSLDbDynaEmbOrchOuterCSvc;
	}
}
