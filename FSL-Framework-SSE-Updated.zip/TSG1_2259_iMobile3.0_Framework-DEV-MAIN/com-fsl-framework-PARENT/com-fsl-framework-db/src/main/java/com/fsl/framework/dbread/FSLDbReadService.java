package com.fsl.framework.dbread;

import org.springframework.beans.factory.annotation.Autowired;

import com.tcs.fwk.db.service.MWReadDBService;
import com.tcs.fwk.service.IEmbeddedOrchInnerMWService;
import com.tcs.fwk.service.MWService;

public abstract class FSLDbReadService extends MWReadDBService implements IEmbeddedOrchInnerMWService {

	@Autowired
	FSLDbReadDynaEmbOuterCSvc fSLDbReadDynaEmbOuterCSvc;

	@Override
	public MWService getOrchOuterMWService() {
		// TODO Auto-generated method stub
		return fSLDbReadDynaEmbOuterCSvc;
	}
}
