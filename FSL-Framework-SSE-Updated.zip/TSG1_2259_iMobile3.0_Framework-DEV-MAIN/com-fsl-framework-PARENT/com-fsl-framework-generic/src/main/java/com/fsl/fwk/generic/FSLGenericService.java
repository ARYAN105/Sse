package com.fsl.fwk.generic;

import org.springframework.beans.factory.annotation.Autowired;

import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.service.IEmbeddedOrchInnerMWService;
import com.tcs.fwk.service.MWGenericService;
import com.tcs.fwk.service.MWService;

/**
 * @author Omkar Powar
 * @author Tata Consultancy Services
 */
public abstract class FSLGenericService extends MWGenericService implements IEmbeddedOrchInnerMWService {

	@Autowired FslGenericDynaEmbOrchOuterCSvc fslGenericDynaEmbOrchOuterCSvc;
	
	@Override
	protected MWResponse<?> invokeGeneric(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn addOn, BaseModel extraData) {
		return invokeGeneric(sessVO, mwRequest, addOn, extraData);
	}

	@Override
	public MWService getOrchOuterMWService() {
		return fslGenericDynaEmbOrchOuterCSvc;
	}
}
