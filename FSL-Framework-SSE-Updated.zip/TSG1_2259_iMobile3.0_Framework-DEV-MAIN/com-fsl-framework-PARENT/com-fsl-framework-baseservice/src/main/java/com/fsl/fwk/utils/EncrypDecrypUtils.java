package com.fsl.fwk.utils;

import java.nio.charset.StandardCharsets;
import java.util.Random;

import javax.crypto.SecretKey;

import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.EncDecModel;

public class EncrypDecrypUtils {
  
  EncrypDecrypUtils(){}
  
  private static final String RSAECBPKCS1PADDING = "RSA/ECB/PKCS1Padding";
  private static final String AESCBCPKCS5PADDING = "AES/CBC/PKCS5Padding";
  private static final String AESGCMNOPADDING    = "AES/GCM/NoPadding";
  
  public static EncDecModel encryptH(String content, String publicKey) {
    EncDecModel dehEncryptionModel = new EncDecModel();
    try {
      String skey         = randomString(16);
      byte[] key1         = skey.getBytes();
      byte[] plaintextKey = key1;
      
      EncryptionHelper helper        = new EncryptionHelper();
      byte[]           encryptedKey  = new Asymmetric().encrypt(plaintextKey, publicKey.getBytes(), EncDecMode.RSA, RSAECBPKCS1PADDING);
      byte[]           encodedEncKey = helper.encodeToBase64(encryptedKey);
      
      String sIV = randomString(16);
      byte[] iv  = sIV.getBytes();
      
      byte[] encryptedContent       = new Symmetric().encrypt(content.getBytes(), iv, plaintextKey, EncDecMode.AES, AESCBCPKCS5PADDING);
      byte[] ivAndEncryptedContent  = helper.mergeTwoByteArrays(iv, encryptedContent);
      byte[] encodedIvAndEncContent = helper.encodeToBase64(ivAndEncryptedContent);
      
      dehEncryptionModel.setContent(new String(encodedIvAndEncContent));
      dehEncryptionModel.setKey(new String(encodedEncKey));
    }
    catch (Exception e) {
      AppLogger.error(null, "Hybrid Encryption failed for payload", e);
      return dehEncryptionModel;
    }
    return dehEncryptionModel;
  }
  
  public static EncDecModel decryptH(String privateKey, String encryptedKeyStr, String encryptedContentStr) {
    EncDecModel decModel = new EncDecModel();
    
    try {
      DecryptionHelper decryptionhelper    = new DecryptionHelper();
      byte[]           decodedContent      = decryptionhelper.decodeFromBase64(encryptedContentStr.getBytes());
      byte[]           extractedIv         = decryptionhelper.extractBytes(decodedContent, 0, 16);
      byte[]           extractedEncContent = decryptionhelper.extractBytes(decodedContent, 16, decodedContent.length);
      
      byte[] decodedKey   = decryptionhelper.decodeFromBase64(encryptedKeyStr.getBytes());
      byte[] decryptedKey = new Asymmetric().decrypt(decodedKey, privateKey.getBytes(), EncDecMode.RSA,
          RSAECBPKCS1PADDING);
      
      byte[] ddecryptedContent = new Symmetric().decrypt(extractedEncContent, extractedIv, decryptedKey,
          EncDecMode.AES, AESCBCPKCS5PADDING);
      decModel.setKey(new String(decryptedKey));
      decModel.setContent(new String(ddecryptedContent));
    }
    catch (Exception e) {
      AppLogger.error(null, "Hybrid Decryption failed for payload", e);
    }
    
    return decModel;
  }
  
  public static EncDecModel encryptHA(String content, String publicKey) {
    EncDecModel      encModel = new EncDecModel();
    EncryptionHelper helper   = new EncryptionHelper();
    try {
      SecretKey key      = helper.generateKey(EncDecMode.AES);
      byte[]    keyBytes = key.getEncoded();
      
      byte[] encryptedKey  = new Asymmetric().encrypt(keyBytes, publicKey.getBytes(), EncDecMode.RSA, RSAECBPKCS1PADDING);
      byte[] encodedEncKey = helper.encodeToBase64(encryptedKey);
      
      byte[] iv                     = new byte[12];
      System.arraycopy(keyBytes, 0, iv, 0, iv.length);
      byte[] encryptedContent       = new Symmetric().encryptGCM(content.getBytes(), iv, keyBytes, EncDecMode.AES, AESGCMNOPADDING);
      byte[] ivAndEncryptedContent  = helper.mergeTwoByteArrays(iv, encryptedContent);
      byte[] encodedIvAndEncContent = helper.encodeToBase64(ivAndEncryptedContent);
      
      encModel.setContent(new String(encodedIvAndEncContent));
      encModel.setKey(new String(encodedEncKey));
    }
    catch (Exception e) {
      AppLogger.error(null, "Hybrid Encryption failed for payload", e);
    }
    return encModel;
  }
  
  public static EncDecModel decryptHA(String privateKey, String encryptedKeyStr, String encryptedContentStr) {
    EncDecModel decModel = new EncDecModel();
    try {
      DecryptionHelper decHelper = new DecryptionHelper();
      
      // Key decryption --------
      //Get IV using getFirst16Bytes(Base64Decode(encryptedData);
      byte[] decodedData = decHelper.decodeFromBase64(encryptedContentStr.getBytes());
      byte[] iv          = new byte[12];
      iv = decHelper.extractBytes(decodedData, 0, iv.length);
      
      byte[] decodedKey   = decHelper.decodeFromBase64(encryptedKeyStr.getBytes());
      byte[] decryptedKey = new Asymmetric().decrypt(decodedKey, privateKey.getBytes(), EncDecMode.RSA,
          RSAECBPKCS1PADDING);
      
      // Content decryption --------
      byte[] decodedContent = decHelper.decodeFromBase64(encryptedContentStr.getBytes());
      iv = decHelper.extractBytes(decodedContent, 0, iv.length);
      
      byte[] encryptedContent = decHelper.extractBytes(decodedContent, iv.length, decodedContent.length);
      byte[] decryptedContent = new Symmetric().decryptGCM(encryptedContent, iv, decryptedKey, EncDecMode.AES,
          AESGCMNOPADDING);
      
      decModel.setKey(new String(decryptedKey));
      decModel.setContent(new String(decryptedContent));
    }
    catch (Exception e) {
      AppLogger.error(null, "Hybrid ASymmetric Decryption failed for payload", e);
    }
    
    return decModel;
  }
  
  private static String randomString(int n) {
    // length is bounded by 256 Character
    byte[] array = new byte[256];
    new Random().nextBytes(array);
    
    String randomString = new String(array, StandardCharsets.UTF_8);
    
    // Create a StringBuffer to store the result
    StringBuilder randomSB = new StringBuilder();
    
    // remove all special char
    String alphaNumericString = randomString.replaceAll("[^A-Za-z0-9]", "");
    
    // Append first 20 alphanumeric characters
    // from the generated random String into the result
    for (int k = 0; k < alphaNumericString.length(); k++) {
      if (Character.isLetter(alphaNumericString.charAt(k)) && (n > 0)
          || Character.isDigit(alphaNumericString.charAt(k)) && (n > 0)) {
        randomSB.append(alphaNumericString.charAt(k));
        n--;
      }
    }
    // return the resultant string
    return randomSB.toString();
  }
  
  public static String encryptS(String painTextValue, String key, String initVector) {
    try {
      /*
      IvParameterSpec iv       = new IvParameterSpec(initVector.getBytes(StandardCharsets.UTF_8));
      SecretKeySpec   skeySpec = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), EncDecMode.AES.name());
      
      Cipher cipher = Cipher.getInstance(AESCBCPKCS5PADDING);
      cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
      byte[] encrypted = cipher.doFinal(painTextValue.getBytes());
      */
      byte[] encrypted = new Symmetric().encrypt(painTextValue.getBytes(), initVector.getBytes(StandardCharsets.UTF_8),
          key.getBytes(StandardCharsets.UTF_8), EncDecMode.AES, AESCBCPKCS5PADDING);
      byte[] encoded = new EncryptionHelper().encodeToBase64(encrypted);
      
      return new String(encoded);
    }
    catch (Exception ex) {
      AppLogger.error(null, "Symetric Encryption failed for payload", ex);
      return null;
    }
  }
  
  public static String decryptS(String encrypted, String key, String initVector) {
    try {
      /*IvParameterSpec iv = new IvParameterSpec(initVector.getBytes(StandardCharsets.UTF_8));
      SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), EncDecMode.AES.name());
      
      Cipher cipher = Cipher.getInstance(AESCBCPKCS5PADDING);
      cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
      byte[] original = cipher.doFinal(Base64.getDecoder().decode(encrypted));*/
      
      byte[] decoded = new DecryptionHelper().decodeFromBase64(encrypted.getBytes());
      byte[] original = new Symmetric().decrypt(decoded, initVector.getBytes(StandardCharsets.UTF_8),
          key.getBytes(StandardCharsets.UTF_8), EncDecMode.AES, AESCBCPKCS5PADDING);
      
      return new String(original);
    }
    catch (Exception ex) {
      AppLogger.error(null, "Symetric Decryption failed for payload", ex);
      return null;
    }
  }
  
}