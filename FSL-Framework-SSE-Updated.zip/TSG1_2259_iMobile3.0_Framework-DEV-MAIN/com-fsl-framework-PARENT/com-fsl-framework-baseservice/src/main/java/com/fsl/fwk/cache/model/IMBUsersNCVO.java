package com.fsl.fwk.cache.model;

import java.io.Serializable;

import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.TagIndexed;
import com.tcs.fwk.data.model.BaseEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Document("usrsnc")
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@Data
@Builder
public class IMBUsersNCVO implements BaseEntity, Serializable {
	private static final long serialVersionUID = IMBUsersNCVO.class.hashCode();

	// ############## imb users NC #############
	@Id
	@org.springframework.data.annotation.Id
	@TagIndexed
	private String mob;//USER_MOBNO

	private String fNm;//USER_FNAME
	private String lNm;//USER_LNAME
	private String email;//USER_EMAIL
	private Integer actv;//USER_ACTIVE
	private String prmAcc;//USER_PRIMEAC
	private String lgnTm;//USER_LOGONTIME
	private String cDt;//USER_CRDATE
	private String uDt;//USER_UPDATED
	private String upiProf;//USERD_UPI_PROFILE
	private String vpaID;//USER_PRIMARY_VPA_ID
	private String uTyp;//USER_ACC_TYPE
	private String eAut;//EMAIL_AUTH
	private String uID;//USER_ID
	private String osFl;//OSCHANGE_FLAG
	private String bUID;//USER_BAY_ID
	private String cCo;//COUNTRY_CODE
	private String mNo;//MOB_NO
	private String iMpc;//INVALMPINCNT
}