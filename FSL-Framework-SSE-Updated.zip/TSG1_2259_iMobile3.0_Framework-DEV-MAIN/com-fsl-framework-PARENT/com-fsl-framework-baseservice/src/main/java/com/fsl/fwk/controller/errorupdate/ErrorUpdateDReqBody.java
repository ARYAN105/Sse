package com.fsl.fwk.controller.errorupdate;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tcs.fwk.model.BaseRequestBody;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class ErrorUpdateDReqBody extends BaseRequestBody {
	private static final long serialVersionUID = ErrorUpdateDReqBody.class.getCanonicalName().hashCode();

	@JsonProperty("errorCode")
	private String errorCode;

	@JsonProperty("errorDesc")
	private String errorDesc;

	@JsonProperty("systemName")
	private String systemName;

	@JsonProperty("serviceId")
	private String serviceId;

}
