package com.fsl.fwk.controller.audit;

import org.springframework.core.env.Environment;

import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequestAddOn;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.service.MWService;

public interface IFSLAuditEventPublisher {
	
	public void publishFSLAuditEvent(ISessionVO sessVO, IMWRequest<?> mwRequest, MWResponse<?> mwResponse,
			MWService mwService, long startTime, MWRequestAddOn reqAddOn, boolean isAuditEnable);
	
	static boolean isAuditEventEnable(ISessionVO sessVO, Environment env, MWService mwService,
			IFSLAuditEventPublisher auditEventPublisher) {
		boolean isPublishEvent = false;
		String serviceId = (mwService == null ? "" : mwService.myServiceID());

		String defaultEnable = env.getProperty("FSL.AUDIT.EVENT.DEFAULT.enable");
		if (defaultEnable == null || defaultEnable.trim().isBlank()) {
			throw new SystemException(FwkResponseStatus.CODING_CONFIG_ERROR,
					"Default value of FSL.AUDIT.EVENT.DEFAULT.enable cannot be null or empty");
		} else {
			isPublishEvent = "1"
					.equals(env.getProperty("FSL.AUDIT.EVENT." + serviceId + ".enable", defaultEnable).trim());
		}

		if (isPublishEvent && auditEventPublisher == null) {
			throw new SystemException(FwkResponseStatus.CODING_CONFIG_ERROR, String
					.format("Audit log is enabled for service %s, But auditPublisher is not configured", serviceId));
		}

		AppLogger.debug(sessVO,
				"AUDIT LOG for service : " + serviceId + " is " + (isPublishEvent ? "enabled" : "disabled"));
		return isPublishEvent;
	}
	
}