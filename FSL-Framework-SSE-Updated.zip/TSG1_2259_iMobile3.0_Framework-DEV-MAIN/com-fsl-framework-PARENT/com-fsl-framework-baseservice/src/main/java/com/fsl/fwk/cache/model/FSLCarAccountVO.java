package com.fsl.fwk.cache.model;

import com.tcs.fwk.model.BaseModel;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
public class FSLCarAccountVO extends BaseModel {
	private static final long serialVersionUID = FSLCarAccountVO.class.hashCode();
	
	private String cId;  //custId
	private String fsId;  //fsId
	private String aNo;  //accNo
	private String aTp;  //accType
	private String aSTp;  //accSubType
	private String sNo;  //serNo
	private String aNm;  //accName
	private String pAFl;  //primaryAccFlg
	private String bHSt;  //bankHomeStatus
	private String mSt;  //minorStatus
	private String nATp;  //nriAccountType

}
