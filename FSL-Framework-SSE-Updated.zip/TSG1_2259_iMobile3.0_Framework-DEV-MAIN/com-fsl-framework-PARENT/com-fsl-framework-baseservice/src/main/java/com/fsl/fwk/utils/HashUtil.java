package com.fsl.fwk.utils;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.function.UnaryOperator;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.fsl.fwk.constants.FSLConstants;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.util.GenericUtil;

@Component
public class HashUtil  {
  
  @Autowired Environment env;
  
  private static String bytesToHex(byte[] bytes) {
    StringBuilder hexString = new StringBuilder();
    for (byte b : bytes) {
      String hex = Integer.toHexString(0xff & b);
      if (hex.length() == 1) {
        hexString.append('0');
      }
      hexString.append(hex);
    }
    return hexString.toString();
  }
  
  public static String generateSHA256Hash(String string)
      throws NoSuchAlgorithmException {
    MessageDigest messageDigest = MessageDigest.getInstance(FSLConstants.SHA256_ALGORITHM);
    byte[]        bytes         = messageDigest.digest(string.getBytes(StandardCharsets.UTF_8));
    StringBuilder stringBuilder = new StringBuilder();
    for (byte b : bytes) {
      stringBuilder.append(Integer.toHexString((b & 0xFF) | 0x100).substring(1, 3));
    }
    return stringBuilder.toString();
  }
  
  public static String calculateHmacSHA256(String message, String secretKey)
      throws NoSuchAlgorithmException, InvalidKeyException {
    Mac mac = Mac.getInstance(FSLConstants.HMAC_SHA256_ALGORITHM);
    
    SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8),
        FSLConstants.HMAC_SHA256_ALGORITHM);
    mac.init(secretKeySpec);
    byte[] hmacBytes = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));
    
    return bytesToHex(hmacBytes);
  }
  
  private UnaryOperator<String> corpHashRepEnabledFlag = svcId -> GenericUtil.isNullOrEmpty(svcId)
      ? "FSL.EAIGATEWAY.HASHREP.ENABLED.DEFAULT.FLAG"
      : "FSL.EAIGATEWAY.HASHREP.ENABLED." + svcId + ".FLAG";
  
  public String checkHashReplayEnabled(String svcId) {
    String defaultEnableProp  = corpHashRepEnabledFlag.apply(null);
    String hashEnableSvcProp  = corpHashRepEnabledFlag.apply(svcId);
    
    return GenericUtil.isNullOrEmpty(env.getProperty(hashEnableSvcProp))
        ? env.getProperty(defaultEnableProp, "0")
        : env.getProperty(hashEnableSvcProp);
  }
  
//Hash should be applied only greater than base
  public boolean isValidAppVersion(String version,String osType,ISessionVO sessvo) {
     String baseVersion = FSLConstants.IOS.equalsIgnoreCase(osType)
        ? env.getProperty("FSL.EAIGATEWAY.HASH.BASE_IOS_VERSION", "30.3")
        : env.getProperty("FSL.EAIGATEWAY.HASH.BASE_ANDROID_VERSION", "31.1");
    
    String excludeVersion = FSLConstants.IOS.equalsIgnoreCase(osType)
        ? env.getProperty("FSL.EAIGATEWAY.HASH.EXCLUDE_IOS_VERSIONS", "")
        : env.getProperty("FSL.EAIGATEWAY.HASH.EXCLUDE_ANDROID_VERSIONS", "");
    
    int compareVersion=compareVersions(version, baseVersion);
    if (compareVersion >= 0 && !Arrays.asList(excludeVersion.split(",")).contains(version)) {
      return true;
    }
    else if (compareVersion<0) {
      AppLogger.info(sessvo,String.format("Hash check skipped Due to AppVersion lower than base version, version|baseversion: %s|%s",version,baseVersion));
      return false;
    }
    else {
      AppLogger.info(sessvo, String.format("Hash check skipped Due to AppVersion is in excluded version list, version|excludeVersion: %s|%s",version,baseVersion));
      return false;
    }
  }

 
  public int compareVersions(String version,String baseVersion) {
    String[] v1     = version.split("\\."); 
    String[] v2     = baseVersion.split("\\."); 
    int      length = Math.max(v1.length, v2.length);
    
    for (int i = 0; i < length; i++) {
      int p1 = i < v1.length ? Integer.parseInt(v1[i]) : 0;
      int p2 = i < v2.length ? Integer.parseInt(v2[i]) : 0;
      if (p1 != p2) {
        return Integer.compare(p1, p2);
      }
    }
    return 0;
  }
  
//Checking received request is from valid appVersion expected format XX.XX
  public boolean isValidAppVersionFormat(String version, ISessionVO sessionVO) {
    version = GenericUtil.isNullOrEmpty(version) ? "" : version.trim();
    Long isValidFormat = version.chars().filter(ch -> ch == FSLConstants.VERSION_SEPARATOR).count();
    
    boolean versionFormatMatches = version .matches(env.getProperty("FSL.EAIGATEWAY.APPVERSION.REGEX", "^[0-9.]+$"));
    
    if ((isValidFormat <= FSLConstants.MAX_DOTS_ALLOWED) && versionFormatMatches) {
      return true;
    }
    else {
      AppLogger.info(sessionVO, "Hash Check Skipped Due to Request Recieved from UnRecognized Appversion: " + version);
      return false;
    }
  }
}
