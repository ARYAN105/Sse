package com.fsl.fwk.generic;

import org.springframework.stereotype.Service;

import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.service.MWGenericService;
import com.tcs.fwk.service.exception.CustomValidationException;

/**
 * @author Omkar Powar
 * @author Tata Consultancy Services
 */
@Service
public class FslSecurityCheckGSvc extends MWGenericService {

	@Override
	public BaseModel customValidations(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn) throws CustomValidationException {
		return null;
	}

	@Override
	protected Class<? extends BaseModel> myRequestBodyType() {
		return BaseModel.class;
	}

	@Override
	protected MWResponse<?> invokeGeneric(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn addOn, BaseModel extraData) {
		return new MWResponse<>(sessVO, FwkResponseStatus.SUCCESS, null);
	}

	@Override
	protected String[] cacheKey(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn) {
		return new String[] { sessVO.getTrcID() };
	}

}
