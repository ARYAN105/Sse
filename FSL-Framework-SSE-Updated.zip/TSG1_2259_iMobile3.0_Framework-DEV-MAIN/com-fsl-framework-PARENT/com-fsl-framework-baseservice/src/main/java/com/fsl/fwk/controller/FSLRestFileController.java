package com.fsl.fwk.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.fsl.fwk.controller.audit.IFSLAuditEventPublisher;
import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequestAddOn;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.model.RequestResponseModel;
import com.tcs.fwk.service.MWRestFileController;
import com.tcs.fwk.service.MWService;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;

/**
 * @author Tata Consultancy Services
 */
public abstract class FSLRestFileController extends MWRestFileController {

	@Autowired FSLControllerHelper fslControllerHelper;
	
	@Autowired(required = false)
	private IFSLAuditEventPublisher auditEventPublisher;
	
	@Autowired private Environment env;
	private boolean isAuditEnable = false;
	
	@PostConstruct
	private void isAuditEventEnable() {
		isAuditEnable = IFSLAuditEventPublisher.isAuditEventEnable(null, env, myMWService(), auditEventPublisher);
	}
	
	@Override
  public RequestResponseModel checkSecurity(HttpServletRequest httpRequest, IMWRequest<?> mwRequest,
      ISessionVO sessionVO)
      throws BusinessException {
    RequestResponseModel reqResModel = super.checkSecurity(httpRequest, mwRequest, sessionVO);
    reqResModel = fslControllerHelper.baseSecurityCheck(httpRequest, mwRequest, apiGatewaySecretConfigured, sessionVO, reqResModel,myMWService());
    
    return fslControllerHelper.checkSecurity(httpRequest, mwRequest, apiGatewaySecretConfigured, sessionVO, reqResModel.getUser());
  }

	@Override
	protected MWResponse<?> after_ServiceInvocation(ISessionVO sessVO, IMWRequest<?> mwRequest, MWResponse<?> mwResponse,
			MWService mwService, long startTime, MWRequestAddOn reqAddOn) {
		MWResponse<?> response = fslControllerHelper.afterServiceInvocation(sessVO, mwRequest, mwResponse, mwService, startTime, reqAddOn);
		
		if (auditEventPublisher != null) {
			auditEventPublisher.publishFSLAuditEvent(sessVO, mwRequest, response, mwService, startTime, reqAddOn, isAuditEnable);
		}
		
		return response;
	}
	
}