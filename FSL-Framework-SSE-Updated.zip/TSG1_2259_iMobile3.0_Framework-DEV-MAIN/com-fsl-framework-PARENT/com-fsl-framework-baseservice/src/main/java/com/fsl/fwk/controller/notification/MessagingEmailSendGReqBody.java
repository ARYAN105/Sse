package com.fsl.fwk.controller.notification;

import java.util.HashMap;
import java.util.List;

import com.tcs.fwk.logger.masking.MaskRule;
import com.tcs.fwk.logger.masking.MaskSensitive;
import com.tcs.fwk.logger.masking.Sensitive;
import com.tcs.fwk.model.BaseRequestBody;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@MaskSensitive
public class MessagingEmailSendGReqBody extends BaseRequestBody {
	private static final long serialVersionUID = MessagingEmailSendGReqBody.class.getCanonicalName().hashCode();
	
	@Sensitive(rule = MaskRule.EXCLUDEAFTER, param = "@")
	private String									from;
  @Sensitive(rule = MaskRule.EXCLUDEAFTER, param = "@")
	private List<String>						to;
  @Sensitive(rule = MaskRule.EXCLUDEAFTER, param = "@")
	private List<String>						cc;
  @Sensitive(rule = MaskRule.EXCLUDEAFTER, param = "@")
	private List<String>						bcc;
	private String									subject;
	private String									bodyTemplateId;					// instead of body
	private HashMap<String, String>	bodyParams;
	private String									attachmentsFileLocation;
	private List<String>						attachmentList;
	private boolean									purgeAttachment;
}
