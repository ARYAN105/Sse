package com.fsl.fwk.upi.fin.model;

import com.fsl.fwk.controller.model.FSLRequestBody;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
//@AllArgsConstructor
//@NoArgsConstructor
public class UpiFinIntegReqBody extends FSLRequestBody {

	/**
	 * 
	 */
	private static final long serialVersionUID = "com.fsl.fwk.upi.fin.UpiFinIntegReqBody".hashCode();

}
