package com.fsl.fwk.cache.model;

import java.util.List;

import org.springframework.data.redis.core.TimeToLive;

import com.redis.om.spring.annotations.Document;
import com.tcs.fwk.data.model.BaseEntity;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@Builder
@Data
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@Document("ucrp")
@Entity

public class IMBUserCarResponseVO implements BaseEntity {
	
	public static final long serialVersionUID = 1L;
	
	@Id
	@org.springframework.data.annotation.Id
	public String bUID;//BAY_USER_ID
	private String cRsp;//CAR_RESPONSE
	private String cRpj;//CAR_RESPONSE_JSON
	/*private String uId;// userId
	private String niSt;// nriStatus
	private String mNo;// mobNo
	private String uNm;// userNm
	private String uTp;// userType
	private String cSg;// custSegment
	private String rlNm;// relNum
	private String dOB;// dateOfBirth
	private List<String> cIds;// custIds
	private List<String> rels;// relationships
	private List<String> sbAc;// sbaAccts
	private List<String> caAc;// ccaAccts
	private List<String> crAc;// ccrAccts
	private List<String> niAc;// nriAccts
	private List<String> noAc;// nroAccts
	private List<String> neAc;// nreAccts
	private List<String> syAc;// ssyAccts
	private List<String> pcAc;// pocAccts
	private List<String> otAc;// otherAccts
  
  @ElementCollection
  private List<FSLCarAccountVO> acl;//accList
   */
  @TimeToLive
  @Builder.Default
  private transient Long ttl = -1L;
}
