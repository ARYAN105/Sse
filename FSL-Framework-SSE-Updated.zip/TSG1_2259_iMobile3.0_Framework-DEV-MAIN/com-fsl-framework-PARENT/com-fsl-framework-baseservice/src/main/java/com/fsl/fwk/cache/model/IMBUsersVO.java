package com.fsl.fwk.cache.model;

import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.TagIndexed;
import com.tcs.fwk.data.model.BaseEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@Document("usrs")
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
//@EqualsAndHashCode(callSuper = true) // due to warning on @Data

@Entity // Added to generate metatmodel
public class IMBUsersVO implements BaseEntity {

	// private String sqID;

	@Id
	@org.springframework.data.annotation.Id
	@TagIndexed
	private String uID;//USER_ID

	private String fNm;//USER_FNAME
	private String lNm;//USER_LNAME	

	@TagIndexed
	private String bUID;//USER_BAY_ID

	@TagIndexed
	private String mob;//USER_MOBNO

	private String email;//USER_EMAIL
	private String prmAcc;//USER_PRIMEAC
	private String lgnTm;//USER_LOGONTIME
	private String actDt;//USER_ACTIVATION_DATE
	private String rActDt;//USER_REACTIVATION_DATE
	private String upiProf;//USERD_UPI_PROFILE
	private String vpaID;//USER_PRIMARY_VPA_ID
	private String uTyp;//USER_TYPE
	private String cCo;//COUNTRY_CODE
	private String mNo;//MOB_NO
	private String osFl;//OSCHANGE_FLAG
	private String uCr;//USER_CRDATE
	private String iMpc;//INVALMPINCNT
	private String uPf;//USERD_PROFILING
	private String uSts;//USER_STATUS
	private String bDt;//BLOCKED_DATE
	private String uCst;//USER_CONSENT
	private String tmcs;//TERMINATED_BY_OC_SESSION
	private String fId;//FED_ID
}
