package com.fsl.fwk.controller.notification;

import java.util.HashMap;
import java.util.List;

import com.tcs.fwk.logger.masking.MaskRule;
import com.tcs.fwk.logger.masking.MaskSensitive;
import com.tcs.fwk.logger.masking.Sensitive;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
//@AllArgsConstructor
@ToString
@MaskSensitive
public class EmailDataVO {
  @Sensitive(rule = MaskRule.EXCLUDEAFTER, param = "@")
	private String									from										= null;
  @Sensitive(rule = MaskRule.EXCLUDEAFTER, param = "@")
	private List<String>						to											= null;
  @Sensitive(rule = MaskRule.EXCLUDEAFTER, param = "@")
	private List<String>						cc											= null;
  @Sensitive(rule = MaskRule.EXCLUDEAFTER, param = "@")
	private List<String>						bcc											= null;
	private String									subject									= null;
	private String									bodyTemplateId					= null;	// instead of body
	private HashMap<String, String>	bodyParams							= null;
	private String									attachmentsFileLocation	= null;
	private List<String>						attachmentList					= null;
	private boolean									purgeAttachment         = false;
	
	public EmailDataVO(String from, List<String> to, String subject, String bodyTemplateId, HashMap<String, String> bodyParams) {
		this.from						= from;
		this.to							= to;
		this.subject				= subject;
		this.bodyTemplateId	= bodyTemplateId;
		this.bodyParams			= bodyParams;
	}
}
