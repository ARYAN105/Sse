package com.fsl.fwk.constants;

import com.tcs.fwk.constants.ResponseStatus;

public enum FSLResponseStatus implements ResponseStatus {
	BUSINESS_SECURITY_VALIDATION_ERRORS(121), // Added for business security validation done in FSL Framework level.
	EAI_AUTH_FAILED(122), // added as required by internal dyna orchestration
	FSL_SECURITY_VALIDATION_FAILED(10);

	private int code;

	private FSLResponseStatus(int code) {
		this.code = code;
	}

	@Override
	public int getCode() {
		// TODO Auto-generated method stub
		return code;
	}
}
