package com.fsl.fwk.model;

import com.tcs.fwk.model.BaseModel;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class FSLFalconHeaders extends BaseModel {
	private static final long serialVersionUID = FSLFalconHeaders.class.hashCode();
	
	String userId;
	String postalCode;
	String street;
	String city;
	String deviceId;
	String deviceIP;
	String deviceType;
	String deviceOS;
	
	String userData09;
	String userData11;
	String userData12;
	String userData18;
	
	String capability;
	String appId;
	
	String onlineAccountOpenDate;
	String userdTouchMFAEnable;
	String customerApplicationVersion;
}
