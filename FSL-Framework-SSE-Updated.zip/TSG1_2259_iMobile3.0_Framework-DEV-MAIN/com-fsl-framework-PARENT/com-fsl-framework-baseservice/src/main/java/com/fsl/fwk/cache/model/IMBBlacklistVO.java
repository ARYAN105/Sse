package com.fsl.fwk.cache.model;

import java.io.Serializable;

import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.TagIndexed;
import com.tcs.fwk.data.model.BaseEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Document("dbl")
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@Data
@Builder
public class IMBBlacklistVO implements BaseEntity,Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@Column(name = "WLDEVICEID")
	@org.springframework.data.annotation.Id
	private String wDID;//WLDEVICEID

	@TagIndexed
	private String imei;//IMEINO

	private String sts;//STATUS


}
