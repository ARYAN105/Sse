package com.fsl.fwk.utils;

import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class DecryptionHelper extends EncDecHelper {
  /*public SecretKeySpec getSecretKey(byte[] keyBytes, String algorithm) {
    return new SecretKeySpec(keyBytes, algorithm);
  }*/
  
  public PrivateKey getPrivate(byte[] privateKey, EncDecMode mode)
      throws NoSuchAlgorithmException, InvalidKeySpecException {
    PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(decodeFromBase64(privateKey));
    KeyFactory          kf   = KeyFactory.getInstance(mode.name());
    return kf.generatePrivate(spec);
  }
  
  public byte[] decrypt(byte[] input, PrivateKey key, String algorithm)
      throws GeneralSecurityException {
    Cipher cipher = Cipher.getInstance(algorithm);
    cipher.init(Cipher.DECRYPT_MODE, key);
    return cipher.doFinal(input);
  }
  
  public byte[] decrypt(byte[] input, SecretKeySpec key, String algorithm, byte[] iv)
      throws GeneralSecurityException {
    Cipher          cipher   = Cipher.getInstance(algorithm);
    IvParameterSpec ivParams = new IvParameterSpec(iv);
    cipher.init(Cipher.DECRYPT_MODE, key, ivParams);
    return cipher.doFinal(input);
  }
  
  public byte[] decrypt(byte[] input, SecretKeySpec key, String algorithm, GCMParameterSpec gcmParameterSpec)
      throws GeneralSecurityException {
    Cipher cipher = Cipher.getInstance(algorithm);
    cipher.init(Cipher.DECRYPT_MODE, key, gcmParameterSpec);
    return cipher.doFinal(input);
  }
  
  public byte[] extractBytes(byte[] input, int startIndex, int endIndex) {
    return Arrays.copyOfRange(input, startIndex, endIndex);
  }
  
}
