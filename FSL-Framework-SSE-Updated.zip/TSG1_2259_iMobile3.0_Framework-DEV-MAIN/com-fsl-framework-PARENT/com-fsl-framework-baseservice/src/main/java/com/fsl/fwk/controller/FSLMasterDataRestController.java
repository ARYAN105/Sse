package com.fsl.fwk.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.controller.model.FSLError;
import com.fsl.fwk.controller.model.FSLUserProfile;
import com.tcs.fwk.constants.FwkConstants;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequestAddOn;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.model.RequestResponseModel;
import com.tcs.fwk.service.MWRestController;
import com.tcs.fwk.service.MWService;
import com.tcs.fwk.service.User;
import com.tcs.fwk.util.GenericUtil;

import jakarta.servlet.http.HttpServletRequest;

public abstract class FSLMasterDataRestController extends MWRestController {

	@Autowired
	FSLControllerHelper fslControllerHelper;

	@Override
	public RequestResponseModel checkSecurity(HttpServletRequest httpRequest, IMWRequest<?> mwRequest, ISessionVO sessionVO)
			throws BusinessException {

		Map<String, Object> meta = null;
		List<String> msgCds = null;
		List<FSLError> fslError = null;
		String apiGatewaySecretKey = httpRequest.getHeader(FwkConstants.HEADER_SECRET);

		if (null == apiGatewaySecretKey) {
			msgCds = new ArrayList<String>();
			msgCds.add("ApiGateway SecretKey is Mandatory");
			throw new BusinessException(FwkResponseStatus.SECURITY_VALIDATION_ERRORS, msgCds);
		} else {
//			//TODO Remove last check for property file name logic NIKHIL
//			if ((GenericUtil.isEnvironmentProd(env) || GenericUtil.isEnvironmentCug(env)) && encryptPropsname.contains("fwkservice")) {
//				apiGatewaySecretKey = AESGcmEncryptDecrypt.decryptS(apiGatewaySecretKey, keyS, ivS);
//			}
			if (!apiGatewaySecretConfigured.equals(apiGatewaySecretKey)) {
				msgCds = new ArrayList<String>();
				msgCds.add("ApiGateway SecretKey Invalid");
				throw new BusinessException(FwkResponseStatus.SECURITY_VALIDATION_ERRORS, msgCds);
			}

			// TBD-NIKHIL :Need to use attributes instead of headers to pass these after
			// confirming whether Postman can pass attributes in httpRequest
			String ID = httpRequest.getHeader(FwkConstants.HEADER_USERID);
			String IDType = httpRequest.getHeader(FwkConstants.HEADER_USERID_TYPE); // enum USERID_TYPE { UID , MOB, CID
																					// } ; //UserID, MobileNo, CustID
			if (!GenericUtil.isNullOrEmpty(IDType)) {
				if (IDType.equalsIgnoreCase(FSLConstants.USERID_TYPE.DID.toString())) {
					ID = httpRequest.getHeader(FwkConstants.HEADER_DEVICEID);
				} else if (IDType.equalsIgnoreCase(FSLConstants.USERID_TYPE.MNL.toString())) {
					ID = httpRequest.getHeader(FwkConstants.HEADER_DEVICEID);
				}
//				else if (IDType.equalsIgnoreCase(FSLConstants.USERID_TYPE.CID.toString())) {
//
//				} else if (IDType.equalsIgnoreCase(FSLConstants.USERID_TYPE.MOB.toString())) {
//
//				}
			}
			String orgID = httpRequest.getHeader(FwkConstants.HEADER_ORGID);
			String deviceID = httpRequest.getHeader(FwkConstants.HEADER_DEVICEID);
			String channel = httpRequest.getHeader(FwkConstants.HEADER_CHANNEL);
			channel = channel == null ? FSLConstants.HEADERVAL_CHANNEL_DEFAULT : "";

			User user = new User(ID, orgID, null);
			IDType = IDType == null ? FSLConstants.USERID_TYPE.UID.toString() : IDType;
			user.setIdType(IDType);
			user.setDeviceID(deviceID);
			FSLUserProfile fslUserProfile = new FSLUserProfile();
			fslUserProfile.setUserID(ID);

			Map<String, Object> userAttribs = new HashMap<>();
			userAttribs.put(FSLConstants.FSL_USER_PROFILE, fslUserProfile);
			user.setAddtionalAttribs(userAttribs);
			return (new RequestResponseModel(user, channel));
		}

	}

	@Override
	protected MWResponse<?> after_ServiceInvocation(ISessionVO sessVO, IMWRequest<?> mwRequest,
			MWResponse<?> mwResponse, MWService mwService, long startTime, MWRequestAddOn reqAddOn) {
		return fslControllerHelper.afterServiceInvocation(sessVO, mwRequest, mwResponse, mwService, startTime,
				reqAddOn);
	}

}
