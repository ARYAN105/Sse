package com.fsl.fwk.utils;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.fsl.fwk.constants.CarCustomConstants;

public class CarResponseParser {
	Document doc;
	private ArrayList<String> custIds = new ArrayList<String>();

	public ArrayList<String> getCustIds() {
		return custIds;
	}

	public CarResponseParser(String xmlString) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xmlString));
			doc = db.parse(is);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String getNodeStr(String tagName, String nodeName) {
		String resStr1 = null;
		try {
			NodeList list = doc.getElementsByTagName(tagName);
			Element element = (Element) list.item(0);
			if (element != null) {
				if (element != null && element.getElementsByTagName(nodeName) != null
						&& element.getElementsByTagName(nodeName).item(0) != null
						&& element.getElementsByTagName(nodeName).item(0).getFirstChild() != null) {
					resStr1 = element.getElementsByTagName(nodeName).item(0).getFirstChild().getNodeValue();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resStr1;
	}

	public String getNodeValue(String TageName, String nodeName) {
		return getNodeStr(TageName, nodeName);
	}

	public ArrayList<HashMap<String, String>> getCarRepeatedDataFromXml(String parentTag, String rootTagName,
			ArrayList<String> tagName) {

		ArrayList<String> accountnotrack = new ArrayList<String>();
		ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
		HashMap<String, String> hashMap = null;
		NodeList nodeList = doc.getElementsByTagName(parentTag);
		for (int j = 0; j < nodeList.getLength(); j++) {
			Node node = nodeList.item(j);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element element = (Element) node;
				if (element.hasChildNodes()) {
					String customerid = "";
					NodeList list1 = element.getElementsByTagName(CarCustomConstants.CustomerID);
					try {
						if (list1 != null && list1.getLength() > 0) {
							if (list1.item(0) != null && list1.item(0).getFirstChild() != null) {
								customerid = list1.item(0).getFirstChild().getNodeValue();
								if (!custIds.contains(customerid)) {
									custIds.add(customerid);
								}
							}
						}
					} catch (Exception ex) {
						ex.printStackTrace();
//						logger.debug("Error While parsing insta Card" + ex.getMessage());
//						logger.error("Error While parsing insta Card", ex);
					}
					NodeList list2 = element.getElementsByTagName(rootTagName);
					for (int k = 0; k < list2.getLength(); k++) {
						hashMap = new HashMap<String, String>();
						hashMap.put(CarCustomConstants.CustomerID, customerid);
						// Snapwork change 11 August Insta CC Start end
						String resStr1 = "";
						Element element2 = (Element) list2.item(k);
						String accno = "";
						for (int i = 0; i < tagName.size(); i++) {
							try {
								resStr1 = element2.getElementsByTagName(tagName.get(i)).item(0).getFirstChild()
										.getNodeValue() != null
												? element2.getElementsByTagName(tagName.get(i)).item(0).getFirstChild()
														.getNodeValue()
												: "";

							} catch (Exception e) {
								resStr1 = "";
							}

							hashMap.put(tagName.get(i), resStr1);
							if (tagName.get(i).equalsIgnoreCase(CarCustomConstants.AccNum)) {
								accno = resStr1;
							}
						}
						if (!accno.equals("") && !accountnotrack.contains(accno)) {
							accountnotrack.add(accno);
							list.add(hashMap);
						}

					}
				}
			}
		}
		accountnotrack.clear();
		accountnotrack = null;
		return list;
	}
}
