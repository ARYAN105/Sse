package com.fsl.fwk.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.tcs.fwk.model.BaseModel;

public class FSLBankMstr extends BaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = "com.fsl.fwk.model.FSLBankMstModel".hashCode();
	
	@JsonProperty(value="bankNm")
	@JsonInclude(Include.NON_EMPTY)
	private String bankNm;
	
	@JsonProperty(value="ifscCd")
	@JsonInclude(Include.NON_EMPTY)
	private String ifscCd;
	
	@JsonProperty(value="ifscInit")
	@JsonInclude(Include.NON_EMPTY)
	private String ifscInit;

	public String getBankNm() {
		return bankNm;
	}

	public void setBankNm(String bankNm) {
		this.bankNm = bankNm;
	}

	public String getIfscCd() {
		return ifscCd;
	}

	public void setIfscCd(String ifscCd) {
		this.ifscCd = ifscCd;
	}

	public String getIfscInit() {
		return ifscInit;
	}

	public void setIfscInit(String ifscInit) {
		this.ifscInit = ifscInit;
	}

	
}
