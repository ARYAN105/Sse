package com.fsl.fwk.utils;

import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionHelper extends EncDecHelper {
  
  /*public byte[] encodeToBase64(byte[] input) {
    return Base64.getEncoder().encode(input);
  }
  
  public byte[] decodeFromBase64(byte[] input) {
    return Base64.getDecoder().decode(input);
  }*/
  
  public SecretKey generateKey(EncDecMode algo)
      throws NoSuchAlgorithmException {
    KeyGenerator keyGenerator = KeyGenerator.getInstance(algo.name());
    keyGenerator.init(256);
    return keyGenerator.generateKey();
  }
  
  public PublicKey getPublic(byte[] publicKey, EncDecMode mode)
      throws GeneralSecurityException {
    X509EncodedKeySpec spec = new X509EncodedKeySpec(decodeFromBase64(publicKey));
    KeyFactory         kf   = KeyFactory.getInstance(mode.name());
    return kf.generatePublic(spec);
  }
  
  public PublicKey getPublicKeyFromPrivateKey(PrivateKey pkcs8PrivateKey, EncDecMode mode)
      throws GeneralSecurityException {
    RSAPrivateCrtKey privk         = (RSAPrivateCrtKey) pkcs8PrivateKey;
    RSAPublicKeySpec publicKeySpec = new RSAPublicKeySpec(privk.getModulus(), privk.getPublicExponent());
    KeyFactory       keyFactory    = KeyFactory.getInstance(mode.name());
    return keyFactory.generatePublic(publicKeySpec);
  }
  
  public SecretKeySpec generateSecretKey(int length, EncDecMode algorithm) {
    SecureRandom rnd = new SecureRandom();
    byte[]       key = new byte[length];
    rnd.nextBytes(key);
    return new SecretKeySpec(key, algorithm.name());
  }
  
  /*public SecretKeySpec getSecretKey(byte[] keyBytes, String algorithm) {
    return new SecretKeySpec(keyBytes, algorithm);
  }*/
  
  public byte[] generateIv(String cipherAlgorithm)
      throws GeneralSecurityException {
    Cipher       cipher = Cipher.getInstance(cipherAlgorithm);
    SecureRandom random = SecureRandom.getInstanceStrong();
    byte[]       iv     = new byte[cipher.getBlockSize()];
    random.nextBytes(iv);
    return iv;
  }
  
  public byte[] encrypt(byte[] input, PublicKey key, String cipherAlgorithm)
      throws GeneralSecurityException {
    Cipher cipher = Cipher.getInstance(cipherAlgorithm);
    cipher.init(Cipher.ENCRYPT_MODE, key);
    return cipher.doFinal(input);
  }
  
  public byte[] encrypt(byte[] input, SecretKeySpec key, String cipherAlgorithm)
      throws GeneralSecurityException {
    Cipher cipher = Cipher.getInstance(cipherAlgorithm);
    cipher.init(Cipher.ENCRYPT_MODE, key);
    return cipher.doFinal(input);
  }
  
  public byte[] encrypt(byte[] input, SecretKeySpec key, String cipherAlgorithm, IvParameterSpec ivSpec)
      throws GeneralSecurityException {
    Cipher cipher = Cipher.getInstance(cipherAlgorithm);
    cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
    return cipher.doFinal(input);
  }
  
  public byte[] encrypt(byte[] input, SecretKeySpec key, String cipherAlgorithm, GCMParameterSpec gcmParameterSpec)
      throws GeneralSecurityException {
    Cipher cipher = Cipher.getInstance(cipherAlgorithm);
    cipher.init(Cipher.ENCRYPT_MODE, key, gcmParameterSpec);
    return cipher.doFinal(input);
  }
  
  public byte[] mergeTwoByteArrays(byte[] arrayOne, byte[] arrayTwo) {
    byte[] mergedArray = new byte[arrayOne.length + arrayTwo.length];
    System.arraycopy(arrayOne, 0, mergedArray, 0, arrayOne.length);
    System.arraycopy(arrayTwo, 0, mergedArray, arrayOne.length, arrayTwo.length);
    return mergedArray;
  }
  
}
