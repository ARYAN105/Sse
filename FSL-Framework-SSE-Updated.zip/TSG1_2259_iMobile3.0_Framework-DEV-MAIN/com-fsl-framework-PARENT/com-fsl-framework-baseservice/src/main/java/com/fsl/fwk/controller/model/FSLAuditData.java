package com.fsl.fwk.controller.model;

import lombok.Data;

@Data
public class FSLAuditData {
	
	private String transactionRefId;
	
	private String amount;
	
	private String accountNo;
	
	private boolean isFailure = true;
	
	private String stan;
}
