package com.fsl.fwk.controller.notification;

import org.springframework.core.env.Environment;

import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.service.MWService;

public interface IFSLEmailEventPublisher {
	
	public boolean publishFSLEmailEvent(ISessionVO sessVO, EmailDataVO emailDataVO, IMWRequestAddOn reqAddOn,
			MWService mwService);
	
	public void publishFSLEmailEventAsync(ISessionVO sessVO, EmailDataVO emailDataVO, IMWRequestAddOn reqAddOn,
			MWService mwService);
	
	default boolean isEmailEventEnable(ISessionVO sessVO, Environment env, MWService mwService) {
		boolean isPublishEvent = false;
	
		String defaultEnable = env.getProperty("FSL.EMAIL.EVENT.DEFAULT.enable");
		if (defaultEnable == null || defaultEnable.trim().isBlank()) {
			throw new SystemException(FwkResponseStatus.CODING_CONFIG_ERROR,
					"Default value of FSL.EMAIL.EVENT.DEFAULT.enable cannot be null or empty");
		} else {
			isPublishEvent = "1".equals(
					env.getProperty("FSL.EMAIL.EVENT." + mwService.myServiceID() + ".enable", defaultEnable).trim());
		}
		
		AppLogger.debug(sessVO, "Email Event for service : " + mwService.myServiceID() + " is " + (isPublishEvent ? "enabled" : "disabled"));
		
		return isPublishEvent;		
	};

}
