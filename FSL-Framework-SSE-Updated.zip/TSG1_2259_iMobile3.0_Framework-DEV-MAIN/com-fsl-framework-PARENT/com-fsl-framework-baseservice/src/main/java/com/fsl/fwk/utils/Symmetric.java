package com.fsl.fwk.utils;

import java.security.GeneralSecurityException;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Symmetric {
  public byte[] decrypt(byte[] encryptedContent, byte[] iv, byte[] key, EncDecMode decryptionMode, String decryptionAlgo)
      throws GeneralSecurityException {
    DecryptionHelper helper    = new DecryptionHelper();
    SecretKeySpec    secretKey = helper.getSecretKey(key, decryptionMode);
    return helper.decrypt(encryptedContent, secretKey, decryptionAlgo, iv);
  }
  
  public byte[] encrypt(byte[] content, byte[] iv, byte[] key, EncDecMode encryptionMode, String encryptionAlgo)
      throws GeneralSecurityException {
    EncryptionHelper helper    = new EncryptionHelper();
    SecretKeySpec    secretKey = helper.getSecretKey(key, encryptionMode);
    IvParameterSpec  ivParams  = new IvParameterSpec(iv);
    return helper.encrypt(content, secretKey, encryptionAlgo, ivParams);
  }
  
  public byte[] encrypt(byte[] content, byte[] key, EncDecMode encryptionMode, String encryptionAlgo)
      throws GeneralSecurityException {
    EncryptionHelper helper    = new EncryptionHelper();
    SecretKeySpec    secretKey = helper.getSecretKey(key, encryptionMode);
    return helper.encrypt(content, secretKey, encryptionAlgo);
  }
  
  public static byte[] encryptGCMTest(byte[] content, SecretKey key, byte[] IV)
      throws GeneralSecurityException {
    // Get Cipher Instance
    Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
    // Create SecretKeySpec
    SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");
    // Create GCMParameterSpec
    GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(16 * 8, IV);
    // Initialize Cipher for ENCRYPT_MODE
    cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmParameterSpec);
    // Perform Encryption
    
    return cipher.doFinal(content);
  }
  
  public static String decryptGCMTest(byte[] cipherText, SecretKey key, byte[] IV)
      throws GeneralSecurityException {
    // Get Cipher Instance
    Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
    // Create SecretKeySpec
    SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");
    // Create GCMParameterSpec
    GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(16 * 8, IV);
    // Initialize Cipher for DECRYPT_MODE
    cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmParameterSpec);
    // Perform Decryption
    byte[] decryptedText = cipher.doFinal(cipherText);
    
    return new String(decryptedText);
  }
  
  //For WEB APIGEE
  public byte[] encryptGCM(byte[] content, byte[] iv, byte[] key, EncDecMode encryptionMode, String encryptionAlgo)
      throws GeneralSecurityException {
    EncryptionHelper helper           = new EncryptionHelper();
    SecretKeySpec    secretKey        = helper.getSecretKey(key, encryptionMode);
    GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(16 * 8, iv);
    
    return helper.encrypt(content, secretKey, encryptionAlgo, gcmParameterSpec);
  }
  
  public byte[] decryptGCM(byte[] encryptedContent, byte[] iv, byte[] key, EncDecMode decryptionMode, String decryptionAlgo)
      throws GeneralSecurityException {
    DecryptionHelper helper           = new DecryptionHelper();
    SecretKeySpec    secretKey        = helper.getSecretKey(key, decryptionMode);
    GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(16 * 8, iv);
    
    return helper.decrypt(encryptedContent, secretKey, decryptionAlgo, gcmParameterSpec);
  }
  
}
