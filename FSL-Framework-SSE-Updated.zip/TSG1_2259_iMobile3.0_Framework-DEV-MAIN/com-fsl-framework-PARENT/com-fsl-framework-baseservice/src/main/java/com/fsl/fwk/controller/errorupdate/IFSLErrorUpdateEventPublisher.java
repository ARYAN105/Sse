package com.fsl.fwk.controller.errorupdate;

import org.springframework.core.env.Environment;

import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.service.MWService;

public interface IFSLErrorUpdateEventPublisher {

	boolean publishFSLErrorEvent(ISessionVO sessVO, ErrorUpdateVO errorUpdateVO);

	default boolean isErrorEventEnable(ISessionVO sessVO, Environment env, MWService mwService) {
		boolean isPublishEvent = false;
		String serviceId = (mwService == null ? "" : mwService.myServiceID());

		String defaultEnable = env.getProperty("FSL.ERRORUPDATE.EVENT.DEFAULT.enable");
		if (defaultEnable == null || defaultEnable.trim().isBlank()) {
			throw new SystemException(FwkResponseStatus.CODING_CONFIG_ERROR,
					"Default value of FSL.ERRORUPDATE.EVENT.DEFAULT.enable cannot be null or empty");
		} else {
			isPublishEvent = "1"
					.equals(env.getProperty("FSL.ERRORUPDATE.EVENT." + serviceId + ".enable", defaultEnable).trim());
		}

		AppLogger.debug(sessVO,
				"Error Update Event for service : " + serviceId + " is " + (isPublishEvent ? "enabled" : "disabled"));

		return isPublishEvent;
	}

}

