package com.fsl.fwk.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.constants.FSLStatusConstants;
import com.fsl.fwk.controller.errorupdate.ErrorUpdateVO;
import com.fsl.fwk.controller.errorupdate.FSLErrorUpdateEventPublisher;
import com.fsl.fwk.controller.model.FSLError;
import com.tcs.fwk.cache.master.MasterDataConstants.MasterColumnsEnum;
import com.tcs.fwk.cache.master.client.MasterCacheColumnBuilder;
import com.tcs.fwk.cache.master.client.MasterCacheQuery;
import com.tcs.fwk.cache.master.client.MasterDataCacheClient;
import com.tcs.fwk.cache.master.client.MultiFieldInputBuilder;
import com.tcs.fwk.cache.master.model.IMasterRowEntity;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.util.GenericUtil;

@Service
public class FSLHelper {
  
  @Autowired
  Environment env;
  
  @Autowired
  MasterDataCacheClient dataCacheClient;
  
  @Autowired
  FSLErrorUpdateEventPublisher fslErrorUpdateEventPublisher;
  
  @Value("${FWK.EAIGATEWAY.DEFAULT.RESPONSEMSG}")
  String  defaultErrorMsg;

  protected List<FSLError> errorTransformation(ISessionVO sessVO, List<String> msgCdStringList) {
    List<FSLError> fslErrorlist = new ArrayList<>();
    
    for (String msgCd : msgCdStringList) {
      //FSL||94||Your transaction request is under process, kindly check your account statement before reinitiating the request
      AppLogger.debug(null, "Error transformation: " + msgCd);
      String errMsg     = null;
      String errCd      = null;
      String systemName = null;
      
      if (msgCd.contains(FSLConstants.ERRCD_DLMTR)) {
        List<Object> errorList = Arrays.asList((Object[]) msgCd.split(FSLConstants.ERRCD_DLMTR_REGEX));
        errCd      = (String) getListValue(errorList, 1);
        systemName = (String) getListValue(errorList, 0, FSLConstants.SYSTEM_NAME.DEH.toString());
        errMsg     = (String) getListValue(errorList, 2, "");
      }
      else {
        //94-Your transaction request is under process, kindly check your account statement before reinitiating the request
        //FSL|94-Your transaction request is under process, kindly check your account statement before reinitiating the request
        int index = msgCd.contains("-") ? msgCd.indexOf("-") : 0;
        if (index > 0) {
          errCd = msgCd.substring(0, index);
          int indexSysNm = msgCd.contains("|") ? msgCd.indexOf("|") : 0;
          systemName = FSLConstants.SYSTEM_NAME.DEH.toString();
          if (indexSysNm > 0) {
            systemName = errCd.substring(0, indexSysNm);
            errCd      = errCd.substring(indexSysNm + 1);
          }
          errMsg = msgCd.substring(index + 1);
        }
      }
      
      if ((errMsg != null) && (errCd != null) && (systemName != null)) {
        FSLError mstrFslError = errorLookup(sessVO,errCd, systemName, errMsg);
        if (GenericUtil.isNeitherNullNorEmpty(mstrFslError))
          fslErrorlist.add(mstrFslError);
        /*if (FSLConstants.SYSTEM_NAME.FSL.toString().equals(systemName) && GenericUtil.isNullOrEmpty(mstrFslError.getErrMsg())) {
          return fslErrorlist;
        }
        else {
          errorMsg.setErrCd(errCd);
          errorMsg.setErrMsg(GenericUtil.isNullOrEmpty(mstrFslError.getErrMsg()) ? errMsg : mstrFslError.getErrMsg());
          errorMsg.setErrTitle(mstrFslError.getErrTitle());
          fslErrorlist.add(errorMsg);
        }*/
      }
      else {
        AppLogger.info(sessVO, "Invalid Error Message Code : " + msgCd);
      }
    }
    return fslErrorlist;
  }
  
  public Map<String, Object> updateResMeta(ISessionVO sessVO, List<String> msgCds, Map<String, Object> meta) {
    List<FSLError> fslError = null;
    
    fslError = errorTransformation(sessVO, msgCds);
    if (GenericUtil.isNeitherNullNorEmpty(fslError) && (!fslError.isEmpty())) {
      if (meta == null)
        meta = new HashMap<>();
      meta.put(FSLStatusConstants.ERRORS_MSG_KEY, fslError);
    }
    return meta;
  }
  
  public List<String> parseMsgCds(List<String> msgCdStringList) {
    
    String ERROR_NEW_DELIMITER="||-";
    
    return msgCdStringList.stream().map(msg -> {
      if (msg.contains(ERROR_NEW_DELIMITER)) {
        //MS||101||-something went wrong
        int index = msg.lastIndexOf(ERROR_NEW_DELIMITER);
        
        return msg.substring(0, index) + FSLConstants.ERRCD_DLMTR
            + msg.substring(index + ERROR_NEW_DELIMITER.length());
      }
      //MS|101-something went wrong
      return msg;
    }).toList();
  }
  
  public Map<String, Object> updateResMeta(ISessionVO sessVO, List<String> msgCds) {
    return updateResMeta(sessVO, msgCds, null);
  }
	
  protected FSLError errorLookup(ISessionVO sessVO, String errCd, String sysNm, String errMsg) {
    FSLError resFslError = null;
    try {
      MasterCacheQuery           masterCacheQuery = getErrorFetchQuery(sysNm, errCd, errMsg);
      Iterable<IMasterRowEntity> masterRowEntity = null;
      try {
    	  masterRowEntity = dataCacheClient.findMasterRows_ByQuery(null, masterCacheQuery);
      } catch(Exception e) {
    	  AppLogger.error(sessVO, "Error Code not found in the Admin Portal for error code" + errCd + " :::::: " + e.getMessage(),null);
      }
      
      if (GenericUtil.isNeitherNullNorEmpty(masterRowEntity) && masterRowEntity.iterator().hasNext()) {
        IMasterRowEntity iMasterRowEntity = masterRowEntity.iterator().next();
        List<Object>     depcols          = iMasterRowEntity.getDependcols();
        
        resFslError = new FSLError();
        resFslError.setErrCd(errCd);
        resFslError.setErrMsg(iMasterRowEntity.getDesc().toString());
        resFslError.setErrTitle((String) getListValue(depcols, 4));
        resFslError.setActionCode((String) getListValue(depcols, 5));
      }
      else {
        ErrorUpdateVO errorUpdateVO = new ErrorUpdateVO();
        if (FSLConstants.SYSTEM_NAME.FSL.toString().equals(sysNm)) {
          errorUpdateVO.setServiceId(errMsg);
        }
        else {
          resFslError = new FSLError();
          resFslError.setErrCd(errCd);
          resFslError.setErrMsg(getErrorMessage(errCd, errMsg, sysNm));
        }
        errorUpdateVO.setErrorCode(errCd);
        errorUpdateVO.setErrorDesc(errMsg);
        errorUpdateVO.setSystemName(sysNm);
        
        AppLogger.info(sessVO, "checking new error update: " + errMsg);
        boolean publishStatus = fslErrorUpdateEventPublisher.publishFSLErrorEvent(sessVO, errorUpdateVO);
        AppLogger.info(sessVO, "checking error event status : " + publishStatus);
      }
      AppLogger.debug(sessVO, "Error lookup: " + errCd + "-" + sysNm + "-" + errMsg + "-"
          + (resFslError != null ? resFslError.getErrMsg() : null));
    }
    catch (Exception e) {
    	AppLogger.error(sessVO, "Error Code not found in the Admin Portal for error code" + errCd + " :::::: " + e.getMessage(),null);
    }
    
    return resFslError;
  }
  
  private MasterCacheQuery getErrorFetchQuery(String sysNm, String errCd, String srvId) {
    MasterCacheQuery masterCacheQuery = null;
    
    if (FSLConstants.SYSTEM_NAME.FSL.toString().equals(sysNm)) {
      masterCacheQuery = MasterCacheQuery.builder(null)
          .setMasterName(FSLConstants.MASTER_TYPE.ERRORSMSTR.toString())
          .where(MasterCacheColumnBuilder.col(MasterColumnsEnum.BASIC_COL_CODE),
              MultiFieldInputBuilder.doOr(false, errCd))
          .doExactSearch()
          .and(MasterCacheColumnBuilder.col(MasterColumnsEnum.COL_DEPCOLS, 2),
              MultiFieldInputBuilder.doOr(false, sysNm))
          .doExactSearch().and(MasterCacheColumnBuilder.col(MasterColumnsEnum.COL_DEPCOLS, 3),
              MultiFieldInputBuilder.doOr(false, srvId))
          .doExactSearch().build();
    }
    else {
      masterCacheQuery = MasterCacheQuery.builder(null)
          .setMasterName(FSLConstants.MASTER_TYPE.ERRORSMSTR.toString())
          .where(MasterCacheColumnBuilder.col(MasterColumnsEnum.BASIC_COL_CODE),
              MultiFieldInputBuilder.doOr(false, errCd))
          .doExactSearch().and(MasterCacheColumnBuilder.col(MasterColumnsEnum.COL_DEPCOLS, 2),
              MultiFieldInputBuilder.doOr(false, sysNm))
          .doExactSearch().build();
    }
    
    return masterCacheQuery;
  }
  
  private Object getListValue(List<Object> listData, int valIndex) {
    return getListValue(listData, valIndex, null);
  }
  
  private Object getListValue(List<Object> listData, int valIndex, Object defVal) {
    Object val = defVal;
    
    if ((listData != null) && (listData.size() >= valIndex + 1)) {
      val = listData.get(valIndex);
    }
    
    return GenericUtil.isNullOrEmpty(val) ? defVal : val;
  }
  
  private String getErrorMessage(String errCd, String errMsg, String system) {
	  return GenericUtil.isNullOrEmpty(errMsg) || errMsg.equalsIgnoreCase(errCd) || "null".equalsIgnoreCase(errMsg) ? defaultErrorMsg:errMsg.trim();
  }
  
}
