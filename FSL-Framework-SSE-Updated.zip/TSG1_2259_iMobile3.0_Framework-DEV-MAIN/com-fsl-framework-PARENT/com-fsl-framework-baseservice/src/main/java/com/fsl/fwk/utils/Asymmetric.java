package com.fsl.fwk.utils;

import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.PublicKey;

public class Asymmetric {
  public byte[] decrypt(byte[] encryptedContent, byte[] privateKey, EncDecMode decryptionMode, String decryptionAlgo)
      throws GeneralSecurityException {
    DecryptionHelper helper          = new DecryptionHelper();
    PrivateKey       pkcs8PrivateKey = helper.getPrivate(privateKey, decryptionMode);
    return helper.decrypt(encryptedContent, pkcs8PrivateKey, decryptionAlgo);
  }
  
  public byte[] encrypt(byte[] content, byte[] publicKey, EncDecMode encryptionMode, String encryptionAlgo)
      throws GeneralSecurityException {
    EncryptionHelper helper  = new EncryptionHelper();
    PublicKey        x509Key = helper.getPublic(publicKey, encryptionMode);
    return helper.encrypt(content, x509Key, encryptionAlgo);
  }
  
  public PublicKey getPubKey(byte[] publicKey, EncDecMode encryptionMode)
      throws GeneralSecurityException {
    EncryptionHelper helper  = new EncryptionHelper();
    return helper.getPublic(publicKey, encryptionMode);
  }
  
}
