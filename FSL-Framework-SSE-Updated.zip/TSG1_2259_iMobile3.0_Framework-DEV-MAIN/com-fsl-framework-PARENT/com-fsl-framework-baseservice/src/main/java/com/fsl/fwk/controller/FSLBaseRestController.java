package com.fsl.fwk.controller;

import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.fsl.fwk.controller.audit.IFSLAuditEventPublisher;
import com.fsl.fwk.utils.FSLHelper;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequestAddOn;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.model.RequestResponseModel;
import com.tcs.fwk.service.MWRestController;
import com.tcs.fwk.service.MWService;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;

/**
 * @author Tata Consultancy Services
 */
public abstract class FSLBaseRestController extends MWRestController {

  @Autowired
  FSLHelper fslHelper;
  
  @Autowired
  FSLControllerHelper fslControllerHelper;
  
  @Autowired(required = false)
  private IFSLAuditEventPublisher auditEventPublisher;
  
  @Autowired
  private Environment env;
  private boolean     isAuditEnable = false;
	
	@PostConstruct
	private void isAuditEventEnable() {
		isAuditEnable = IFSLAuditEventPublisher.isAuditEventEnable(null, env, myMWService(), auditEventPublisher);
	}

	@Override
	protected MWResponse<?> after_ServiceInvocation(ISessionVO sessVO, IMWRequest<?> mwRequest, MWResponse<?> mwResponse,
			MWService mwService, long startTime, MWRequestAddOn reqAddOn) {
		MWResponse<?> response = fslControllerHelper.afterServiceInvocation(sessVO, mwRequest, mwResponse, mwService, startTime, reqAddOn);
		
		if (auditEventPublisher != null) {
			auditEventPublisher.publishFSLAuditEvent(sessVO, mwRequest, response, mwService, startTime, reqAddOn, isAuditEnable);
		}
		
		return response;
	}
	
	@Override
	protected Map<String, String> customiseSchemaValidationErrors(ISessionVO sessVO,
			Map<String, String> mapValidationErrors, FwkResponseStatus statusCd) {
		Map<String, String> map = fslControllerHelper.customiseSchemaValidationErrors(sessVO, mapValidationErrors, statusCd);
		//TODO: Confirm if to perform audit here or NOT
		return map;
	}
  
  @Override
  public RequestResponseModel checkSecurity(HttpServletRequest httpRequest, IMWRequest<?> mwRequest,
      ISessionVO sessionVO)
      throws BusinessException {
    long tsTT = 0;
    long startTime = new Date().getTime();
    RequestResponseModel reqResModel = super.checkSecurity(httpRequest, mwRequest, sessionVO);
    tsTT = new Date().getTime() - startTime;

    startTime = new Date().getTime();
    RequestResponseModel restRes = fslControllerHelper.baseSecurityCheck(httpRequest, mwRequest, apiGatewaySecretConfigured, sessionVO,
        reqResModel,myMWService());
    AppLogger.info(sessionVO,
        String.format("Timetaken for security check: {ts:%s#fs:%s}", tsTT, (new Date().getTime() - startTime)));
    
    return restRes;
  }
  
  @Override
  protected Map<String, Object> a(ISessionVO sessionVO, IMWRequest<?> mwRequest, IMWRequestAddOn mwRequestAddOn, MWResponse<?> mwResponse) {
    return mwResponse.getMeta();
  }
  
  /*
  @Override
  public ResponseEntity<MWResponse<?>> a(ObjectNode arg0, Map<String, String> arg1) {
	ISessionVO sessVO = new SessionVO(super.a(((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest(), null));
	fslControllerHelper.logClientPayload(sessVO, arg0);
    return super.a(arg0, arg1);
  }
  */
}