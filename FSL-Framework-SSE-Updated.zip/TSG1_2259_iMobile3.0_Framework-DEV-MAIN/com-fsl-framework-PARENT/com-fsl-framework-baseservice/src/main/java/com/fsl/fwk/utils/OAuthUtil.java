package com.fsl.fwk.utils;

import java.util.function.UnaryOperator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.tcs.fwk.util.GenericUtil;

@Component
public class OAuthUtil {
  
  @Autowired
  Environment env;
  
  private UnaryOperator<String> isCorpOAuthEnabled = svcId -> GenericUtil.isNullOrEmpty(svcId)
      ? "FSL.EAIGATEWAY.CORP.OAUTH.DEFAULT.FLAG"
      : "FSL.EAIGATEWAY.CORP.OAUTH." + svcId + ".FLAG";
  
  public String checkOAuthEnabled(String svcId) {
    String defaultEnableProp  = isCorpOAuthEnabled.apply(null);
    String oauthEnableSvcProp = isCorpOAuthEnabled.apply(svcId);
    
    return GenericUtil.isNullOrEmpty(env.getProperty(oauthEnableSvcProp))
        ? env.getProperty(defaultEnableProp, "0")
        : env.getProperty(oauthEnableSvcProp);
  }
  
}
