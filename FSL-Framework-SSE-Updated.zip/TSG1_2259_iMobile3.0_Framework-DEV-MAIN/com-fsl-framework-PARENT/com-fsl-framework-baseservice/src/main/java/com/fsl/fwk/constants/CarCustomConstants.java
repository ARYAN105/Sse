package com.fsl.fwk.constants;

import java.util.Arrays;
import java.util.List;

public interface CarCustomConstants {

//	FsID constants
	static final String FSID_ETB = "2";
	static final String FSID_CCR = "3";
	static final String FSID_DEM = "7";
	static final String FSID_POC = "35";
	static final String FSID_TC = "36";
	static final String FSID_COMPN = "37";
	static final String FSID_NPS = "80";
	static final String[] PRUFSID = { "96", "97", "98", "99" };
	static final String[] LOANFSID = { "10", "11", "14", "21", "22", "202", "203", "302", "402", "404", "404", "405",
			"406", "407", "408", "409", "410", "411", "412", "413", "414", "415", "551" };

	static final String CAR_NRI_STATUS_TRUE = "Y";
	static final String CAR_NRI_STATUS_FALSE = "N";
	static final String PRIMARY_FLAG_TRUE = "Y";
	static final String PRIMARY_FLAG_FALSE = "N";
	static final String CUST_SEGMENT_GB = "GB|GB";
	static final String CUST_SEGMENT_NRI = "NRI|NRI";
	static final String CUST_SEGMENT_GPC = "GPC|GPC";

//	AccNoSubString Constants
	static final List<String> ACCNUM_SBA = Arrays.asList("01", "81");
	static final String ACCNUM_CCA = "05";
	static final String ACCNUM_PPF = "18";
	static final String ACCNUM_SSY = "19";
	static final String ACCNUM_BJU = "61";
	static final String ACCNUM_IWISH = "24";
	static final String[] ACCNUM_TDA_FD = { "10", "13", "14", "15", "31" };
	static final String ACCNUM_TDA_RD = "25";
	static final String ACCNUM_COMPN_CARD = "46295270";
	static final String ACCNUM_COMPN_PLUS = "46295271";

//	Account Type Constants
	static final String ACCTYPE_SBA = "SBA";
	static final String ACCTYPE_CCA = "CCA";
	static final String ACCTYPE_GL1 = "GL1";
	static final String ACCTYPE_IWISH = "iWish";
	static final String ACCTYPE_TDA = "TDA";
	static final String ACCTYPE_PPF = "PPF";
	static final String ACCTYPE_SSY = "SSY";
	static final String ACCTYPE_BJU = "BJU";
	static final String ACCTYPE_CCR = "CCR";
	static final String ACCTYPE_DEM = "DEM";
	static final String ACCTYPE_POC = "POC";
	static final String ACCTYPE_TC = "TC";
	static final String ACCTYPE_COMPN = "COMPN";
	static final String ACCTYPE_NPS = "NPS";
	static final String ACCTYPE_PRU = "Pru-insurence";
	static final String ACCTYPE_LAA = "LAA";

//	Account SubType Constants
	static final String ACCSUBTYPE_NRO = "NRO";
	static final String ACCSUBTYPE_NRE = "NRE";
	static final String ACCSUBTYPE_FD = "FD";
	static final String ACCSUBTYPE_RD = "RD";
	static final String ACCSUBTYPE_COMPANION = "Companion";
	static final String ACCSUBTYPE_COMPANION_CARD = "Companion Card";
	static final String ACCSUBTYPE_COMPANION_PLUS = "Companion Plus";

//	NRI Account Type Constants
	static final String NRIACCTYPE_NRO = "NRO";
	static final String NRIACCTYPE_NRE = "NRE";
	static final String NRIACCTYPE_FCNR = "FCNR";

//	BankHomeStatus Constants
	static final String BHS_NRO = "NRO";
	static final String BHS_NRE = "NRE";
	static final String BHS_CAANO = "CAANO";
	static final String BHS_CAANE = "CAANE";
	static final String BHS_CANUE = "CANUE";
	static final String BHS_SCHEMECD = "schemeCd";
	static final String BHS_LNBJU = "LNBJU";
	static final String BHS_SKNRO = "SKNRO";
	static final String BHS_SBNRO = "SBNRO";
	static final String BHS_SONRO = "SONRO";
	static final String BHS_SBNRE = "SBNRE";
	static final String BHS_SKNRE = "SKNRE";
	static final String BHS_SONRE = "SONRE";
	static final String BHS_CANRE = "CANRE";
	static final String BHS_RDNRO = "RDNRO";
	static final String BHS_RDNRE = "RDNRE";
	static final String BHS_RDMNE = "RDMNE";
	static final String GL_SCHEME_CODES = "CAGLP,CAGLA,CAGLN,CAGLF,CAGLW,IFLGN";
	static final String[] FCNR_SCHEME_CODES = { "CFCNE", "CFCNR", "CFDDM", "CFDEU", "CFDGB", "CFDJY", "CFDMC", "CFDUS",
			"CFMCD", "FDHDM", "FDHEU", "FDHGB", "FDHJY", "FDHMC", "FDHUS", "FDHYG", "FDHYR", "MCCFD", "FCNR" };
	static final String[] FD_NRE_SCHEME_CODES = { "CFDTE", "FDISE", "FDMTE", "FDQME", "SCNRE", "SFDHE", "SFDQE",
			"SFSTE", "SMDIE", "CFDEE", "FDQTE", "ADRNE", "FDNRE", "JHDNM", "JHDNQ", "NRECS", "NRETM", "NRETQ" };
	static final String[] FD_NRO_SCHEME_CODES = { "ADNRO", "CF80O", "CF80R", "CFDEO", "CFDER", "CFDTA", "FD90O",
			"FD90R", "FDISD", "FDISO", "FDMSO", "FDNRO", "FDQMO", "FDQTO", "FDRBO", "FDRBR", "FDRPO", "FMO80", "FQO80",
			"SCNRO", "SFDHO", "SFDQO", "SFSTO", "SMDIO", "NROCS", "NROTM", "NROTQ" };

//	User Relation Constants
	static final String NRI = "NRI";
	static final String SBA = "SBA";
	static final String CCR = "CCR";
	static final String LAA = "LAA";
	static final String PAYPK = "PAYPK";
	static final String BJU = "BJU";

//	Data Parsing Constants
	static final String PvtDataField48 = "PvtDataField48";
	static final String UserID = "UserID";
	static final String MobileNumber = "MobileNumber";
	static final String CustName = "CustName";
	static final String CustType = "CustType";
	static final String RelNum = "RelNum";
	static final String NRIStatus = "NRIStatus";
	static final String FsId = "FsId";
	static final String AccNum = "AccNum";
	static final String AcctName = "AcctName";
	static final String CustomerID = "CustomerID";
	static final String BankHomeStatus = "BankHomeStatus";
	static final String MinorStatus = "MinorStatus";
	static final String SER_NO = "SER_NO";
	static final String Record = "Record";
	static final String AccountDetails = "AccountDetails";
	static final String[] keyList = { "FsId", "AccNum", "AcctName", "BankHomeStatus", "SER_NO", "MinorStatus" };
	static final String DOB = "DOB";

}
