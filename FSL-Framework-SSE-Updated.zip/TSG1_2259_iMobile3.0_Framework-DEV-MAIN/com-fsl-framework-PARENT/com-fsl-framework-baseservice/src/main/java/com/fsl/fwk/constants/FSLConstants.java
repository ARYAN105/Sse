package com.fsl.fwk.constants;

import com.tcs.fwk.constants.FwkConstants;

/**
 * @author Tata Consultancy Services
 */
public interface FSLConstants extends FwkConstants {
  
  public static final String HEADERVAL_CHANNEL_DEFAULT = "iMobile3";
  public static final String FSL_USER_PROFILE          = "fslUserProfile";
  public static final String GCAREQUIRED               = "GCARequired";
  //Common Headers
  public static final String HEADER_APPVER = "appver";
  public static final String HEADER_RMTIP  = "rmtip";
  public static final String HEADER_IMEI   = "imei";
  public static final String HEADER_GCMTKN = "gcmtoken";
  //Falcon headers
  public static final String HEADER_POSTALCODE = "postalCode";
  public static final String HEADER_STREET     = "street";
  public static final String HEADER_CITY       = "city";
  public static final String HEADER_IPADDRESS  = "ipValue";
  public static final String HEADER_OSTYPE     = "osType";
  public static final String HEADER_NPCIAPPID  = "npciAppId";
  public static final String HEADER_VERSION  = "version";
  //Error Code Seperator
  public static final String ERRCD_DLMTR       = "||";
  public static final String ERRCD_DLMTR_REGEX = "\\|\\|";
  
  public static final String REDIS_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
  public static final String HEADER_AUTH="Authorization";
  public static final String HEADER_OAUTH_TOKEN="corp-oauth-token";
  public static final String BEARER_PFX="Bearer ";
  public static final String HEADER_HASH="hash";
  public static final String HMAC_SHA256_ALGORITHM="HmacSHA256";
  public static final String SHA256_ALGORITHM="SHA-256";
  public static final String IS_VALIDATED = "is_validated";
  public static final String REFRESH_FLAG = "refresh_flag";
  public static final String TXN_ID ="txnID";
  public static final String IOS ="ios";
  public static final char   VERSION_SEPARATOR='.';
  public static final String HASH_ENABLED ="1";
  public static final String REFRESH_FLAG_IGNORE="refresh-ignore";
  public static final int    MAX_DOTS_ALLOWED= 1;
  public static final String FSL_HASH="FslHash";
  //**************************************//
  //@formatter:off
	public enum USERID_TYPE { UID, MOB, CID, DID, MNL, LNM }
	//UserID(ETB_LI), MobileNo(NTB_LI), CustID, DeviceID(ETB_NLI), DeviceID(NTB_NLI), Standalone loan(LI)
	
	public enum ACC_TYPE { PAYPK }
	
	public enum MASTER_TYPE {
	  ERRORSMSTR,CARDTYPERANGE,CCPAMSTR,CREDBANKMSTR,CIBILMSTR,CIBILSTATEMSTR,MUTUALFUNDMSTR,LOVMSTR,
	  ALLBANKMSTR,POPBANKMSTR,BRANCHMSTR,BILLERMSTR,GLOBALBANKMSTR,MCCBLOCKLIST,PINCODEMSTR,CORPMSTR,BNFMSTR,CHEQUEBRMSTR,IBOXMSTR,MCCLIMITMSTR
	}
	
	public enum SYSTEM_NAME {DEH,FCRM,ICCM,PCMS,PRIME,CDCI,ICORE,UBPS,MONTRAN,BRE,DCMS,DNC,LOP,UPI,UPICIRCLE,
		RETAIL_FX,OMNIDOC,ICASH,INTEGRA,INSTBANK,MDM,MS,FALCON,FSSCMS,FINACLE,IWISH,DISCOVER,CKYC,FINNONE,FINNONENEO,CRM,
		FSL,AADHARVAULT,SETU,ISARKAR,SMSGW,CAR,UCJ,INTDMZ,DPSECURE,WMS,PIPHUB,NPCI,IPAY,FASTAGRIB,ICRM,CDP}
  //@formatter:on
  
  public enum USER_TYPE {
    ETBRI("ETB-RI"),
    ETBNRI("ETB-NRI"),
    NTB("NTB"),
    STDLA("STDLA"),
    STDCC("STDCC"),
    STDPL("STDPL");
    
    String headerUserType;
    
    USER_TYPE(String userType) {
      this.headerUserType = userType;
    }
    
    @Override
    public String toString() {
      return this.headerUserType;
    }
  }
  
  public enum DB_USER_TYPE {
    NTB("NTB"),
    STDLA("LAA"),
    ICICIRET("ICICIRET");
    
    String userType;
    
    DB_USER_TYPE(String userType) {
      this.userType = userType;
    }
    
    @Override
    public String toString() {
      return this.userType;
    }
    
  }
  
  public enum OS_TYPE {
    ANDROID("Android"),
    IOS("iOS");
    
    String osType;
    
    OS_TYPE(String osType) {
      this.osType = osType;
    }
    
    @Override
    public String toString() {
      return this.osType;
    }
    
  }

}
