//package com.fsl.fwk.controller.model;
//
//import lombok.Data;
//
///**
// * @author Tata Consultancy Services
// */
//@Data
//public class FSLEmbOrchResponseBody<T> extends FSLResponseBody {
//
//	private static final long serialVersionUID = "com.fsl.fwk.controller.model.FSLEmbOrchResponseBody".hashCode();
//	
//	private T serviceData;
//}
