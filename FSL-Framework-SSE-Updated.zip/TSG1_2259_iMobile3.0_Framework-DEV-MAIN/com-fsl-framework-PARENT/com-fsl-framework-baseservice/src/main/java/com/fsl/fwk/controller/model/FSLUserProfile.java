package com.fsl.fwk.controller.model;

import com.fsl.fwk.model.FSLCarResponse;
import com.tcs.fwk.model.BaseModel;

public class FSLUserProfile extends BaseModel {
	private static final long serialVersionUID = 1L;

	private String upiProfileID = "";
	private String langCode = "";
	private String userID = "";
	private String userdPref = "";
	private String userMOBNo = "";
	private String userEmail = "";
	private String userLogonTime = "";
	private String userdActiveFlag = "";
	private String userFname = "";
	private String userLname = "";
	private String userType = "";
	private String userBayID = "";
	@Deprecated
	private String userdXid = "";
	private String userdWldeviceID = "";
	private String userdAppver = "";
	private String userdGCAValidation = "";
	private String reactivationFlag = "";
	private String freeText = "";
	private String userdIMEI = "";
	private String userdTouchMFAEnable = "";
	private String primAccNo = "";
	private String userdOSType = "";
	private String userActivationDate = "";
	private String userReActivationDate = "";
	private String userPrimVpaId = "";
	private FSLCarResponse userCarResponse = null;
	private String userEmailAuth = "";
	private String userAccType = "";
	private String countryCode = "";
	private String mobWOCC = "";
	private String osFlag = "";
	private String carCustId = "";
	private String usrCreatedDate = "";
	private String userdprofiling = "";
	private String deviceBlockStatus = "";
	private String invalMpinCnt = "";
	private String upiElgChk = "";
	private String userConsent = "";
	private String terminateByConSession = "";
	private String fedId= "";
	private String userStatus = "";
	private String blockedDate = "";
	private String tfApplicable = "";
	private String tfValidation = "";
	private String mpin = "";
	private String mpin2 = "";
	

	
	public String getFedId() {
		return fedId;
	}

	public void setFedId(String fedId) {
		this.fedId = fedId;
	}

	public String getInvalMpinCnt() {
		return invalMpinCnt;
	}

	public void setInvalMpinCnt(String invalMpinCnt) {
		this.invalMpinCnt = invalMpinCnt;
	}

	public String getUpiProfileID() {
		return upiProfileID;
	}

	public void setUpiProfileID(String upiProfileID) {
		this.upiProfileID = upiProfileID;
	}

	public String getLangCode() {
		return langCode;
	}

	public void setLangCode(String langCode) {
		this.langCode = langCode;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserdPref() {
		return userdPref;
	}

	public void setUserdPref(String userdPref) {
		this.userdPref = userdPref;
	}

	public String getUserMOBNo() {
		return userMOBNo;
	}

	public void setUserMOBNo(String userMOBNo) {
		this.userMOBNo = userMOBNo;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserLogonTime() {
		return userLogonTime;
	}

	public void setUserLogonTime(String userLogonTime) {
		this.userLogonTime = userLogonTime;
	}

	public String getUserdActiveFlag() {
		return userdActiveFlag;
	}

	public void setUserdActiveFlag(String userdActiveFlag) {
		this.userdActiveFlag = userdActiveFlag;
	}

	public String getUserFname() {
		return userFname;
	}

	public void setUserFname(String userFname) {
		this.userFname = userFname;
	}

	public String getUserLname() {
		return userLname;
	}

	public void setUserLname(String userLname) {
		this.userLname = userLname;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserBayID() {
		return userBayID;
	}

	public void setUserBayID(String userBayID) {
		this.userBayID = userBayID;
	}

	public String getUserdXid() {
		return userdXid;
	}

	public void setUserdXid(String userdXid) {
		this.userdXid = userdXid;
	}

	public String getUserdWldeviceID() {
		return userdWldeviceID;
	}

	public void setUserdWldeviceID(String userdWldeviceID) {
		this.userdWldeviceID = userdWldeviceID;
	}

	public String getUserdAppver() {
		return userdAppver;
	}

	public void setUserdAppver(String userdAppver) {
		this.userdAppver = userdAppver;
	}

	public String getUserdGCAValidation() {
		return userdGCAValidation;
	}

	public void setUserdGCAValidation(String userdGCAValidation) {
		this.userdGCAValidation = userdGCAValidation;
	}

	public String getReactivationFlag() {
		return reactivationFlag;
	}

	public void setReactivationFlag(String reactivationFlag) {
		this.reactivationFlag = reactivationFlag;
	}

	public String getFreeText() {
		return freeText;
	}

	public void setFreeText(String freeText) {
		this.freeText = freeText;
	}

	public String getUserdIMEI() {
		return userdIMEI;
	}

	public void setUserdIMEI(String userdIMEI) {
		this.userdIMEI = userdIMEI;
	}

	public String getUserdTouchMFAEnable() {
		return userdTouchMFAEnable;
	}

	public void setUserdTouchMFAEnable(String userdTouchMFAEnable) {
		this.userdTouchMFAEnable = userdTouchMFAEnable;
	}

	public String getPrimAccNo() {
		return primAccNo;
	}

	public void setPrimAccNo(String primAccNo) {
		this.primAccNo = primAccNo;
	}

	public String getUserdOSType() {
		return userdOSType;
	}

	public void setUserdOSType(String userdOSType) {
		this.userdOSType = userdOSType;
	}

	public String getUserActivationDate() {
		return userActivationDate;
	}

	public void setUserActivationDate(String userActivationDate) {
		this.userActivationDate = userActivationDate;
	}

	public String getUserReActivationDate() {
		return userReActivationDate;
	}

	public void setUserReActivationDate(String userReActivationDate) {
		this.userReActivationDate = userReActivationDate;
	}

	public String getUserPrimVpaId() {
		return userPrimVpaId;
	}

	public void setUserPrimVpaId(String userPrimVpaId) {
		this.userPrimVpaId = userPrimVpaId;
	}

	public FSLCarResponse getUserCarResponse() {
		return userCarResponse;
	}

	public void setUserCarResponse(FSLCarResponse userCarResponse) {
		this.userCarResponse = userCarResponse;
	}

	public String getUserEmailAuth() {
		return userEmailAuth;
	}

	public void setUserEmailAuth(String userEmailAuth) {
		this.userEmailAuth = userEmailAuth;
	}

	public String getUserAccType() {
		return userAccType;
	}

	public void setUserAccType(String userAccType) {
		this.userAccType = userAccType;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getMobWOCC() {
		return mobWOCC;
	}

	public void setMobWOCC(String mobWOCC) {
		this.mobWOCC = mobWOCC;
	}

	public String getOsFlag() {
		return osFlag;
	}

	public void setOsFlag(String osFlag) {
		this.osFlag = osFlag;
	}

	public String getCarCustId() {
		return carCustId;
	}

	public void setCarCustId(String carCustId) {
		this.carCustId = carCustId;
	}

	public String getUsrCreatedDate() {
		return usrCreatedDate;
	}

	public void setUsrCreatedDate(String usrCreatedDate) {
		this.usrCreatedDate = usrCreatedDate;
	}

	public String getUserdprofiling() {
		return userdprofiling;
	}

	public void setUserdprofiling(String userdprofiling) {
		this.userdprofiling = userdprofiling;
	}

	public String getDeviceBlockStatus() {
		return deviceBlockStatus;
	}

	public void setDeviceBlockStatus(String deviceBlockStatus) {
		this.deviceBlockStatus = deviceBlockStatus;
	}

	public String getUpiElgChk() {
		return upiElgChk;
	}

	public void setUpiElgChk(String upiElgChk) {
		this.upiElgChk = upiElgChk;
	}

	public String getUserConsent() {
		return userConsent;
	}

	public void setUserConsent(String userConsent) {
		this.userConsent = userConsent;
	}
	
	public String getTerminateByConSession() {
    return terminateByConSession;
  }

  public void setTerminateByConSession(String terminateByConSession) {
    this.terminateByConSession = terminateByConSession;
  }

public String getUserStatus() {
	return userStatus;
}

public void setUserStatus(String userStatus) {
	this.userStatus = userStatus;
}

public String getBlockedDate() {
	return blockedDate;
}

public void setBlockedDate(String blockedDate) {
	this.blockedDate = blockedDate;
}

public String getTfApplicable() {
	return tfApplicable;
}

public void setTfApplicable(String tfApplicable) {
	this.tfApplicable = tfApplicable;
}

public String getTfValidation() {
	return tfValidation;
}

public void setTfValidation(String tfValidation) {
	this.tfValidation = tfValidation;
}

public String getMpin() {
	return mpin;
}

public void setMpin(String mpin) {
	this.mpin = mpin;
}

public String getMpin2() {
	return mpin2;
}

public void setMpin2(String mpin2) {
	this.mpin2 = mpin2;
}


}
