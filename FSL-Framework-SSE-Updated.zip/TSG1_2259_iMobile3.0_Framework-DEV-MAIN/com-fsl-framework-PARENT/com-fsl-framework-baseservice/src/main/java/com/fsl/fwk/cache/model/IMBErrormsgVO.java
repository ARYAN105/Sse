package com.fsl.fwk.cache.model;

import java.io.Serializable;

import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.TagIndexed;
import com.tcs.fwk.data.model.BaseEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
//@Table(name = "IMB_ADM_NEW_MESSAGE_DTLS")
@Builder 
@Document("AnMD")
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@Entity 
public class IMBErrormsgVO implements BaseEntity,Serializable{
	private static final long serialVersionUID = IMBErrormsgVO.class.hashCode();
	
	@Id
	@org.springframework.data.annotation.Id
	@TagIndexed
	private int mID;//MSG_ID
	@TagIndexed
	private String sNm;//SYSTEM_NAME
	@TagIndexed
	private String mCd;//MSG_CD
	
	private String mtxt;//MSG_TXT
	@TagIndexed
	private String sID;//SERVICE_ID
	@TagIndexed
	private String act;//ACTIVE
	

}

