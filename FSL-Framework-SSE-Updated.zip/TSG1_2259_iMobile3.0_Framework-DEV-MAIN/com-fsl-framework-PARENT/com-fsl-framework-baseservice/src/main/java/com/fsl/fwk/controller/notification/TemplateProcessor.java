package com.fsl.fwk.controller.notification;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.templateresolver.FileTemplateResolver;

import jakarta.annotation.PostConstruct;

@Configuration
public class TemplateProcessor {
	@Autowired
	Environment env;

	@Autowired
	private SpringTemplateEngine templateEngine;

	@PostConstruct
	public void initTemplateProcessor() {
		String templatePath = env.getRequiredProperty("FSL.EMAIL.TEMPLATES.FILE_LOCATION");

		// if (templateEngine == null)
		templateEngine = new SpringTemplateEngine();

		FileTemplateResolver resolver = new FileTemplateResolver();
		resolver.setPrefix(templatePath);
		resolver.setSuffix(".html");
		resolver.setTemplateMode("HTML");
		resolver.setOrder(templateEngine.getTemplateResolvers().size());
		resolver.setCacheable(true);
		templateEngine.addTemplateResolver(resolver);
	}

	public String processTemplate(String templateId, Map<String, String> params) {
		Context context = new Context();
		params.forEach(context::setVariable);

		return templateEngine.process(templateId, context);

	}

}
