package com.fsl.fwk.upi.fin.model;

import com.fsl.fwk.controller.model.FSLResponseBody;

import lombok.Data;

@Data
//@AllArgsConstructor
//@NoArgsConstructor
public class UpiFinIntegResBody extends FSLResponseBody {

	/**
	 * 
	 */
	private static final long serialVersionUID = "com.fsl.fwk.upi.fin.UpiFinIntegResBody".hashCode();

}
