package com.fsl.fwk.cache.model;

import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.TagIndexed;
import com.tcs.fwk.data.model.BaseEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder 
@Document("usrsdv")
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@Entity // Added to generate metamodel
public class IMBUserDevicesVO implements BaseEntity{
	@Id
	@org.springframework.data.annotation.Id
	@TagIndexed
	private String wDID;//USERD_WLDEVICEID
	@TagIndexed
	private String uID;//USERD_USER_ID
	private Integer pref;//USERD_PREF
	@TagIndexed
	private String mpin;//USERD_MPIN
	private Long sqId;//userd_seqid
	@TagIndexed
	private String imei;//USERD_IMEI
	//private String macId;
	private String nTkn;//USERD_NOTIFTOKEN
	//private String osver;
	//private String osTp;
	private String uAvr;//USERD_APPVER
	//private String userAgnt;
	private Integer actFlg;//USERD_ACTIVEFLAG
	//private String blckdBy;
	//private String blckdRsn;
	//private LocalDateTime blckdDt; // Confirm Date type
	//private LocalDateTime crDt; // Confirm Date type
	private String udtd;//userd_updated // Confirm Date type
	//@TagIndexed
	private String gca;//USERD_GCAVALIDATION
	//private String model;
	//private String saltKey;
	@TagIndexed
  private String mpin2;//USERD_MPIN2
	//@NumericIndexed
	//private Integer userdTocuhId;
	//private String userdXId;
	//private LocalDateTime pboCrDt; // Confirm Date type
	//private String pboUserId;
	//private String androidId;
	private String devStts;//device_status
	//private LocalDateTime jailBrkCrtDt; // Confirm Date type
	//private LocalDateTime jailBrkUpdtnDt; // Confirm Date type
	//private Integer faceId;
	//private Integer voiceId;
	private String tMFA;//USERD_TOUCH_MFA_ENABLE
	//private LocalDateTime mfaCrteDt; // Confirm Date type Date mfaUpdtDt;
	//private Character isRtd;
	//private LocalDateTime referalId; // Confirm Date type
	//private String reactvnFlg; 
	//private String freeTxt;
	//@TagIndexed
	private String crCid;//CARCUSTID
	private String upEgCk;//UPI_ELIGIBILTY_CHECK
	//private LocalDateTime simBoundTmstmp;
	private String rActFlg;//REACTIVATION_FLAG
	private String uOs;//USERD_OSTYPE
	private String uTfv;//USERD_TF_VALIDATION
	private String uTfa;//USERD_TF_APPLICABLE
	private String uBr;//USERD_BLOCKED_REASON
}
