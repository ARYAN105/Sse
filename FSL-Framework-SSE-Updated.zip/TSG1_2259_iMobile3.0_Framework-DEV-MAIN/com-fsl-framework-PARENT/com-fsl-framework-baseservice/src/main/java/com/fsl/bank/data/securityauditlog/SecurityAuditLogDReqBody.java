package com.fsl.bank.data.securityauditlog;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tcs.fwk.logger.masking.MaskRule;
import com.tcs.fwk.logger.masking.MaskSensitive;
import com.tcs.fwk.logger.masking.Sensitive;
import com.tcs.fwk.model.BaseRequestBody;
import com.tcs.fwk.model.MWRequest;
import com.tcs.fwk.model.MWResponse;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor
@AllArgsConstructor
@MaskSensitive
public class SecurityAuditLogDReqBody extends BaseRequestBody {
    private static final long serialVersionUID = "com.fsl.com.data.securityauditlog.SecurityAuditLogDReqBody".hashCode();
    
    @JsonProperty("invkrSvc")
    private String invkrSvc;
    
    @JsonProperty("trnsEdDt")
    private String trnsEndDt;
    
    @JsonProperty("trnsStDt")
    private String trnsStrtDt;
    
    @JsonProperty("stsCd")
    private Integer statusCd;
    
    @JsonProperty("req")
    private MWRequest<?> reqJson;
    
    @JsonProperty("res")
    private MWResponse<?> resJson;
    
    @Sensitive(rule = MaskRule.DIGIT)
    @JsonProperty("amnt")
    private String amnt;
    
    @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
    @JsonProperty("acc")
    private String acc;
    
    @JsonProperty("trnsRef")
    private String trnsRef;
    
    @JsonProperty("fail")
    private boolean fail;
    
    @JsonProperty("stan")
    private String stan;

    @JsonProperty("uid")
    private String uid;
    
    @JsonProperty("did")
    private String did;
    
    @JsonProperty("appVer")
    private String appVer;
    
    @JsonProperty("rmtIp")
    private String rmtIp;
    
    @JsonProperty("hstNm")
    private String hstNm;
    
    @JsonProperty("hstIp")
    private String hstIp;
    
    @JsonProperty("usrAgnt")
    private String usrAgnt;
    
    @JsonProperty("dvcMdl")
    private String dvcMdl;
    
    @JsonProperty("errCd")
    private String errCd;
}
