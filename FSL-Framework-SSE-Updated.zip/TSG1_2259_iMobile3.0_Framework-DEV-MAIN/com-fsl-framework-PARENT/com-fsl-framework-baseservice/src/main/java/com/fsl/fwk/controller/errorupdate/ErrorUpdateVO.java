package com.fsl.fwk.controller.errorupdate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ErrorUpdateVO {

	private String errorCode;
	private String errorDesc;
	private String systemName;
	private String serviceId;

}
