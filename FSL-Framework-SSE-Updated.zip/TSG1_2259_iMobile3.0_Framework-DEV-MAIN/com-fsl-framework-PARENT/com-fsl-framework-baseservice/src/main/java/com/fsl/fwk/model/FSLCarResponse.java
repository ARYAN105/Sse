package com.fsl.fwk.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tcs.fwk.logger.masking.MaskRule;
import com.tcs.fwk.logger.masking.MaskSensitive;
import com.tcs.fwk.logger.masking.Sensitive;
import com.tcs.fwk.model.BaseModel;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
@MaskSensitive(enabled = "1")
public class FSLCarResponse extends BaseModel{
	
	private static final long serialVersionUID = "com.fsl.fwk.model.FSLCarResponse".hashCode();

  @JsonProperty("uId")
	private String userId;
  @JsonProperty("niSt")
	private String nriStatus;
  @JsonProperty("mNo")
	private String mobNo;
  @JsonProperty("uNm")
	private String userNm;
  @JsonProperty("uTp")
	private String userType;
  @JsonProperty("cSg")
	private String custSegment;
  @JsonProperty("bUID")
	private String bayUserId;
  @JsonProperty("rlNm")
	private String relNum;
  @JsonProperty("dOB")
	private String dateOfBirth;
  @JsonProperty("cDF")
	private String carDataFlag;
  @JsonProperty("cIds")
	private List<String> custIds;
  @JsonProperty("rels")
	private List<String> relationships;
  @JsonProperty("uDT")
  	private  String updateDateTime;
  
  @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
  @JsonProperty("sbAc")
	private List<String> sbaAccts;
  @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
  @JsonProperty("caAc")
	private List<String> ccaAccts;
  @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
  @JsonProperty("crAc")
	private List<String> ccrAccts;
  @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
  @JsonProperty("niAc")
  private List<String> nriAccts;
  @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
  @JsonProperty("noAc")
	private List<String> nroAccts;
  @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
  @JsonProperty("neAc")
	private List<String> nreAccts;
  @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
  @JsonProperty("syAc")
	private List<String> ssyAccts;
  @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
  @JsonProperty("pcAc")
	private List<String> pocAccts;
  @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
  @JsonProperty("otAc")
	private List<String> otherAccts;
  
  @JsonProperty("acl")
	private List<FSLCarAccount> accList;

}
