package com.fsl.fwk.utils;

import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.Map;

import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.PRAcroForm;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.util.GenericUtil;

public class FSLPDFUtils {

	public static String generatePDF(Map<String, String> pdfFields, String fileName, Boolean formFlattening,
			Float textSize) throws SystemException {

		String message = null;

		try {

			ByteArrayOutputStream outputStream = null;
			outputStream = new ByteArrayOutputStream();
			PdfReader reader = null;
			PdfStamper stamp = null;
			reader = new PdfReader(fileName);
			stamp = new PdfStamper(reader, outputStream);
			AcroFields pdfFormField = stamp.getAcroFields();
			PRAcroForm acroForm = reader.getAcroForm();
			acroForm.remove(new PdfName("XFA"));
			for (Map.Entry<String, String> entry : pdfFields.entrySet()) {
				if (GenericUtil.isNeitherNullNorEmpty(textSize)) {
					pdfFormField.setFieldProperty(entry.getKey(), "textsize", textSize, null);
				}
				pdfFormField.setField(entry.getKey(), entry.getValue());
			}
			stamp.setFormFlattening(formFlattening);
			stamp.close();
			byte[] pdfByteContent = outputStream.toByteArray();
			String encodeBytes =  Base64.getEncoder().encodeToString(pdfByteContent);
			outputStream.close();
			message = encodeBytes;

		} catch (Exception e) {
			throw new SystemException(e);
		}
		return message;

	}
}
