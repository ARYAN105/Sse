package com.fsl.fwk.utils;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsl.fwk.cache.model.IMBBlacklistVO;
import com.fsl.fwk.cache.model.IMBUserCarResponseVO;
import com.fsl.fwk.cache.model.IMBUserDeviceNCVO;
import com.fsl.fwk.cache.model.IMBUserDeviceNCVO_;
import com.fsl.fwk.cache.model.IMBUserDevicesVO;
import com.fsl.fwk.cache.model.IMBUserDevicesVO_;
import com.fsl.fwk.cache.model.IMBUsersNCVO;
import com.fsl.fwk.cache.model.IMBUsersVO;
import com.fsl.fwk.constants.CarCustomConstants;
import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.constants.FSLStatusConstants;
import com.fsl.fwk.controller.model.FSLUserProfile;
import com.fsl.fwk.model.FSLCarAccount;
import com.fsl.fwk.model.FSLCarResponse;
import com.fsl.fwk.model.FSLProfileTimeTaken;
import com.tcs.fwk.cache.master.client.MasterDataCacheClient;
import com.tcs.fwk.cache.rtwb.client.ReadThruCacheClient;
import com.tcs.fwk.db.filter.AbstractFilter;
import com.tcs.fwk.db.filter.Simple;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.util.GenericUtil;
import com.tcs.fwk.util.JSONUtil;

@Service
public class FSLReadDataHelper {

	@Autowired
	MasterDataCacheClient dataCacheClient;

	@Autowired
	private ReadThruCacheClient readclient;

	public FSLUserProfile loadUserProfile(ISessionVO sessionVO, String idType, String deviceId, String imei,
			String osType, String gcmTkn, String userType) {
		FSLUserProfile fslUserProfile = null;
		FSLProfileTimeTaken profileLoadTT = new FSLProfileTimeTaken();
		try {
			AppLogger.debug(sessionVO, "user profile request: " + osType + "|" + idType 
			    + "|" + deviceId + "|" + imei + "|" + gcmTkn + "|" + userType);
			long startTime = new Date().getTime();
	    fslUserProfile = getUserProfile(sessionVO, idType, deviceId, imei, userType, profileLoadTT);
      AppLogger.info(sessionVO, String.format("Timetaken for fetch user profile : %s - %s",
          (new Date().getTime() - startTime), profileLoadTT.toString()));
		}
		catch (Exception exception) {
			AppLogger.error(null, "Error While Fetching User profile", exception);
			throw new SystemException("Exception Occured in loadUserProfile::::::::::::::: " + exception.getMessage());
		}
		return fslUserProfile;
	}

	private FSLUserProfile getUserProfile(ISessionVO sessionVO, String idType, String deviceId, String imei, 
	    String userType, FSLProfileTimeTaken profileLoadTT) {
		if (GenericUtil.isNullOrEmpty(deviceId) || GenericUtil.isNullOrEmpty(idType)) {
			return null;
		}
		FSLUserProfile fslUserProfile = null;

		if ((FSLConstants.USERID_TYPE.UID.toString().equalsIgnoreCase(idType) 
				&& (!FSLConstants.USER_TYPE.NTB.toString().equalsIgnoreCase(userType)))
				|| FSLConstants.USERID_TYPE.DID.toString().equalsIgnoreCase(idType)
				|| FSLConstants.USERID_TYPE.LNM.toString().equalsIgnoreCase(idType)) {
			fslUserProfile = getUserProfileForUidDid(sessionVO, deviceId, imei, profileLoadTT);
		} else if ((FSLConstants.USERID_TYPE.UID.toString().equalsIgnoreCase(idType) 
				&& (FSLConstants.USER_TYPE.NTB.toString().equalsIgnoreCase(userType)))
				||FSLConstants.USERID_TYPE.MOB.toString().equalsIgnoreCase(idType)
				|| FSLConstants.USERID_TYPE.MNL.toString().equalsIgnoreCase(idType)) {
			fslUserProfile = getUserProfileForNC(sessionVO, deviceId, imei, profileLoadTT);
		}

		return fslUserProfile;
	}

	private FSLUserProfile getUserProfileForUidDid(ISessionVO sessionVO, String deviceId, String imei, 
	    FSLProfileTimeTaken profileLoadTT) {
		FSLUserProfile fslUserProfile = null;
		IMBUsersVO imbUsers = null;
		long startTime = new Date().getTime();
		IMBUserDevicesVO imbUserDevices = readclient.findById(sessionVO, IMBUserDevicesVO.class, deviceId).orElse(null);
		profileLoadTT.setDevIdRecFetchTime(new Date().getTime() - startTime);
		//AppLogger.debug(sessionVO, "Timetaken for fetch device rec: " + profileLoadTT.getDevIdRecFetchTime());

		if (GenericUtil.isNullOrEmpty(imbUserDevices)) {
			AppLogger.error(sessionVO, "Device record not found with request Device Id:" + deviceId, null);
			if (GenericUtil.isNeitherNullNorEmpty(imei)) {
				AbstractFilter imeiFilter = Simple.of(IMBUserDevicesVO.class).eq(IMBUserDevicesVO_.IMEI, imei);
				startTime = new Date().getTime();
				List<IMBUserDevicesVO> data = readclient.findAllByFilter(sessionVO, IMBUserDevicesVO.class, imeiFilter, null);
				profileLoadTT.setImeiRecFetchTime(new Date().getTime() - startTime);
		    //AppLogger.debug(sessionVO, "Timetaken for fetch device rec with IMEI: " + profileLoadTT.getImeiRecFetchTime());
				if (GenericUtil.isNeitherNullNorEmpty(data) && (!data.isEmpty()))
					imbUserDevices = data.get(0);
				else
					AppLogger.error(sessionVO, "Device record not found with request IMEI:" + imei, null);
			}
		}
		
		if (GenericUtil.isNeitherNullNorEmpty(imbUserDevices)) {
		  startTime = new Date().getTime();
      imbUsers = readclient.findById(sessionVO, IMBUsersVO.class, imbUserDevices.getUID()).orElse(null);
      profileLoadTT.setUserRecFetchTime(new Date().getTime() - startTime);
      //AppLogger.debug(sessionVO, "Timetaken for fetch user rec: " + profileLoadTT.getUserRecFetchTime());
      if (GenericUtil.isNullOrEmpty(imbUsers) ) {
				AppLogger.error(sessionVO, "Request Device Id :" + deviceId + " user record not found", null);
			}
			else {
				fslUserProfile = new FSLUserProfile();

				fslUserProfile.setReactivationFlag(
						GenericUtil.isNullOrEmpty(imbUserDevices.getRActFlg()) ? "" : imbUserDevices.getRActFlg());
				fslUserProfile.setUserBayID(GenericUtil.isNullOrEmpty(imbUsers.getBUID()) ? "" : imbUsers.getBUID());
				fslUserProfile.setUserdActiveFlag(
						GenericUtil.isNullOrEmpty(imbUserDevices.getActFlg()) ? "" : String.valueOf(imbUserDevices.getActFlg()));
				fslUserProfile
						.setUserdGCAValidation(GenericUtil.isNullOrEmpty(imbUserDevices.getGca()) ? "" : imbUserDevices.getGca());
				fslUserProfile.setUserdIMEI(GenericUtil.isNullOrEmpty(imbUserDevices.getImei()) ? "" : imbUserDevices.getImei());
				fslUserProfile.setUserdPref(
						GenericUtil.isNullOrEmpty(imbUserDevices.getPref()) ? "" : String.valueOf(imbUserDevices.getPref()));
				fslUserProfile.setUserdTouchMFAEnable(
						GenericUtil.isNullOrEmpty(imbUserDevices.getTMFA()) ? "" : String.valueOf(imbUserDevices.getTMFA()));
				fslUserProfile
						.setUserdWldeviceID(GenericUtil.isNullOrEmpty(imbUserDevices.getWDID()) ? "" : imbUserDevices.getWDID());
				fslUserProfile.setUserEmail(GenericUtil.isNullOrEmpty(imbUsers.getEmail()) ? "" : imbUsers.getEmail());
				fslUserProfile.setUserFname(GenericUtil.isNullOrEmpty(imbUsers.getFNm()) ? "" : imbUsers.getFNm());
				fslUserProfile.setUserID(GenericUtil.isNullOrEmpty(imbUserDevices.getUID()) ? "" : imbUserDevices.getUID());
				fslUserProfile.setUserLname(GenericUtil.isNullOrEmpty(imbUsers.getLNm()) ? "" : imbUsers.getLNm());
				fslUserProfile
						.setUserLogonTime(GenericUtil.isNullOrEmpty(imbUsers.getLgnTm()) ? "" : imbUsers.getLgnTm());
				fslUserProfile.setUserMOBNo(GenericUtil.isNullOrEmpty(imbUsers.getMob()) ? "" : imbUsers.getMob());
				fslUserProfile.setUpiProfileID(GenericUtil.isNullOrEmpty(imbUsers.getUpiProf()) ? "" : imbUsers.getUpiProf());
				fslUserProfile.setPrimAccNo(GenericUtil.isNullOrEmpty(imbUsers.getPrmAcc()) ? "" : imbUsers.getPrmAcc());
				fslUserProfile
						.setUserActivationDate(GenericUtil.isNullOrEmpty(imbUsers.getActDt()) ? "" : imbUsers.getActDt());
				fslUserProfile.setUserReActivationDate(
						GenericUtil.isNullOrEmpty(imbUsers.getRActDt()) ? "" : imbUsers.getRActDt());
				fslUserProfile.setUserPrimVpaId(GenericUtil.isNullOrEmpty(imbUsers.getVpaID()) ? "" : imbUsers.getVpaID());
				fslUserProfile.setCountryCode(GenericUtil.isNullOrEmpty(imbUsers.getCCo()) ? "" : imbUsers.getCCo());
				fslUserProfile.setMobWOCC(GenericUtil.isNullOrEmpty(imbUsers.getMNo()) ? "" : imbUsers.getMNo());
        //startTime = new Date().getTime();
        fslUserProfile.setUserCarResponse(getProcessedCarResponse(sessionVO, fslUserProfile.getUserBayID(), fslUserProfile.getUserID(), profileLoadTT));
        //AppLogger.debug(sessionVO, "Timetaken for process CAR response: " + (new Date().getTime() - startTime));
				fslUserProfile.setUserType(GenericUtil.isNullOrEmpty(imbUsers.getUTyp()) ? "" : imbUsers.getUTyp());
				fslUserProfile.setOsFlag(GenericUtil.isNullOrEmpty(imbUsers.getOsFl()) ? "" : imbUsers.getOsFl());
				fslUserProfile.setUserdOSType(GenericUtil.isNullOrEmpty(imbUserDevices.getUOs()) ? "" : imbUserDevices.getUOs());
				fslUserProfile.setCarCustId(GenericUtil.isNullOrEmpty(imbUserDevices.getCrCid()) ? "" : imbUserDevices.getCrCid());
				fslUserProfile.setUsrCreatedDate(GenericUtil.isNullOrEmpty(imbUsers.getUCr()) ? "" : imbUsers.getUCr());
				fslUserProfile.setUserdprofiling(GenericUtil.isNullOrEmpty(imbUsers.getUPf()) ? "" : imbUsers.getUPf());
				fslUserProfile.setUserAccType(GenericUtil.isNullOrEmpty(imbUsers.getUTyp()) ? "" : imbUsers.getUTyp());
				fslUserProfile.setUserdAppver(GenericUtil.isNullOrEmpty(imbUserDevices.getUAvr()) ? "" : imbUserDevices.getUAvr());
				fslUserProfile.setInvalMpinCnt(GenericUtil.isNullOrEmpty(imbUsers.getIMpc()) ? "" : imbUsers.getIMpc());
				fslUserProfile.setUpiElgChk(GenericUtil.isNullOrEmpty(imbUserDevices.getUpEgCk()) ? "" : imbUserDevices.getUpEgCk());
				fslUserProfile.setUserConsent(GenericUtil.isNullOrEmpty(imbUsers.getUCst()) ? "" : imbUsers.getUCst());
				fslUserProfile.setTerminateByConSession(GenericUtil.isNullOrEmpty(imbUsers.getTmcs()) ? "" : imbUsers.getTmcs());
				fslUserProfile.setFedId(GenericUtil.isNullOrEmpty(imbUsers.getFId())? "": imbUsers.getFId());
				fslUserProfile.setUserStatus(GenericUtil.isNullOrEmpty(imbUsers.getUSts()) ? "" : imbUsers.getUSts());
				fslUserProfile.setBlockedDate(GenericUtil.isNullOrEmpty(imbUsers.getBDt()) ? "" : imbUsers.getBDt());
				fslUserProfile.setTfApplicable(GenericUtil.isNullOrEmpty(imbUserDevices.getUTfa()) ? "" : imbUserDevices.getUTfa());
				fslUserProfile.setTfValidation(GenericUtil.isNullOrEmpty(imbUserDevices.getUTfv()) ? "" : imbUserDevices.getUTfv());
				fslUserProfile.setMpin(GenericUtil.isNullOrEmpty(imbUserDevices.getMpin()) ? "" : imbUserDevices.getMpin());
				fslUserProfile.setMpin2(GenericUtil.isNullOrEmpty(imbUserDevices.getMpin2()) ? "" : imbUserDevices.getMpin2());
			}
		}
		
		return fslUserProfile;
	}

	private FSLUserProfile getUserProfileForNC(ISessionVO sessionVO, String deviceId, String imei,
	    FSLProfileTimeTaken profileLoadTT) {
		FSLUserProfile fslUserProfile = null;
		IMBUsersNCVO imbUsersNc = null;
		IMBUserDeviceNCVO imbUserDevicesNc = readclient.findById(sessionVO, IMBUserDeviceNCVO.class, deviceId).orElse(null);

		if (GenericUtil.isNullOrEmpty(imbUserDevicesNc)) {
			AppLogger.error(sessionVO, "NC Device record not found with request Device Id:" + deviceId, null);
			if (GenericUtil.isNeitherNullNorEmpty(imei)) {
				AbstractFilter imeiFilter = Simple.of(IMBUserDeviceNCVO.class).eq(IMBUserDeviceNCVO_.IMEI, imei);

				List<IMBUserDeviceNCVO> data = readclient.findAllByFilter(sessionVO, IMBUserDeviceNCVO.class, imeiFilter, null);
				if (GenericUtil.isNeitherNullNorEmpty(data) && (!data.isEmpty()))
					imbUserDevicesNc = data.get(0);
				else
					AppLogger.error(sessionVO, "NC Device record not found with request IMEI:" + imei, null);
			}
		}
		
		if (GenericUtil.isNeitherNullNorEmpty(imbUserDevicesNc)) {
			imbUsersNc = readclient.findById(sessionVO, IMBUsersNCVO.class, imbUserDevicesNc.getMob()).orElse(null);
			if (GenericUtil.isNullOrEmpty(imbUsersNc) ) {
				AppLogger.error(sessionVO, "Request Device Id :" + deviceId + " user record not found", null);
			} 
			else {
				fslUserProfile = new FSLUserProfile();

				fslUserProfile.setUserdActiveFlag(GenericUtil.isNullOrEmpty(imbUserDevicesNc.getAFlg()) ? "" : imbUserDevicesNc.getAFlg());
				fslUserProfile.setUserdGCAValidation(GenericUtil.isNullOrEmpty(imbUserDevicesNc.getGca()) ? "" : imbUserDevicesNc.getGca());
				fslUserProfile.setUserdIMEI(GenericUtil.isNullOrEmpty(imbUserDevicesNc.getImei()) ? "" : imbUserDevicesNc.getImei());
				fslUserProfile.setUserdPref(GenericUtil.isNullOrEmpty(imbUserDevicesNc.getPref()) ? "" : imbUserDevicesNc.getPref().toString());
				fslUserProfile.setUserdWldeviceID(GenericUtil.isNullOrEmpty(imbUserDevicesNc.getWDID()) ? "" : imbUserDevicesNc.getWDID());
				fslUserProfile.setUserEmail(GenericUtil.isNullOrEmpty(imbUsersNc.getEmail()) ? "" : imbUsersNc.getEmail());
				fslUserProfile.setUserFname(GenericUtil.isNullOrEmpty(imbUsersNc.getFNm()) ? "" : imbUsersNc.getFNm());
				String mobNo = (GenericUtil.isNullOrEmpty(imbUsersNc.getMob()) ? "" : imbUsersNc.getMob());
				fslUserProfile.setUserID(GenericUtil.isNullOrEmpty(imbUsersNc.getUID()) ? mobNo : imbUsersNc.getUID());
				fslUserProfile.setUserBayID(GenericUtil.isNullOrEmpty(imbUsersNc.getBUID()) ? "" : imbUsersNc.getBUID());
				fslUserProfile.setUserLname(GenericUtil.isNullOrEmpty(imbUsersNc.getLNm()) ? "" : imbUsersNc.getLNm());
				fslUserProfile.setUserLogonTime(GenericUtil.isNullOrEmpty(imbUsersNc.getLgnTm()) ? "" : imbUsersNc.getLgnTm()); // Time to String
				fslUserProfile.setUserMOBNo(GenericUtil.isNullOrEmpty(imbUsersNc.getMob()) ? imbUsersNc.getUID() : imbUsersNc.getMob());
				fslUserProfile.setPrimAccNo(GenericUtil.isNullOrEmpty(imbUsersNc.getPrmAcc()) ? "" : imbUsersNc.getPrmAcc());
				fslUserProfile.setUserActivationDate(GenericUtil.isNullOrEmpty(imbUsersNc.getCDt()) ? "" : imbUsersNc.getCDt());// Time to String
				fslUserProfile.setUserReActivationDate(GenericUtil.isNullOrEmpty(imbUsersNc.getUDt()) ? "" : imbUsersNc.getUDt());// Time to String
				fslUserProfile.setUserPrimVpaId(GenericUtil.isNullOrEmpty(imbUsersNc.getVpaID()) ? "" : imbUsersNc.getVpaID());
				fslUserProfile.setUpiProfileID(GenericUtil.isNullOrEmpty(imbUsersNc.getUpiProf()) ? "" : imbUsersNc.getUpiProf());
				fslUserProfile.setUserEmailAuth(GenericUtil.isNullOrEmpty(imbUsersNc.getEAut()) ? "" : imbUsersNc.getEAut());
				fslUserProfile.setUserAccType(GenericUtil.isNullOrEmpty(imbUsersNc.getUTyp()) ? "" : imbUsersNc.getUTyp());
				fslUserProfile.setOsFlag(GenericUtil.isNullOrEmpty(imbUsersNc.getOsFl()) ? "" : imbUsersNc.getOsFl());
				fslUserProfile.setUserdOSType(GenericUtil.isNullOrEmpty(imbUserDevicesNc.getUOs()) ? "" : imbUserDevicesNc.getUOs());
				fslUserProfile.setCountryCode(GenericUtil.isNullOrEmpty(imbUsersNc.getCCo()) ? "" : imbUsersNc.getCCo());
				fslUserProfile.setMobWOCC(GenericUtil.isNullOrEmpty(imbUsersNc.getMNo()) ? "" : imbUsersNc.getMNo());
			}
		}

		return fslUserProfile;
	}

	/*old approach to get the user details from encrypted CarResponse
	public FSLCarResponse getProcessedCarResponse(ISessionVO sessVo, String bayUserId, String userId) {
		try {
			IMBUserCarResponseVO res = null;
			if (bayUserId != null && !bayUserId.isBlank()) {
				res = readclient.findById(sessVo, IMBUserCarResponseVO.class, bayUserId).orElse(null);
			}

			if (GenericUtil.isNullOrEmpty(res) || GenericUtil.isNullOrEmpty(res.getCRsp())) {
				if (userId != null && !userId.isBlank()) {
					res = readclient.findById(sessVo, IMBUserCarResponseVO.class, userId).orElse(null);
					AppLogger.debug(null, "fetching CAR RESPONSE using user id " + userId + " , found? " + (res != null));
				} else {
					return null;
				}
			}
			
			if (GenericUtil.isNullOrEmpty(res) || GenericUtil.isNullOrEmpty(res.getCRsp())) {
				AppLogger.info(null, "CAR RESPONSE RECORD NOT FOUND");
				return null;
			}
			AppLogger.debug(sessVo, "CAR RESPONSE: " + res.getCRsp());
	*/
	public FSLCarResponse getExtractCarResponse(ISessionVO sessVo, IMBUserCarResponseVO res) {
		try {
			byte[] xmlTxtByte = Base64.getDecoder().decode(res.getCRsp().getBytes());
			String xmlTxt = new String(xmlTxtByte, StandardCharsets.UTF_8);
			
			if (xmlTxt == null || xmlTxt.trim().isEmpty()) {
				AppLogger.info(null, "CAR RESPONSE NOT FOUND");
				return null;
			} 
			else {
				boolean	sbaFlag				= false;
				boolean	ccrFlag				= false;
				boolean	laaFlag				= false;
				boolean	byjuFlag			= false;
				boolean	paylaterFlag	= false;

				CarResponseParser parser = new CarResponseParser(xmlTxt);

				ArrayList<String> keyList = new ArrayList<>();
				for (String key : Arrays.asList(CarCustomConstants.keyList)) {
					keyList.add(key);
				}

				ArrayList<HashMap<String, String>> accountlists = parser.getCarRepeatedDataFromXml(
						CarCustomConstants.Record, CarCustomConstants.AccountDetails, keyList);

				StringBuilder iPruFedIds = new StringBuilder();
				ArrayList<String> sbaAccts = new ArrayList<>();
				ArrayList<String> nriaccounts = new ArrayList<>();
				ArrayList<String> nroaccounts = new ArrayList<>();
				ArrayList<String> nreaccounts = new ArrayList<>();
				ArrayList<String> ccaAccts = new ArrayList<>();
				ArrayList<String> ccrAccts = new ArrayList<>();
				ArrayList<String> pocketAccts = new ArrayList<>();
				ArrayList<String> result = new ArrayList<>();
				ArrayList<String> ssyAccts = new ArrayList<>();
				String carNriStatus = parser.getNodeValue(CarCustomConstants.PvtDataField48,
						CarCustomConstants.NRIStatus) == null ? CarCustomConstants.CAR_NRI_STATUS_FALSE
								: parser.getNodeValue(CarCustomConstants.PvtDataField48, CarCustomConstants.NRIStatus);

				List<FSLCarAccount> accList = new ArrayList<>();
				boolean primaryFlg = false;
				
				for (int k = 0; k < accountlists.size(); k++) {
					boolean skipfromcheck = false;
					HashMap<String, String> map = accountlists.get(k);
					String fsId = map.get(CarCustomConstants.FsId) == null ? ""
							: map.get(CarCustomConstants.FsId).trim();
					String accNum = map.get(CarCustomConstants.AccNum) == null ? ""
							: map.get(CarCustomConstants.AccNum).trim();
					String acctName = map.get(CarCustomConstants.AcctName) == null ? ""
							: map.get(CarCustomConstants.AcctName).trim();
					String customerid = map.get(CarCustomConstants.CustomerID) == null ? ""
							: map.get(CarCustomConstants.CustomerID).trim();
					String accountType = "";
					String accountSubType = "";
					String nriAccType = "";
					String bankHomeStatus = map.get(CarCustomConstants.BankHomeStatus) == null ? ""
							: map.get(CarCustomConstants.BankHomeStatus).trim();
					String minorStatus = map.get(CarCustomConstants.MinorStatus) == null ? ""
							: map.get(CarCustomConstants.MinorStatus).trim();
					String serNo = map.get(CarCustomConstants.SER_NO) == null ? ""
							: map.get(CarCustomConstants.SER_NO).trim();

					FSLCarAccount fslCarAcc = new FSLCarAccount();
					fslCarAcc.setCustId(customerid);
					fslCarAcc.setFsId(fsId);
					fslCarAcc.setAccName(acctName);
					fslCarAcc.setAccNo(accNum);
					fslCarAcc.setBankHomeStatus(bankHomeStatus);
					fslCarAcc.setMinorStatus(minorStatus);
					fslCarAcc.setSerNo(serNo);
					fslCarAcc.setPrimaryAccFlg(CarCustomConstants.PRIMARY_FLAG_FALSE);

					if (accNum.length() > 0) {

						if (fsId.equals(CarCustomConstants.FSID_ETB)
								&& CarCustomConstants.ACCNUM_SBA.contains(accNum.substring(4, 6))) {

							fslCarAcc.setPrimaryAccFlg(primaryFlg ? CarCustomConstants.PRIMARY_FLAG_FALSE
									: CarCustomConstants.PRIMARY_FLAG_TRUE);
							primaryFlg = true;
							accountType = CarCustomConstants.ACCTYPE_SBA;
							skipfromcheck = true;
							sbaFlag = true;
							if (carNriStatus != null
									&& carNriStatus.equalsIgnoreCase(CarCustomConstants.CAR_NRI_STATUS_TRUE)) {

								if (bankHomeStatus.contains(CarCustomConstants.BHS_NRO)
										|| CarCustomConstants.BHS_CAANO.equalsIgnoreCase(bankHomeStatus)
										|| bankHomeStatus.contains(CarCustomConstants.BHS_NRE)
										|| CarCustomConstants.BHS_CAANE.equalsIgnoreCase(bankHomeStatus)
										|| CarCustomConstants.BHS_CANUE.equalsIgnoreCase(bankHomeStatus)
										|| CarCustomConstants.BHS_SCHEMECD.equalsIgnoreCase(bankHomeStatus)) {
									nriaccounts.add(accNum);
								}

								if (bankHomeStatus.contains(CarCustomConstants.BHS_NRO)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_CAANO)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SKNRO)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SBNRO)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SONRO)) {
									nriAccType = CarCustomConstants.NRIACCTYPE_NRO;
									accountSubType = CarCustomConstants.ACCSUBTYPE_NRO;
									nroaccounts.add(accNum);
								}
								if (bankHomeStatus.contains(CarCustomConstants.BHS_NRE)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SBNRE)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SKNRE)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SONRE)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_CANRE)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_CAANE)) {
									nriAccType = CarCustomConstants.NRIACCTYPE_NRE;
									accountSubType = CarCustomConstants.ACCSUBTYPE_NRE;
									nreaccounts.add(accNum);
								}
							}

						} else if (fsId.equals(CarCustomConstants.FSID_ETB)
								&& accNum.substring(4, 6).equals(CarCustomConstants.ACCNUM_CCA)) {
							accountType = CarCustomConstants.ACCTYPE_CCA;
							if (carNriStatus != null
									&& carNriStatus.equalsIgnoreCase(CarCustomConstants.CAR_NRI_STATUS_TRUE)) {

								if (bankHomeStatus.contains(CarCustomConstants.BHS_NRO)
										|| CarCustomConstants.BHS_CAANO.equalsIgnoreCase(bankHomeStatus)
										|| bankHomeStatus.contains(CarCustomConstants.BHS_NRE)
										|| CarCustomConstants.BHS_CAANE.equalsIgnoreCase(bankHomeStatus)
										|| CarCustomConstants.BHS_CANUE.equalsIgnoreCase(bankHomeStatus)
										|| CarCustomConstants.BHS_SCHEMECD.equalsIgnoreCase(bankHomeStatus)) {
									nriaccounts.add(accNum);
								}

								if (bankHomeStatus.contains(CarCustomConstants.BHS_NRO)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_CAANO)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SKNRO)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SBNRO)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SONRO)) {
									nriAccType = CarCustomConstants.NRIACCTYPE_NRO;
									accountSubType = CarCustomConstants.ACCSUBTYPE_NRO;
									nroaccounts.add(accNum);
								}
								if (bankHomeStatus.contains(CarCustomConstants.BHS_NRE)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SBNRE)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SKNRE)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_SONRE)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_CANRE)
										|| bankHomeStatus.equals(CarCustomConstants.BHS_CAANE)) {
									nriAccType = CarCustomConstants.NRIACCTYPE_NRE;
									accountSubType = CarCustomConstants.ACCSUBTYPE_NRE;
									nreaccounts.add(accNum);
								}
							} else {
								String glSchemeCodes = CarCustomConstants.GL_SCHEME_CODES;
								if (!bankHomeStatus.trim().isEmpty() && glSchemeCodes != null
										&& glSchemeCodes.contains(bankHomeStatus)) {
									accountType = CarCustomConstants.ACCTYPE_GL1;
								}
							}
							skipfromcheck = true;
							sbaFlag = true;
						} else if (fsId.equals(CarCustomConstants.FSID_ETB)
								&& accNum.substring(4, 6).equals(CarCustomConstants.ACCNUM_IWISH)) {
							accountType = CarCustomConstants.ACCTYPE_IWISH;
							skipfromcheck = true;

						} else if (fsId.equals(CarCustomConstants.FSID_ETB)
								&& Arrays.asList(CarCustomConstants.ACCNUM_TDA_FD).contains(accNum.substring(4, 6))) {

							accountType = CarCustomConstants.ACCTYPE_TDA;
							accountSubType = CarCustomConstants.ACCSUBTYPE_FD;
							skipfromcheck = true;

							if ((carNriStatus != null)
									&& (carNriStatus.equalsIgnoreCase(CarCustomConstants.CAR_NRI_STATUS_TRUE))) {
								boolean fcnrResult = Arrays.asList(CarCustomConstants.FCNR_SCHEME_CODES)
										.contains(bankHomeStatus) ? true : false;
								boolean nreResult = Arrays.asList(CarCustomConstants.FD_NRE_SCHEME_CODES)
										.contains(bankHomeStatus);
								boolean nroResult = Arrays.asList(CarCustomConstants.FD_NRO_SCHEME_CODES)
										.contains(bankHomeStatus);
								if (fcnrResult) {
									nriAccType = CarCustomConstants.NRIACCTYPE_FCNR;
								} else if (nreResult) {
									nriAccType = CarCustomConstants.NRIACCTYPE_NRE;
								} else if (nroResult) {
									nriAccType = CarCustomConstants.NRIACCTYPE_NRO;
								}
							}

						} else if (fsId.equals(CarCustomConstants.FSID_ETB)
								&& accNum.substring(4, 6).equals(CarCustomConstants.ACCNUM_TDA_RD)) {
							accountType = CarCustomConstants.ACCTYPE_TDA;
							accountSubType = CarCustomConstants.ACCSUBTYPE_RD;
							skipfromcheck = true;
							if (carNriStatus != null
									&& carNriStatus.equalsIgnoreCase(CarCustomConstants.CAR_NRI_STATUS_TRUE)) {
								if (bankHomeStatus.equalsIgnoreCase(CarCustomConstants.BHS_RDNRO)) {
									nriAccType = CarCustomConstants.NRIACCTYPE_NRO;
								} else if (bankHomeStatus.equalsIgnoreCase(CarCustomConstants.BHS_RDNRE)
										|| bankHomeStatus.equalsIgnoreCase(CarCustomConstants.BHS_RDMNE)) {
									nriAccType = CarCustomConstants.NRIACCTYPE_NRE;
								}
							}
						} else if (fsId.equals(CarCustomConstants.FSID_ETB)
								&& accNum.substring(4, 6).equals(CarCustomConstants.ACCNUM_PPF)) {
							accountType = CarCustomConstants.ACCTYPE_PPF;
							skipfromcheck = true;
						} else if (fsId.equals(CarCustomConstants.FSID_ETB)
								&& accNum.substring(4, 6).equals(CarCustomConstants.ACCNUM_SSY)) {
							accountType = CarCustomConstants.ACCTYPE_SSY;
							skipfromcheck = true;

						} else if (fsId.equals(CarCustomConstants.FSID_ETB)
								&& accNum.substring(4, 6).equals(CarCustomConstants.ACCNUM_BJU)) {
							if (bankHomeStatus.equals(CarCustomConstants.BHS_LNBJU)) {
								accountType = CarCustomConstants.ACCTYPE_BJU;
							}
							if (accountlists.size() == 1) {
								byjuFlag = true;
							}
							skipfromcheck = true;

						} else if (fsId.equals(CarCustomConstants.FSID_CCR)) {
							accountType = CarCustomConstants.ACCTYPE_CCR;
							if (accNum.startsWith(CarCustomConstants.ACCNUM_COMPN_CARD)
									|| accNum.startsWith(CarCustomConstants.ACCNUM_COMPN_PLUS)) {
								accountSubType = CarCustomConstants.ACCSUBTYPE_COMPANION;
							}
							skipfromcheck = true;
							ccrFlag = true;
						} else if (fsId.equals(CarCustomConstants.FSID_DEM)) {
							accountType = CarCustomConstants.ACCTYPE_DEM;
							skipfromcheck = true;
						} else if (fsId.equals(CarCustomConstants.FSID_POC)) {
							accountType = CarCustomConstants.ACCTYPE_POC;
							skipfromcheck = true;
						} else if (fsId.equals(CarCustomConstants.FSID_TC)) {
							accountType = CarCustomConstants.ACCTYPE_TC;
							skipfromcheck = true;
						} else if (fsId.equals(CarCustomConstants.FSID_COMPN)) {
							accountType = CarCustomConstants.ACCTYPE_COMPN;
							if (accNum.startsWith(CarCustomConstants.ACCNUM_COMPN_CARD)) {
								accountSubType = CarCustomConstants.ACCSUBTYPE_COMPANION_CARD;
							} else if (accNum.startsWith(CarCustomConstants.ACCNUM_COMPN_PLUS)) {
								accountSubType = CarCustomConstants.ACCSUBTYPE_COMPANION_PLUS;
							}
						} else if (fsId.equals(CarCustomConstants.FSID_NPS)) {
							accountType = CarCustomConstants.ACCTYPE_NPS;
						}
						if (!skipfromcheck) {
							String insurence[] = CarCustomConstants.PRUFSID;
							if (Arrays.asList(insurence).contains(fsId)) {
								accountType = CarCustomConstants.ACCTYPE_PRU;
								skipfromcheck = true;
								if (iPruFedIds.length() == 0) {
									iPruFedIds.append(accNum);
								} else {
									iPruFedIds.append("|" + accNum);
								}
							}
						}
						if (!skipfromcheck) {
							String loan[] = CarCustomConstants.LOANFSID;
							if (Arrays.asList(loan).contains(fsId)) {
								accountType = CarCustomConstants.ACCTYPE_LAA;
								skipfromcheck = true;
								laaFlag = true;
							}
						}

					}

					fslCarAcc.setAccType(accountType);
					fslCarAcc.setAccSubType(accountSubType);

					switch (accountType) {
					case CarCustomConstants.ACCTYPE_SBA:
						sbaAccts.add(accNum);
						break;
					case CarCustomConstants.ACCTYPE_CCA:
						ccaAccts.add(accNum);
						break;
					case CarCustomConstants.ACCTYPE_CCR:
						ccrAccts.add(accNum);
						break;
					case CarCustomConstants.ACCTYPE_POC:
						pocketAccts.add(accNum);
						break;
					case CarCustomConstants.ACCTYPE_SSY:
						ssyAccts.add(accNum);
						break;
					case CarCustomConstants.ACCTYPE_GL1:
						ssyAccts.add(accNum);
						break;
					default:
						result.add(accNum);
						break;
					}

					fslCarAcc.setAccType(accountType);
					fslCarAcc.setAccSubType(accountSubType);
					fslCarAcc.setNriAccountType(nriAccType);

					accList.add(fslCarAcc);
				}
				ArrayList<String> relationships = new ArrayList<>();
				if (carNriStatus.equalsIgnoreCase(CarCustomConstants.CAR_NRI_STATUS_TRUE))
					relationships.add(CarCustomConstants.NRI);
				if (sbaFlag)
					relationships.add(CarCustomConstants.SBA);
				if (ccrFlag)
					relationships.add(CarCustomConstants.CCR);
				if (laaFlag)
					relationships.add(CarCustomConstants.LAA);
				if (paylaterFlag)
					relationships.add(CarCustomConstants.PAYPK);
				if (byjuFlag)
					relationships.add(CarCustomConstants.BJU);

				String userType = carNriStatus.equalsIgnoreCase(CarCustomConstants.CAR_NRI_STATUS_TRUE)
						? CarCustomConstants.NRI
						: sbaFlag ? CarCustomConstants.SBA
								: ccrFlag ? CarCustomConstants.CCR
										: laaFlag ? CarCustomConstants.LAA : CarCustomConstants.PAYPK;

				String custSegment = parser.getNodeValue(CarCustomConstants.PvtDataField48,
						CarCustomConstants.CustType);
				if (CarCustomConstants.CUST_SEGMENT_GB.equalsIgnoreCase(custSegment)
						&& CarCustomConstants.CAR_NRI_STATUS_TRUE.equalsIgnoreCase(carNriStatus)) {
					custSegment = CarCustomConstants.CUST_SEGMENT_NRI;
				} else if (CarCustomConstants.CUST_SEGMENT_NRI.equalsIgnoreCase(custSegment)
						&& CarCustomConstants.CAR_NRI_STATUS_FALSE.equalsIgnoreCase(carNriStatus)) {
					custSegment = CarCustomConstants.CUST_SEGMENT_GB;
				}
				String dateOfBirth = parser.getNodeValue(CarCustomConstants.PvtDataField48,
						CarCustomConstants.DOB);
				FSLCarResponse fslCarResponse = new FSLCarResponse();
				fslCarResponse.setUserId(
						parser.getNodeValue(CarCustomConstants.PvtDataField48, CarCustomConstants.UserID) == null ? ""
								: parser.getNodeValue(CarCustomConstants.PvtDataField48, CarCustomConstants.UserID));
				fslCarResponse.setNriStatus(carNriStatus);
				fslCarResponse.setMobNo(
						parser.getNodeValue(CarCustomConstants.PvtDataField48, CarCustomConstants.MobileNumber) == null
								? ""
								: parser.getNodeValue(CarCustomConstants.PvtDataField48,
										CarCustomConstants.MobileNumber));
				fslCarResponse.setUserNm(
						parser.getNodeValue(CarCustomConstants.PvtDataField48, CarCustomConstants.CustName) == null ? ""
								: parser.getNodeValue(CarCustomConstants.PvtDataField48, CarCustomConstants.CustName));
				fslCarResponse.setRelNum(
						parser.getNodeValue(CarCustomConstants.PvtDataField48, CarCustomConstants.RelNum) == null ? ""
								: parser.getNodeValue(CarCustomConstants.PvtDataField48, CarCustomConstants.RelNum));
				fslCarResponse.setDateOfBirth(dateOfBirth == null ? "" : dateOfBirth);
				fslCarResponse.setAccList(accList);
				fslCarResponse.setCcaAccts(ccaAccts);
				fslCarResponse.setCcrAccts(ccrAccts);
				fslCarResponse.setCustIds(parser.getCustIds());
				fslCarResponse.setCustSegment(custSegment);
				fslCarResponse.setNreAccts(nreaccounts);
				fslCarResponse.setNriAccts(nriaccounts);
				fslCarResponse.setNroAccts(nroaccounts);
				fslCarResponse.setOtherAccts(result);
				fslCarResponse.setPocAccts(pocketAccts);
				fslCarResponse.setRelationships(relationships);
				fslCarResponse.setSbaAccts(sbaAccts);
				fslCarResponse.setSsyAccts(ssyAccts);
				fslCarResponse.setUserType(userType);

				return fslCarResponse;
			}
		} catch (Exception e) {
			AppLogger.error(sessVo, "Exception Occured: ", e);
			return null;
		}
	}
	
	//getting user details from redis cache
	public FSLCarResponse getProcessedCarResponse(ISessionVO sessVo, String bayUserId, String userId,
	    FSLProfileTimeTaken profileLoadTT) {
		try {
			IMBUserCarResponseVO res = null;
			long startTime = new Date().getTime();
	    if (bayUserId != null && !bayUserId.isBlank()) {
				res = readclient.findById(sessVo, IMBUserCarResponseVO.class, bayUserId).orElse(null);
				profileLoadTT.setCarBIdRecFetchTime(new Date().getTime() - startTime);
	      //AppLogger.debug(sessVo, "Timetaken for get CAR resp bayId: " + profileLoadTT.getCarBIdRecFetchTime());
			}

			if (GenericUtil.isNullOrEmpty(res) || (GenericUtil.isNullOrEmpty(res.getCRsp()) && GenericUtil.isNullOrEmpty(res.getCRpj()))) {
				if (userId != null && !userId.isBlank()) {
				  startTime = new Date().getTime();
				  res = readclient.findById(sessVo, IMBUserCarResponseVO.class, userId).orElse(null);
				  profileLoadTT.setCarUIdRecFetchTime(new Date().getTime() - startTime);
	        //AppLogger.debug(sessVo, "Timetaken for get CAR resp userId(" + userId + "):" + profileLoadTT.getCarUIdRecFetchTime());
					//AppLogger.debug(null, "fetching CAR RESPONSE using user id " + userId + " , found? " + (res != null));
				}
				else {
					return null;
				}
			}
			
			if (GenericUtil.isNullOrEmpty(res) || (GenericUtil.isNullOrEmpty(res.getCRsp()) && GenericUtil.isNullOrEmpty(res.getCRpj()))) {
				AppLogger.info(null, "CAR RESPONSE RECORD NOT FOUND");
				return null;
      }
      
		FSLCarResponse fslCarResponse = null;
		if (GenericUtil.isNeitherNullNorEmpty(res.getCRsp())) {
			try {
				AppLogger.debug(sessVo, "Processing with XML CAR response...");
				startTime = new Date().getTime();
				fslCarResponse = getExtractCarResponse(sessVo, res);
				profileLoadTT.setCarXMLDataProcessTime(new Date().getTime() - startTime);
				// AppLogger.debug(sessVo, "Timetaken for process JSON CAR response: " + profileLoadTT.getCarJSONDataProcessTime());
			} catch (Exception e) {
				AppLogger.warn(sessVo, "Failed to process XML CAR response::" + e.getMessage());
			}
		}
      
		if (GenericUtil.isNullOrEmpty(fslCarResponse) && GenericUtil.isNeitherNullNorEmpty(res.getCRpj())) {
			try {
				AppLogger.debug(sessVo, "Processing with JSON CAR response...");
				startTime = new Date().getTime();
				byte[] jsonTxtByte = Base64.getDecoder().decode(res.getCRpj().getBytes());
				String jsonTxt = new String(jsonTxtByte, StandardCharsets.UTF_8);
				fslCarResponse = JSONUtil.static_deserializeJSONObj(sessVo, jsonTxt, FSLCarResponse.class);
				profileLoadTT.setCarJSONDataProcessTime(new Date().getTime() - startTime);
				// AppLogger.debug(sessVo, "Timetaken for process XML CAR response: " + profileLoadTT.getCarXMLDataProcessTime());
			} catch (Exception e) {
				AppLogger.warn(sessVo, "Failed to process JSON CAR response::" + e.getMessage());
			}
		}
	    
			//AppLogger.debug(sessVo, "fslCarResponse: " + fslCarResponse);
			return fslCarResponse;
		}
		catch (Exception e) {
			AppLogger.error(sessVo, "Exception Occured: ", e);
			return null;
		}
	}
	
	public String getDeviceBlockStatus(ISessionVO sessVo, String deviceID) {
    long startTime = new Date().getTime();
		if (GenericUtil.isNullOrEmpty(deviceID)) {
			AppLogger.info(sessVo, "Device id not found in request");
			return  FSLStatusConstants.blocked;
		}
		
		IMBBlacklistVO res = readclient.findById(sessVo, IMBBlacklistVO.class, deviceID).orElse(null);
    if (GenericUtil.isNullOrEmpty(res) || GenericUtil.isNullOrEmpty(res.getSts())) {
      AppLogger.info(sessVo, "Device block record not found - TT::" + (new Date().getTime() - startTime));
			return FSLStatusConstants.unBlock;
		}
    else {
      AppLogger.info(sessVo,
          String.format("Device block record found [%s] - TT::%s", res.getSts(), (new Date().getTime() - startTime)));
      return res.getSts();
    }
	}
	
}
