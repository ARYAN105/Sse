package com.fsl.fwk.model;

import com.tcs.fwk.model.BaseModel;

public class FSLBranchMstr  extends BaseModel{

	private static final long serialVersionUID = "com.fsl.fwk.model.FSLBranchMstr".hashCode();
	
	private String bankRefNo;
	
	private String bankNm;
	
	private String branchNm;
	
	private String addr;
	
	private String ifscCd;
	
	private String city;
	
	private String state;
	
	private String zipCd;
	
	private String country;

	public String getBankRefNo() {
		return bankRefNo;
	}

	public void setBankRefNo(String bankRefNo) {
		this.bankRefNo = bankRefNo;
	}

	public String getBankNm() {
		return bankNm;
	}

	public void setBankNm(String bankNm) {
		this.bankNm = bankNm;
	}

	public String getBranchNm() {
		return branchNm;
	}

	public void setBranchNm(String branchNm) {
		this.branchNm = branchNm;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getIfscCd() {
		return ifscCd;
	}

	public void setIfscCd(String ifscCd) {
		this.ifscCd = ifscCd;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCd() {
		return zipCd;
	}

	public void setZipCd(String zipCd) {
		this.zipCd = zipCd;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	
	
}
