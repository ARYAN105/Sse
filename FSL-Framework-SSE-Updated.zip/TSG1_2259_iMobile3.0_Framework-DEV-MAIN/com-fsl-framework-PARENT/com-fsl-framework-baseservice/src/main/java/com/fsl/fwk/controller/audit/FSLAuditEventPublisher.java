package com.fsl.fwk.controller.audit;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;

import com.fsl.bank.data.securityauditlog.SecurityAuditLogDReqBody;
import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.constants.FSLStatusConstants;
import com.fsl.fwk.controller.model.FSLAuditData;
import com.fsl.fwk.controller.model.FSLError;
import com.fsl.fwk.controller.model.FSLResponseBody;
import com.tcs.fwk.constants.FwkConstants;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.event.FwkEventConfig;
import com.tcs.fwk.event.MWServiceEventPublisher;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequest;
import com.tcs.fwk.model.MWRequestAddOn;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.service.MWService;
import com.tcs.fwk.service.User;
import com.tcs.fwk.service.model.EventRequestEnvelope;
import com.tcs.fwk.util.DateUtil;
import com.tcs.fwk.util.GenericUtil;
import com.tcs.fwk.util.JSONUtil;

@Configuration
public class FSLAuditEventPublisher implements IFSLAuditEventPublisher{

	private static final String AUDIT_SVC_ID = "SecurityAuditLogD";
	private MWServiceEventPublisher producer;
  
  @Autowired
  private void populateEventPublisher(ApplicationContext context) {
    if (context.containsBean(FwkEventConfig.FwkEventConfigBeanName)) {
      this.producer = context.getBean(MWServiceEventPublisher.class);
    }
  }
  
  private User copyUserObject(ISessionVO sessVO, MWRequestAddOn reqAddOn) {
    User user = null;
    if ((reqAddOn != null) && (reqAddOn.getUser() != null)) {
				user = new User(reqAddOn.getUser().getUserID(),
            				    reqAddOn.getUser().getOrgID(),
            						reqAddOn.getUser().getUserType()
        );
    }
    return user;
  }

  @Override
  public void publishFSLAuditEvent(ISessionVO sessVO, IMWRequest<?> mwRequest, MWResponse<?> mwResponse,
      MWService mwService, long startTime, MWRequestAddOn reqAddOn, boolean isAuditEnable) {
    String serviceId = GenericUtil.isNeitherNullNorEmpty(reqAddOn.getEmbeddedOrchInnerMWServiceID())
        ? reqAddOn.getEmbeddedOrchInnerMWServiceID()
        : mwService.myServiceID();
    
    try {
      /* Populate only required data in audit request body */
      MWRequest<SecurityAuditLogDReqBody> auditReq = new MWRequest<>();
      auditReq.setTrcID(mwRequest.getTrcID());
      
      Map<String, List<String>> headersMap = reqAddOn.getHeadersMap();
      
      MWRequestAddOn auditReqAddOn = new MWRequestAddOn(mwRequest.getTrcID());
      auditReqAddOn.setPathParams(reqAddOn.getPathparams());
      auditReqAddOn.setRestName(reqAddOn.getRestName());
      auditReqAddOn.setInputSchemaValidated(reqAddOn.isInputSchemaValidated());
      auditReqAddOn.setUser(copyUserObject(sessVO, reqAddOn));
      auditReqAddOn.addHeader(FwkConstants.HEADER_SECRET, headersMap.get(FwkConstants.HEADER_SECRET));
      auditReqAddOn.addHeader(FwkConstants.HEADER_TRACE_ID, headersMap.get(FwkConstants.HEADER_TRACE_ID));
      
      List<String> channel = headersMap.get(FwkConstants.HEADER_CHANNEL);
      auditReqAddOn.setChannel(
          (channel != null && !channel.isEmpty()) ? channel.get(0) : FSLConstants.HEADERVAL_CHANNEL_DEFAULT);
      auditReqAddOn
          .setChannelVersion((reqAddOn.getChannelVersion() != null) ? reqAddOn.getChannelVersion() : "");
      
      SecurityAuditLogDReqBody auditReqbody = new SecurityAuditLogDReqBody();
      auditReqbody.setUid(reqAddOn.getUser().getUserID());
      auditReqbody.setDid(reqAddOn.getUser().getDeviceID());
      List<String> appVerList = headersMap.get(FSLConstants.HEADER_VERSION);
      if (appVerList != null && !appVerList.isEmpty()) {
        auditReqbody.setAppVer(appVerList.get(0));
      }
      
      String remoteIp = null;
      
      List<String> rmtIpList        = headersMap.get(FSLConstants.HEADER_RMTIP);
      List<String> bcRmtAddressList = headersMap.get("bc_ipaddress");
      if (rmtIpList != null && !rmtIpList.isEmpty()) {
        remoteIp = rmtIpList.get(0);
      }
      else if (bcRmtAddressList != null && !bcRmtAddressList.isEmpty()) {
        remoteIp = bcRmtAddressList.get(0);
      }
      
      auditReqbody.setRmtIp(remoteIp);
      
      List<String> userAgentList = headersMap.get("bc_useragent");
      
      String deviceModel = null;
      
      if (userAgentList != null && !userAgentList.isEmpty()) {
        String userAgent = userAgentList.get(0);
        
        auditReqbody.setUsrAgnt(userAgent);
        
        String[] userAgentSplit = userAgent.split(";");
        
        if (userAgentSplit.length == 2) {
          deviceModel = userAgentSplit[1];
        }
        
      }
      
      auditReqbody.setDvcMdl(deviceModel);
      
      String errCd = Integer.toString(mwResponse.getStatusCd());
      
      Map<String, Object> meta = mwResponse.getMeta();
      
      if (meta != null && !meta.isEmpty()) {
        
        List<Map<String, String>> metaErrors = (List<Map<String, String>>) meta.get(FSLStatusConstants.ERRORS_MSG_KEY);
        
        errCd = metaErrors.stream().map(x->x.get("errCd")).collect(Collectors.joining(","));
      }
      
      auditReqbody.setErrCd(errCd);
      
      try {
        InetAddress nodeIpDetails = InetAddress.getLocalHost();
        auditReqbody.setHstIp(nodeIpDetails.getHostAddress());
        auditReqbody.setHstNm(nodeIpDetails.getHostName());
      }
      catch (UnknownHostException e) {
        AppLogger.error(sessVO, "Unable to get host details: " + e.getMessage(), null);
        auditReqbody.setHstIp("UNKNOWN");
        auditReqbody.setHstNm("UNKNOWN");
      }
      
      auditReqbody.setInvkrSvc(serviceId);
      auditReqbody.setStatusCd(mwResponse.getStatusCd());
      auditReqbody.setTrnsStrtDt(DateUtil.dateToStr(new Date(startTime))); // Instant when request enters MWRestController
      auditReqbody.setTrnsEndDt(DateUtil.dateToStr(new Date())); // Instant when event is being published	
      auditReqbody.setFail(mwResponse.getStatusCd() < 100);
      
      if (mwResponse.getBody() != null) {
        FSLResponseBody resBody = (FSLResponseBody) mwResponse.getBody();
        FSLAuditData    data    = resBody.getAuditData();
        
        if (data != null) {
          auditReqbody.setAcc(data.getAccountNo());
          auditReqbody.setAmnt(data.getAmount());
          auditReqbody.setTrnsRef(data.getTransactionRefId());
          auditReqbody.setStan(data.getStan());
          auditReqbody.setFail(data.isFailure());
          
          if (mwResponse.getStatusCd() > 100)
            auditReqbody.setFail(data.isFailure());
        }
      }
      if (auditReqbody.isFail()) {
        auditReqbody.setReqJson((MWRequest<?>) mwRequest);
        auditReqbody.setResJson(mwResponse);
      }
      
      auditReq.setBody(auditReqbody);
      AppLogger.debug(sessVO, "Publishing audit event for service " + serviceId + " : "
          + JSONUtil.staticMaskedSerializeJSONObj(sessVO, auditReq));
      
      if (isAuditEnable && (producer != null)) {
        FwkResponseStatus eventStatus = producer.sendMessage(sessVO, AUDIT_SVC_ID, null,
            new EventRequestEnvelope((MWRequest<?>) auditReq, (MWRequestAddOn) auditReqAddOn), null);
        
        AppLogger.debug(sessVO,
            "Audit event published for service " + serviceId + " with stsCd: " + eventStatus.getCode());
      }
    }
    catch (Exception e) {
      AppLogger.error(sessVO, "Exception Occurred while Publishing Audit LOG event for service " + serviceId
          + " :::::: " + e.getMessage(), null);
    }
  }
}
