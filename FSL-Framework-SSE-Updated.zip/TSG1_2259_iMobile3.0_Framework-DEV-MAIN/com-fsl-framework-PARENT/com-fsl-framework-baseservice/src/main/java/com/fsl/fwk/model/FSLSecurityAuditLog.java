package com.fsl.fwk.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tcs.fwk.model.BaseRequestBody;
import com.tcs.fwk.model.MWRequest;
import com.tcs.fwk.model.MWResponse;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FSLSecurityAuditLog extends BaseRequestBody {
	private static final long serialVersionUID = FSLSecurityAuditLog.class.hashCode();
	
	@JsonProperty("invkrSvc")
	private String invkrSvc;
	
	@JsonProperty("trnsEdDt")
	private String trnsEndDt;
	
	@JsonProperty("trnsStDt")
	private String trnsStrtDt;
	
	@JsonProperty("stsCd")
	private Integer statusCd;
	
	@JsonProperty("req")
	private MWRequest<?> reqJson;
	
	@JsonProperty("res")
	private MWResponse<?> resJson;
	
	@JsonProperty("amnt")
	private String amnt;
	
	@JsonProperty("acc")
	private String acc;
	
	@JsonProperty("trnsRef")
	private String trnsRef;
	
	@JsonProperty("isFail")
	private boolean isFail;
	
	@JsonProperty("stan")
	private String stan;
	
	@JsonProperty("uid")
	private String uid;
	
	@JsonProperty("did")
	private String did;
	
	@JsonProperty("appVer")
	private String appVer;
	
	@JsonProperty("rmtIp")
	private String rmtIp;
	
}
