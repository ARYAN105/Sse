package com.fsl.fwk.controller.model;

import com.tcs.fwk.model.BaseRequestBody;

/**
 * @author Tata Consultancy Services
 */
public class FSLRequestBody extends BaseRequestBody {

	private static final long serialVersionUID = "com.fsl.fwk.controller.model.FSLRequestBody".hashCode();
}
