package com.fsl.fwk.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.RequestResponseModel;
import com.tcs.fwk.service.User;

import jakarta.servlet.http.HttpServletRequest;

/**
 * @author Tata Consultancy Services
 */
public abstract class FSLRestController extends FSLBaseRestController {


	@Autowired FSLControllerHelper fslControllerHelper;
	
	@Override
	public RequestResponseModel checkSecurity(HttpServletRequest httpRequest, IMWRequest<?> mwRequest,ISessionVO sessionVO)
			throws BusinessException {
		RequestResponseModel baseRes = super.checkSecurity(httpRequest, mwRequest, sessionVO);
		return fslControllerHelper.checkSecurity(httpRequest, mwRequest, apiGatewaySecretConfigured, sessionVO, (User) baseRes.getUser());
	}
}