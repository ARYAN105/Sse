package com.fsl.fwk.cache.model;

import java.io.Serializable;

import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.TagIndexed;
import com.tcs.fwk.data.model.BaseEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
//@Table(name = "IMB_USER_DEVICES_NC")
@Document("usrsdvnc")
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@Data
@Builder
public class IMBUserDeviceNCVO implements BaseEntity, Serializable {
	private static final long serialVersionUID = "com.fsl.fwk.cache.model.IMBUserDeviceNCVO".hashCode();

	@Id
	@org.springframework.data.annotation.Id
	@TagIndexed
	private String wDID;//USERD_WLDEVICEID
	@TagIndexed
	private String mob;//USERD_MOBNO
	private String uID;//USERD_USER_ID
	private Integer pref;//USERD_PREF
	@TagIndexed
	private String mpin;//USERD_MPIN
	@TagIndexed
	private String imei;//USERD_IMEI
	private String nTkn;//USERD_NOTIFTOKEN
	private String uAvr;//USERD_APPVER
	private String aFlg;//USERD_ACTIVEFLAG
	private String gca;//USERD_GCAVALIDATION
	private String uOs;//USERD_OSTYPE
  @TagIndexed
  private String mpin2;//USERD_MPIN2
  private String uBr;//USERD_BLOCKED_REASON
}