package com.fsl.fwk.constants;

public interface FSLStatusConstants {
	static final String blocked = "2";
	static final String unBlock = "1";
	
	static final String GCARequired = "1";

	static final String gcaDoneStatus = "1";
	static final String eauthDoneStatus = "Y";
	
	static final String gcaActStatus = "5";
	
	static final String ERRORS_MSG_KEY = "errors";
	
  static final String TERMINATE_CON_SESSION = "Y";

	public enum ValidationStatus{
		DID_MANDATE("FSL-00001", "Device ID is Mandatory"),
		DID_BLKD("FSL-00002", "Device is blocked"),
		INVLD_USR("FSL-00003", "Invalid user device details"),
		DID_MISMATCH("FSL-00004", "Device ID Mismatch"),
		GCA_VAL_FLD("FSL-00005", "GCA validation failed/Activation not done"),
		EMAIL_AUTH_NOT_DONE("FSL-00006", "Email authentication not done"),
		UID_MISMATCH("FSL-00007", "User ID is Mismatch"),
		UID_MANDATE("FSL-00008", "User ID is Mandatory"),
		INVLD_REQDTM("FSL-00009","Invalid request date time"),
		CORP_OAUTH_FAILURE("FSL-00010","Unable to process the request, Please try again later"),
		GCA_ACT_MSG("FSL-00011","GCA validation not done"),
		DUPLICATE_REQUEST("FSL-00012", "Duplicate Request"),
		MANDATORY_HEADER_NOT_FOUND("FSL-00013","Required header feild Missing"),
		HASH_INVALID("FSL-00014","Hash is Mismatched"),
	  INVALID_APPVERSION("FSL-00015", "UnRecognized App Version"),
	  HASH_HEADER_NOTFOUND("FSL-00016","Hash Header is Mandatory"),
	  TERMINATED_BY_CONCURRENT_SESSION("FSL-00017","You are now logged out of iMobile and can continue on other channel.");

		private String errCd;
		private String errDesc;
		private String errString;
		
		private ValidationStatus(String errCd, String errDesc) {
			this.errCd = errCd;
			this.errDesc = errDesc;
			this.errString = String.join(FSLConstants.ERRCD_DLMTR, FSLConstants.SYSTEM_NAME.MS.toString(), errCd, errDesc);
		}

		public String getErrCd() {
			return errCd;
		}

		public String getErrString() {
			return errString;
		}

		public String getErrDesc() {
			return errDesc;
		}
	}
}
