package com.fsl.fwk.controller.errorupdate;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.fsl.fwk.cache.model.IMBErrormsgVO;
import com.fsl.fwk.cache.model.IMBErrormsgVO_;
import com.fsl.fwk.constants.FSLConstants;
import com.tcs.fwk.cache.master.client.MasterDataCacheClient;
import com.tcs.fwk.cache.rtwb.client.ReadThruCacheClient;
import com.tcs.fwk.constants.FwkConstants;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.db.filter.AbstractFilter;
import com.tcs.fwk.db.filter.And;
import com.tcs.fwk.db.filter.Simple;
import com.tcs.fwk.event.FwkEventConfig;
import com.tcs.fwk.event.MWServiceEventPublisher;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequest;
import com.tcs.fwk.model.MWRequestAddOn;
import com.tcs.fwk.service.User;
import com.tcs.fwk.service.model.EventRequestEnvelope;
import com.tcs.fwk.util.GenericUtil;

@Configuration
public class FSLErrorUpdateEventPublisher implements IFSLErrorUpdateEventPublisher {

	@Autowired
	Environment env;

	@Autowired
	MasterDataCacheClient dataCacheClient;

	@Autowired
	private ReadThruCacheClient readclient;

	private static final String ERROR_SVC_ID = "ErrorTableUpdateD";
	private static final String ERROR_REST_NAME = "error-table-update";
	private MWServiceEventPublisher producer;

	@Autowired
	private void populateEventPublisher(ApplicationContext context) {
		if (context.containsBean(FwkEventConfig.FwkEventConfigBeanName)) {
			this.producer = context.getBean(MWServiceEventPublisher.class);
		}
	}

	private User copyUserObject(ISessionVO sessVO) {
		User user = null;
		if (sessVO != null) {
			user = new User(sessVO.getUserID(), null, null);
		}
		return user;
	}

	@Override
	public boolean publishFSLErrorEvent(ISessionVO sessVO, ErrorUpdateVO errorUpdateVO) {
		try {
			if (isErrorEventEnable(sessVO, env, null)) {
				if (isNewErrorCode(sessVO, errorUpdateVO)) {
					ErrorUpdateDReqBody errorReqbody = new ErrorUpdateDReqBody();
					MWRequest<ErrorUpdateDReqBody> errorReq = new MWRequest<>();
					MWRequestAddOn errorReqAddOn = new MWRequestAddOn(sessVO.getTrcID());
					String secret = env.getProperty("FWK.SERVICE.APIGateway.secret", "");

					errorReqAddOn.setRestName(ERROR_REST_NAME);
					errorReqAddOn.setInputSchemaValidated(true);
					errorReqAddOn.setUser(copyUserObject(sessVO));
					errorReqAddOn.addHeader(FwkConstants.HEADER_SECRET, Arrays.asList(secret));
					errorReqAddOn.addHeader(FwkConstants.HEADER_TRACE_ID, Arrays.asList(sessVO.getTrcID()));

					if (errorUpdateVO != null) {
						errorReqbody.setErrorCode(errorUpdateVO.getErrorCode());
						errorReqbody.setErrorDesc(errorUpdateVO.getErrorDesc());
						errorReqbody.setServiceId(errorUpdateVO.getServiceId());
						errorReqbody.setSystemName(errorUpdateVO.getSystemName());
					}

					errorReq.setBody(errorReqbody);
					errorReq.setTrcID(sessVO.getTrcID());

					FwkResponseStatus eventStatus = producer.sendMessage(sessVO, ERROR_SVC_ID, null,
							new EventRequestEnvelope((MWRequest<?>) errorReq, (MWRequestAddOn) errorReqAddOn), null);

					return FwkResponseStatus.ASYNC_REQUEST_SENT.equals(eventStatus);
				} else {
					AppLogger.debug(sessVO, "Error Code Already present");
				}
			}

		} catch (Exception e) {
			AppLogger.error(sessVO, "Exception Occurred while publishing error update event for service " + " :::::: " + e.getMessage(),null);
		}

		return false;
	}

	private boolean isNewErrorCode(ISessionVO sessVO, ErrorUpdateVO errorUpdateVO) {
		boolean isNewErrorCode = false;
		List<IMBErrormsgVO> data = null;
		AbstractFilter errfilter = null;
		if (GenericUtil.isNeitherNullNorEmpty(errorUpdateVO.getErrorCode())) {
			AbstractFilter errcodeFilter = Simple.of(IMBErrormsgVO.class).eq(IMBErrormsgVO_.M_CD,
					errorUpdateVO.getErrorCode());
			AbstractFilter sysnamefilter = Simple.of(IMBErrormsgVO.class).eq(IMBErrormsgVO_.S_NM,
					errorUpdateVO.getSystemName());
			AbstractFilter servidFilter = Simple.of(IMBErrormsgVO.class).eq(IMBErrormsgVO_.S_ID,
					errorUpdateVO.getServiceId());

			if (FSLConstants.SYSTEM_NAME.FSL.toString().equals(errorUpdateVO.getSystemName()))
				errfilter = And.of(sysnamefilter, errcodeFilter, servidFilter);
			else
				errfilter = And.of(sysnamefilter, errcodeFilter);

			data = readclient.findAllByFilter(sessVO, IMBErrormsgVO.class, errfilter, null);

			if (data != null && !data.isEmpty() && data.get(0).getMtxt() != null) {
				if (!data.get(0).getMtxt().equalsIgnoreCase(errorUpdateVO.getErrorDesc()))
					isNewErrorCode = true;
				else
					isNewErrorCode = false;
			} else
				isNewErrorCode = true;
		}
		return isNewErrorCode;
	}

}
