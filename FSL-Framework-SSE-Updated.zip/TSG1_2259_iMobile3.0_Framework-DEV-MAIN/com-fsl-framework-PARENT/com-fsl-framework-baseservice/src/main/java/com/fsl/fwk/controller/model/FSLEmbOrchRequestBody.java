//package com.fsl.fwk.controller.model;
//
//import com.fasterxml.jackson.databind.JsonNode;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
///**
// * @author Tata Consultancy Services
// */
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class FSLEmbOrchRequestBody extends FSLRequestBody {
//
//	private static final long serialVersionUID = "com.fsl.fwk.controller.model.FSLEmbOrchRequestBody".hashCode();
//
//	private JsonNode serviceData;
//}
