package com.fsl.fwk.cache.model;

import com.redis.om.spring.annotations.Document;
import com.redis.om.spring.annotations.TagIndexed;
import com.tcs.fwk.data.model.BaseEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@Builder
@Document("admCfg")
@AllArgsConstructor
@RequiredArgsConstructor(staticName = "of")
@Entity // Added to generate metamodel
public class IMBADMConfigVO implements BaseEntity {
  @Id
  @org.springframework.data.annotation.Id
  @TagIndexed
  private String cfk;
  private String cfv;
  
}
