package com.fsl.fwk.utils;

public enum EncDecMode {
  RSA,
  AES
}