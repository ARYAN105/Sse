package com.fsl.fwk.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.constants.FSLConstants.SYSTEM_NAME;
import com.fsl.fwk.constants.FSLResponseStatus;
import com.fsl.fwk.constants.FSLStatusConstants;
import com.fsl.fwk.constants.FSLStatusConstants.ValidationStatus;
import com.fsl.fwk.controller.model.FSLResponseBody;
import com.fsl.fwk.controller.model.FSLUserProfile;
import com.fsl.fwk.utils.EncDecHelper;
import com.fsl.fwk.utils.FSLHelper;
import com.fsl.fwk.utils.FSLReadDataHelper;
import com.fsl.fwk.utils.HashUtil;
import com.tcs.fwk.constants.FwkConstants;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequestAddOn;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.model.RequestResponseModel;
import com.tcs.fwk.service.MWService;
import com.tcs.fwk.service.User;
import com.tcs.fwk.util.DateUtil;
import com.tcs.fwk.util.GenericUtil;
import com.tcs.fwk.util.JSONUtil;

import jakarta.servlet.http.HttpServletRequest;

@Component
public class FSLControllerHelper {

	@Autowired
	FSLHelper fslHelper;

	@Autowired
	Environment env;

	@Autowired
	FSLReadDataHelper readDataHelper;
	
	@Autowired
	HashUtil hashutil;
	
	String osType=null;

	@Value("${FWK.LOGGER.DEFAULT.clientPayload.print:1}")
	private boolean isLogClientPayload;

  @Value("${FWK.LOGGER.DEFAULT.clientPayload.headers.print:0}")
  private boolean isLogClientHeader;

  @Value("${FWK.LOGGER.DEFAULT.clientPayload.headers.excludes:}")
  private List<String> excludeLogHeaders = null;
  
	public RequestResponseModel checkSecurity(HttpServletRequest httpRequest, IMWRequest<?> mwRequest,
			String apiGatewaySecretConfigured, ISessionVO sessionVO, User user) throws BusinessException {
    /**
      following httpRequest headers must be passed only when the request is
      received from the APIGateway. FOr inter-ABCservice communication these
      headers will NOT be present. For interService communication this info will
      already be in the MWRequest.head.user.
      //TBD-Deepa : how to check whether the request is actually passed from ApiGateway or not
      to check this have the APIGateway to pass a SecretKey (which can either be
      dynamically changed & Stored in distributed cache OR hardcoded in properties)
     **/
		Map<String, Object> meta = null;
		List<String> msgCds = null;
		
		String uId = httpRequest.getHeader(FwkConstants.HEADER_USERID);
		String idType = httpRequest.getHeader(FwkConstants.HEADER_USERID_TYPE); 
		if (!GenericUtil.isNullOrEmpty(idType) 
			&& (idType.equalsIgnoreCase(FSLConstants.USERID_TYPE.DID.toString())
			|| idType.equalsIgnoreCase(FSLConstants.USERID_TYPE.MNL.toString()))) {
			uId = httpRequest.getHeader(FwkConstants.HEADER_DEVICEID);
		}
		
		String deviceID = httpRequest.getHeader(FwkConstants.HEADER_DEVICEID);
		String channel = httpRequest.getHeader(FwkConstants.HEADER_CHANNEL);
		String userType = httpRequest.getHeader(FwkConstants.HEADER_USER_TYPE);
		channel = channel == null ? FSLConstants.HEADERVAL_CHANNEL_DEFAULT : "";
		
		String gcaRequired = FSLStatusConstants.GCARequired;
		if (GenericUtil.isNeitherNullNorEmpty(httpRequest.getHeader(FSLConstants.GCAREQUIRED))) {
			gcaRequired = httpRequest.getHeader(FSLConstants.GCAREQUIRED);
		}
		
		if (GenericUtil.isNullOrEmpty(uId)) {
      msgCds = Arrays.asList(ValidationStatus.UID_MANDATE.getErrString());
      meta = fslHelper.updateResMeta(sessionVO, msgCds);
			AppLogger.error(sessionVO, "Request User Id is Empty", null);
			throw new BusinessException(FSLResponseStatus.BUSINESS_SECURITY_VALIDATION_ERRORS, msgCds, meta);
		}

		FSLUserProfile fslUserProfile = (FSLUserProfile) user.getAddtionalAttribs().get(FSLConstants.FSL_USER_PROFILE);
		
		if (GenericUtil.isNullOrEmpty(fslUserProfile)) {
      msgCds = Arrays.asList(ValidationStatus.INVLD_USR.getErrString());
      meta = fslHelper.updateResMeta(sessionVO, msgCds);
			AppLogger.error(sessionVO, "Request Id: " + uId + ", Device ID: " + deviceID + ", User Profile not found", null);
			throw new BusinessException(FSLResponseStatus.BUSINESS_SECURITY_VALIDATION_ERRORS, msgCds, meta);
		}
		if (FSLStatusConstants.blocked.equals(fslUserProfile.getDeviceBlockStatus())) {
			msgCds = Arrays.asList(ValidationStatus.DID_BLKD.getErrString());
			meta = fslHelper.updateResMeta(sessionVO, msgCds);
			AppLogger.error(sessionVO, "Request Device Id: " + deviceID + ", is blocked", null);
			throw new BusinessException(FSLResponseStatus.BUSINESS_SECURITY_VALIDATION_ERRORS, msgCds, meta);
		}
		
	if(FSLStatusConstants.TERMINATE_CON_SESSION.equals(fslUserProfile.getTerminateByConSession())) {
	  msgCds =Arrays.asList(ValidationStatus.TERMINATED_BY_CONCURRENT_SESSION.getErrString());
	  meta = fslHelper.updateResMeta(sessionVO, msgCds);
	  AppLogger.error(sessionVO, "Logged Out Due to Concurrent Session", null);
    throw new BusinessException(FSLResponseStatus.BUSINESS_SECURITY_VALIDATION_ERRORS, msgCds, meta);
	}
		
		String gcaStatus = GenericUtil.isNullOrEmpty(fslUserProfile.getUserdGCAValidation()) ? ""
				: fslUserProfile.getUserdGCAValidation();
		String accType = GenericUtil.isNullOrEmpty(fslUserProfile.getUserAccType()) ? ""
				: fslUserProfile.getUserAccType();
		String emailAuth = GenericUtil.isNullOrEmpty(fslUserProfile.getUserEmailAuth()) ? ""
				: fslUserProfile.getUserEmailAuth();
		String userTypeDB = GenericUtil.isNullOrEmpty(fslUserProfile.getUserType()) ? ""
				: fslUserProfile.getUserType();
		String userdProfiling = GenericUtil.isNullOrEmpty(fslUserProfile.getUserdprofiling()) ? ""
				: fslUserProfile.getUserdprofiling();
		
		AppLogger.debug(sessionVO, "idType="+idType+"| userType="+userType+"| userTypeDB="+userTypeDB+"| "
				+ "userdProfiling="+userdProfiling+"| gcaStatus="+gcaStatus);
		
		if (!validateIdentity(fslUserProfile, idType, uId, sessionVO)) {
      msgCds = Arrays.asList(ValidationStatus.UID_MISMATCH.getErrString());
      meta = fslHelper.updateResMeta(sessionVO, msgCds);
			AppLogger.error(sessionVO, "Identity validation failed", null);
			throw new BusinessException(FSLResponseStatus.BUSINESS_SECURITY_VALIDATION_ERRORS, msgCds, meta);
		}
		else if (((FSLConstants.USERID_TYPE.UID.toString().equalsIgnoreCase(idType) 
				&& (!FSLConstants.USER_TYPE.NTB.toString().equalsIgnoreCase(userType)))  
				|| FSLConstants.USERID_TYPE.DID.toString().equalsIgnoreCase(idType))
				 && (! (FSLConstants.DB_USER_TYPE.STDLA.toString().equalsIgnoreCase(userdProfiling))) //IFA-6355-GCA to be skipped for LAA Profile
			 && (!FSLStatusConstants.gcaDoneStatus.equalsIgnoreCase(gcaStatus))
				&& (FSLStatusConstants.GCARequired.equalsIgnoreCase(gcaRequired))) {
			
	
	  String errorString = FSLStatusConstants.gcaActStatus.equalsIgnoreCase(gcaStatus)?ValidationStatus.GCA_ACT_MSG.getErrString():ValidationStatus.GCA_VAL_FLD.getErrString();
      msgCds = Arrays.asList(errorString);
      meta = fslHelper.updateResMeta(sessionVO, msgCds);
			AppLogger.error(sessionVO, 
					"Request User :" + uId + " GCA validation failed/Activation not done, Current Status: " + gcaStatus, 
					null);
			//throw new BusinessException(FSLResponseStatus.BUSINESS_SECURITY_VALIDATION_ERRORS, msgCds, meta);
			throw new BusinessException(FwkResponseStatus.SECURITY_VALIDATION_ERRORS, msgCds, meta);
			/**
			 * throw SECURITY_VALIDATION_ERRORS instead BUSINESS_SECURITY_VALIDATION_ERRORS for redirect user to login screen
			 * This will be stopgap arrangement until actionCd implementation get complete 
			 **/
		}
		else if ((FSLConstants.USERID_TYPE.MOB.toString().equalsIgnoreCase(idType)
		    || FSLConstants.USER_TYPE.NTB.toString().equalsIgnoreCase(userType)
				|| FSLConstants.USERID_TYPE.MNL.toString().equalsIgnoreCase(idType))
				&& FSLConstants.ACC_TYPE.PAYPK.toString().equalsIgnoreCase(accType)
				&& (!FSLStatusConstants.eauthDoneStatus.equalsIgnoreCase(emailAuth))) {
      msgCds = Arrays.asList(ValidationStatus.EMAIL_AUTH_NOT_DONE.getErrString());
      meta = fslHelper.updateResMeta(sessionVO, msgCds);
			AppLogger.error(sessionVO,
					"Request User :" + uId + " Email authentication not done, Current Status: " + emailAuth, 
					null);
			throw new BusinessException(FSLResponseStatus.BUSINESS_SECURITY_VALIDATION_ERRORS, msgCds, meta);
		}

		return (new RequestResponseModel(user, channel));
	}

	protected MWResponse<?> afterServiceInvocation(ISessionVO sessVO, IMWRequest<?> mwRequest,
			MWResponse<?> mwResponse, MWService mwService, long startTime, MWRequestAddOn reqAddOn) {
		Map<String, Object> meta = new HashMap<>();
		@SuppressWarnings("unchecked")
		MWResponse<FSLResponseBody> mwReqResponse = (MWResponse<FSLResponseBody>) mwResponse;
		
    String svcID = null;
    if (GenericUtil.isNeitherNullNorEmpty(reqAddOn.getEmbeddedOrchInnerMWServiceID())) {
      svcID = reqAddOn.getEmbeddedOrchInnerMWServiceID();
    }
    else {
      svcID = mwService.myServiceID();
    }
    
		if (GenericUtil.isNeitherNullNorEmpty(mwResponse.getMsgCds()) && (!mwResponse.getMsgCds().isEmpty())) {
		  List<String> msgCdStringList = mwResponse.getMsgCds();
      fslHelper.updateResMeta(sessVO, msgCdStringList, meta);
			mwReqResponse.setMsgCds(null);
		} 
    else if (mwReqResponse.getStatusCd() != FwkResponseStatus.INPUT_VALIDATION_CUSTOM_FAILED.getCode()
        && mwReqResponse.getStatusCd() < FwkResponseStatus.SUCCESS.getCode()
        && GenericUtil.isNeitherNullNorEmpty(svcID)) {
      List<String> msgCdStringList = Arrays.asList(String.join(FSLConstants.ERRCD_DLMTR,
          SYSTEM_NAME.FSL.toString(), String.valueOf(mwReqResponse.getStatusCd()), svcID));
      fslHelper.updateResMeta(sessVO, msgCdStringList, meta);
      mwReqResponse.setMsgCds(null);
    }

		// filter based on pagination input if present in meta of request
		Map<String, Object> reqMeta = mwRequest.getMeta();
		if (reqMeta != null && !reqMeta.isEmpty()) {
			Object pgntnReqData = reqMeta.get("pgntnReqData");
			if (pgntnReqData != null) {
				updatePaginationData(meta, mwReqResponse, pgntnReqData);
			}
		}

		if (!meta.isEmpty()) {
			mwReqResponse.setMeta(meta);
		}
		
		if (isLogClientPayload || mwReqResponse.getStatusCd()!=FwkResponseStatus.SUCCESS.getCode())
		  logClientResPayload(sessVO, mwResponse, reqAddOn.getHeadersMap());

		return mwReqResponse;
	}
	
  private Integer strToInteger(Object strVal) {
    return (strVal != null) && NumberUtils.isParsable(strVal.toString()) ? Integer.parseInt(strVal.toString()) : null;
  }
  
  private void updatePaginationData(Map<String, Object> meta, MWResponse<FSLResponseBody> mwReqResponse,
      Object pgntnReqData) {
    @SuppressWarnings("unchecked")
    Map<String, Object> pgDataMap = (Map<String, Object>) pgntnReqData;
    Integer             pgNo      = strToInteger(pgDataMap.get("pgNo"));
    Integer             numRecs   = strToInteger(pgDataMap.get("numRecs"));
    
    if (pgNo != null && pgNo > 0 && numRecs != null && numRecs > 0) {
      
      // apply pagination on below data
      List<?> pagedData = mwReqResponse.getBody().getPagedData();
      
      // eg 1: 550 recs present -> fetch 30 recs from 7 pgNo -> start - 180(index 0 of
      // list)(x = numRecs*(pgNo-1)) and end - 209(y = x + numRecs - 1) ->
      // eg 2: 29 recs present -> fetch 5 recs from 6 pgNo -> start - (x =
      // numRecs*(pgNo-1) = 25) and end - (y = x + numRecs - 1 = 29) -> end is grtr
      // than list size -> end = list size
      int     start              = numRecs * (pgNo - 1); // - 1 since list starts from index 0
      String  hasMoreRecords     = "0";
      int     numRecordsReturned = 0;
      List<?> resPagedData       = null;
      
      if ((pagedData != null) && (start < pagedData.size())) { // start will always be >=0 as pgNo is >0 and numRecs is >0
        int end = start + numRecs - 1; // - 1 since list starts from index 0
        // end will always be >=0 as start is >=0 and numRecs is >0
        
        if (end >= pagedData.size()) {
          end            = pagedData.size() - 1;
          hasMoreRecords = "0";
        }
        else if (end == pagedData.size() - 1) {
          hasMoreRecords = "0";
        }
        else
          hasMoreRecords = "1";
        
        resPagedData = pagedData.subList(start, end + 1); // + 1 since start is inclusive and end is
        // exclusive
        numRecordsReturned = resPagedData.size();
      }
      
      mwReqResponse.getBody().setPagedData(resPagedData);
      Map<String, Object> pgntnResData = new HashMap<>();
      pgntnResData.put("numRecsReturned", numRecordsReturned);
      pgntnResData.put("hasMoreRecs", hasMoreRecords);
      pgntnResData.put("totalRecs", pagedData == null ? 0 : pagedData.size());
      pgntnResData.put("totalPgs", pagedData == null ? 0 : Math.ceilDiv(pagedData.size(), numRecs));
      meta.put("pgntnResData", pgntnResData);
    }
    else {
      throw new SystemException(FwkResponseStatus.CODING_CONFIG_ERROR, "Invalid pagination request data");
    }
  }
	
	private boolean validateIdentity(FSLUserProfile fslUserProfile, String IDType, String ID, ISessionVO sessionVO) {
		boolean validUser = false;

		if ((!GenericUtil.isNullOrEmpty(ID)) && (!GenericUtil.isNullOrEmpty(IDType))
				&& (!GenericUtil.isNullOrEmpty(fslUserProfile))) {
			FSLConstants.USERID_TYPE idType = FSLConstants.USERID_TYPE.valueOf(IDType);
			
			switch (idType) {
			case UID:
				validUser = ID.equalsIgnoreCase(fslUserProfile.getUserBayID());
				if (!validUser) AppLogger.error(sessionVO,
						"Request Bay Id :" + ID + " not matched with user Bay ID " + fslUserProfile.getUserBayID(), null);
				break;
			case MOB:
				validUser = ID.equalsIgnoreCase("+" + fslUserProfile.getUserMOBNo());
				if (!validUser) AppLogger.error(sessionVO,
						"Request Mobile no :" + ID + " not matched with user Mobile no +" + fslUserProfile.getUserMOBNo(), null);
				break;
			case LNM:
				// for LNM user user id is store as mob no with or without country code
				String userMobNo = fslUserProfile.getUserID(); 
				userMobNo = GenericUtil.isNeitherNullNorEmpty(userMobNo) ? userMobNo.trim() : "";
				userMobNo = (userMobNo.length() == 10) ? ("+91" + userMobNo) : ("+" + userMobNo);
				validUser = ID.trim().equalsIgnoreCase(userMobNo);
				if (!validUser) AppLogger.error(sessionVO,
						"Request Alias Id :" + ID + " not matched with user Alias ID " + userMobNo, null);
				break;
			case DID, MNL:
			default:
				String imei = ID.replaceAll("-", "");
				validUser = ID.equalsIgnoreCase(fslUserProfile.getUserdWldeviceID()) || imei.equalsIgnoreCase(fslUserProfile.getUserdIMEI());
				if (!validUser) AppLogger.error(sessionVO,
						"Request Device id/imei :" + ID + " not matched with user Device/imei " + fslUserProfile.getUserdWldeviceID(),
						null);
				break;
			}
		}
		else {
			AppLogger.error(sessionVO, "Invalid input for validate user", null);
		}

		return validUser;
	}
	
	private static Map<String, String> xssValErr = Map.of("Reason", "XSS Failure");
	private static Map<String, String> schemaValErr = Map.of("Reason", "Schema validation Failure");
	
	protected Map<String, String> customiseSchemaValidationErrors(ISessionVO sessVO,
			Map<String, String> mapValidationErrors, FwkResponseStatus statusCd) {
		AppLogger.debug(sessVO, "Request body validation exception for status: " + statusCd.getCode() + " Errors: " + mapValidationErrors);
		Map<String, String> map = null;
		if (FwkResponseStatus.XSS_VALIDATION_FAILED == statusCd) {
			map = xssValErr;
		} else if (FwkResponseStatus.INPUT_VALIDATION_SCHEMA_FAILED == statusCd) {
			map = schemaValErr;
		}
		//TODO: Confirm if to perform audit here or NOT
		return map;
	}
  
  private Map<String, String> getRequestHeaders(ISessionVO sessVO, HttpServletRequest httpRequest) {
    Map<String, String> headers = null;
    
    if (GenericUtil.isNeitherNullNorEmpty(httpRequest)) {
      Enumeration<String> headerNames = httpRequest.getHeaderNames();
      if (headerNames != null) {
        headers = new HashMap<>();
        while (headerNames.hasMoreElements()) {
          String headerName = headerNames.nextElement();
          if (excludeLogHeaders.contains(headerName))
            headers.put(headerName, "**********");
          else {
            String headerValue = Collections.list(httpRequest.getHeaders(headerName)).get(0);
            headers.put(headerName, headerValue);
          }
        }
      }
    }
    
    return headers;
  }
  
  private void logClientReqPayload(ISessionVO sessVO, IMWRequest<?> mwRequest, HttpServletRequest httpRequest) {
    try {
      Map<String, String> headers = getRequestHeaders(sessVO, httpRequest);
      
      StringBuilder clientReqPayload = new StringBuilder();
      clientReqPayload.append("{ \"reqPayload\":");
      clientReqPayload.append(JSONUtil.staticMaskedSerializeJSONObj(sessVO, mwRequest));
      if (isLogClientHeader && (headers != null)) {
        clientReqPayload.append(", \"reqHeaders\":");
        clientReqPayload.append(JSONUtil.staticMaskedSerializeJSONObj(sessVO, headers));
      }
      clientReqPayload.append("}");
      AppLogger.info(sessVO, clientReqPayload.toString());
    }
    catch (Exception e) {
      AppLogger.error(sessVO, "Exception while logClientPayload ", e);
    }
  }

  private void logClientResPayload(ISessionVO sessVO, MWResponse<?> mwResponse, Map<String, List<String>> resHeaders) {
    try {
      StringBuilder clientResPayload = new StringBuilder();
      Map<String, String> headers = new HashMap<>();
      clientResPayload.append("{ \"resPayload\":");
      clientResPayload.append(JSONUtil.staticMaskedSerializeJSONObj(sessVO, mwResponse));
      if (isLogClientHeader && (resHeaders != null)) {
        resHeaders.forEach((key, values) -> headers.put(key, values.get(0)));
        clientResPayload.append(", \"resHeaders\":");
        clientResPayload.append(JSONUtil.staticMaskedSerializeJSONObj(sessVO, headers));
      }
      clientResPayload.append("}");
      AppLogger.info(sessVO, clientResPayload.toString());
    }
    catch (Exception e) {
      AppLogger.error(sessVO, "Exception while logClientPayload ", e);
    }
  }
  
  public RequestResponseModel baseSecurityCheck(HttpServletRequest httpRequest, IMWRequest<?> mwRequest,
      String apiGatewaySecretConfigured, ISessionVO sessionVO, RequestResponseModel reqResModel, MWService myMWService)
      throws BusinessException {
    logClientReqPayload(sessionVO, mwRequest, httpRequest);
    
    // ApiGateway should extract these IDs from JWTToken & pass in httRequest HEADER
    // ATTRIBUTES as follows or pass as separate JWTToken
    if (GenericUtil.isNullOrEmpty(httpRequest.getHeader(FwkConstants.HEADER_TOKEN))) {
      List<String> msgCds = Arrays.asList("Token is Mandatory");
  		throw new BusinessException(FwkResponseStatus.SECURITY_VALIDATION_ERRORS, msgCds);
  	}
      
    String uId = httpRequest.getHeader(FwkConstants.HEADER_USERID);
  	String idType = httpRequest.getHeader(FwkConstants.HEADER_USERID_TYPE); 
  	if (!GenericUtil.isNullOrEmpty(idType) 
  		&& (idType.equalsIgnoreCase(FSLConstants.USERID_TYPE.DID.toString())
  		|| idType.equalsIgnoreCase(FSLConstants.USERID_TYPE.MNL.toString()))) {
  		uId = httpRequest.getHeader(FwkConstants.HEADER_DEVICEID);
  	}
  	
  	String orgID = httpRequest.getHeader(FwkConstants.HEADER_ORGID);
  	String deviceID = httpRequest.getHeader(FwkConstants.HEADER_DEVICEID);
  	String channel = httpRequest.getHeader(FwkConstants.HEADER_CHANNEL);
  	String userType = httpRequest.getHeader(FwkConstants.HEADER_USER_TYPE);
  	channel = channel == null ? FSLConstants.HEADERVAL_CHANNEL_DEFAULT : "";
    
    if (GenericUtil.isNullOrEmpty(deviceID)) {
      List<String> msgCds = Arrays.asList(ValidationStatus.DID_MANDATE.getErrString());
      Map<String, Object> meta = fslHelper.updateResMeta(sessionVO, msgCds);
  		AppLogger.error(sessionVO, "Request Device Id is Empty", null);
  		throw new BusinessException(FSLResponseStatus.BUSINESS_SECURITY_VALIDATION_ERRORS, msgCds, meta);
  	}
    String blockStatusValue= readDataHelper.getDeviceBlockStatus(sessionVO, deviceID);
  
    User user = new User(uId, orgID, null);
  	idType = idType == null ? FSLConstants.USERID_TYPE.UID.toString() : idType;
  	user.setIdType(idType);
  	user.setDeviceID(deviceID);
  	osType = httpRequest.getHeader(FSLConstants.HEADER_OSTYPE);
  	String imei = httpRequest.getHeader(FSLConstants.HEADER_IMEI);
  	String gcmTkn = httpRequest.getHeader(FSLConstants.HEADER_GCMTKN);
  	
  	String trcID= httpRequest.getHeader(FwkConstants.HEADER_TRACE_ID);
    if (GenericUtil.isNullOrEmpty(trcID)) {
      List<String>        msgCds = Arrays.asList(ValidationStatus.MANDATORY_HEADER_NOT_FOUND.getErrString());
      Map<String, Object> meta   = fslHelper.updateResMeta(sessionVO, msgCds);
      throw new BusinessException(FwkResponseStatus.SECURITY_VALIDATION_ERRORS, msgCds, meta);
    }
    
	osType = httpRequest.getHeader(FSLConstants.HEADER_OSTYPE);
	if (GenericUtil.isNullOrEmpty(osType)) {
		List<String> msgCds = Arrays.asList(ValidationStatus.MANDATORY_HEADER_NOT_FOUND.getErrString());
		Map<String, Object> meta = fslHelper.updateResMeta(sessionVO, msgCds);
		throw new BusinessException(FwkResponseStatus.SECURITY_VALIDATION_ERRORS, msgCds, meta);
	}
       
  	
    String svcID           = myMWService.myServiceID();
    String hash            = httpRequest.getHeader(FSLConstants.HEADER_HASH);
    String isValidated     = httpRequest.getHeader(FSLConstants.IS_VALIDATED);
    String txnID           = httpRequest.getHeader(FSLConstants.TXN_ID);
    String version         = httpRequest.getHeader(FSLConstants.HEADER_VERSION);
    String baseVersion     = FSLConstants.IOS.equalsIgnoreCase(osType)
                           ? env.getProperty("FSL.EAIGATEWAY.HASH.BASE_IOS_VESRION", "30.3")
                           : env.getProperty("FSL.EAIGATEWAY.HASH.BASE_ANDROID_VESRION", "31.1");
    String rawJsonHash     = (String)httpRequest.getAttribute(FSLConstants.FSL_HASH);
    
    AppLogger.info(sessionVO, "rawJsonHash:"+rawJsonHash);
    
     // If ORCH internal call skip checking hash flag and hash calculation
    if (GenericUtil.isNullOrEmpty(isValidated) && GenericUtil.isNullOrEmpty(txnID)) {
        
        String hashFlagEnabled = hashutil.checkHashReplayEnabled(svcID);
        AppLogger.info(sessionVO, String.format("Hash Flag for %s: %s", svcID, hashFlagEnabled));
        
        if (FSLConstants.HASH_ENABLED.equals(hashFlagEnabled)) {
          
          if (hashutil.compareVersions(version, baseVersion) >= 0 && GenericUtil.isNullOrEmpty(hash)) {
            AppLogger.error(sessionVO,
                String.format("Hash Header is Mandatory for app version greater than:%s", baseVersion), null);
            List<String>        msgCds = Arrays.asList(ValidationStatus.HASH_HEADER_NOTFOUND.getErrString());
            Map<String, Object> meta   = fslHelper.updateResMeta(sessionVO, msgCds);
            throw new BusinessException(FSLResponseStatus.FSL_SECURITY_VALIDATION_FAILED, msgCds, meta);
          }
       
          if (!GenericUtil.isNullOrEmpty(hash)
              && Boolean.TRUE.equals(hashutil.isValidAppVersionFormat(version, sessionVO)
                  && Boolean.TRUE.equals(hashutil.isValidAppVersion(version, osType, sessionVO)))) {
            
           validateRequestHash(sessionVO, hash, mwRequest, trcID,rawJsonHash);
            validateReplayAttack(sessionVO, mwRequest);
          }
        }
     }
   
  	FSLUserProfile fslUserProfile = readDataHelper.loadUserProfile(sessionVO, idType, deviceID, imei, osType, gcmTkn, userType);
    if (fslUserProfile != null)
      fslUserProfile.setDeviceBlockStatus(GenericUtil.isNullOrEmpty(blockStatusValue)?  "" :blockStatusValue);

  	Map<String, Object> userAttribs = new HashMap<>();
  	userAttribs.put(FSLConstants.FSL_USER_PROFILE, fslUserProfile);
  	
  	user.setAddtionalAttribs(userAttribs);
  	return (new RequestResponseModel(user, channel));
  }
  
  private void validateReplayAttack(ISessionVO sessionVO, IMWRequest<?> mwRequest)
      throws BusinessException {
	  String reqDtTm = mwRequest.getHead().getRequestDtTm();
	    Date   reqDate = DateUtil.strDateTimeToDate(reqDtTm);
	    
	    Date serverTime = new Date();
	    
	    long requestTime = reqDate.getTime();
	    long currentTime = serverTime.getTime();
	    
	    long pastTolerance   = Long.parseLong(env.getProperty("FSL.EAIGATEWAY.REPLAYATTCK.TIME", "60000"));
	    long futureTolerance = Long.parseLong(env.getProperty("FSL.EAIGATEWAY.OFFSET.TIME.MILLISECONDS", "1000"));
	    long timeDiff        = currentTime - requestTime;
	    AppLogger.info(sessionVO, String.format("ReqDtTm:%s | ServerTime:%s | TimeDiff:%d | PastTolerance:%d | FutureTolerance:%d",reqDtTm, serverTime, timeDiff, pastTolerance, futureTolerance));
	    boolean isOlderThanAllowed    = timeDiff > pastTolerance;
	    boolean isFutureBeyondAllowed = timeDiff < -futureTolerance;
	    
	    if (isOlderThanAllowed || isFutureBeyondAllowed) {
	      List<String>        msgCds = Arrays.asList(ValidationStatus.INVLD_REQDTM.getErrString());
	      Map<String, Object> meta   = fslHelper.updateResMeta(sessionVO, msgCds);
	      AppLogger.error(sessionVO, "Invalid request date time: " + reqDtTm, null);
	      throw new BusinessException(FSLResponseStatus.FSL_SECURITY_VALIDATION_FAILED, msgCds, meta);
	    }
	    AppLogger.debug(sessionVO, "Replay Attack Successfully validated");
  }
  
  public void validateRequestHash(ISessionVO sessionVO,String hash,
      IMWRequest<?> mwRequest,String trcID, String rawJsonHash)
      throws BusinessException {
      String hashMessage = serializeJson(sessionVO, mwRequest)+ "|"+trcID;

      String secretKey      = env.getProperty("FSL.EAIGATEWAY.HASH.SALT");
      String calculatedHash = "";
      
      try {
        String sha256 = HashUtil.generateSHA256Hash(hashMessage);
        calculatedHash = HashUtil.calculateHmacSHA256(sha256, secretKey);
      }
      catch (NoSuchAlgorithmException | InvalidKeyException e) {
        AppLogger.error(sessionVO, "Exception while Hashing", e);
      }
      AppLogger.info(sessionVO, String.format("Req Header Hash|Calculated Hash: %s|%s",hash, calculatedHash));
      AppLogger.info(sessionVO, String.format("Req Header Hash|  RawJson Hash: %s|%s",hash, rawJsonHash));
      if (!hash.equals(rawJsonHash)) {
        List<String>        msgCds = Arrays.asList(ValidationStatus.HASH_INVALID.getErrString());
        Map<String, Object> meta   = fslHelper.updateResMeta(sessionVO, msgCds);
        AppLogger.error(sessionVO, "Request Hash is not valid :" + hash, null);
        AppLogger.info(sessionVO, "Sorted json for hash: " + new EncDecHelper().encodeStrToBase64(hashMessage.getBytes()));
        throw new BusinessException(FSLResponseStatus.FSL_SECURITY_VALIDATION_FAILED, msgCds, meta);
      }
  }

  private String serializeJson(ISessionVO sessVO, IMWRequest<?> mwRequest) {
    ObjectMapper mapper = JsonMapper.builder()
        .configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, true)
        .serializationInclusion(Include.NON_NULL)
        .build();
    
    bigDecimalSerializer(mapper);
    mapper.enable(JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN);
    
    try {
      return mapper.writeValueAsString(mwRequest);
    }
    catch (JsonProcessingException e) {
      AppLogger.error(sessVO, "error while seralizing", e);
    }
    
    return "";
  }
  
  // Added condition to avoid serialization for higher numeric  value of bigDecimal
  private void bigDecimalSerializer(ObjectMapper mapper)
  {
    SimpleModule module = new SimpleModule();
    module.addSerializer(BigDecimal.class, new JsonSerializer<BigDecimal>() {
      public void serialize(BigDecimal value, JsonGenerator gen, SerializerProvider serializers)
          throws IOException {
        if (osType != null && FSLConstants.IOS.equalsIgnoreCase(osType)) {
          
          if (value.stripTrailingZeros().scale() <= 0) {
            gen.writeNumber(value.setScale(1, RoundingMode.HALF_UP).toPlainString());
          }
          else {
            gen.writeNumber(value.toPlainString());
          }
        }
        else {
          gen.writeNumber(value.setScale(2, RoundingMode.HALF_UP).toPlainString());
        }
      }
      
    });
    mapper.registerModule(module);
    
  }
}
