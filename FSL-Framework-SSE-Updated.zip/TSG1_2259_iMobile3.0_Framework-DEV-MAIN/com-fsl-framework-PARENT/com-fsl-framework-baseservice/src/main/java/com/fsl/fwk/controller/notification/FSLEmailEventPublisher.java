package com.fsl.fwk.controller.notification;

import java.io.File;
import java.util.HashMap;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.tcs.fwk.constants.FwkConstants;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.event.FwkEventConfig;
import com.tcs.fwk.event.MWServiceEventPublisher;
import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWRequest;
import com.tcs.fwk.model.MWRequestAddOn;
import com.tcs.fwk.service.MWService;
import com.tcs.fwk.service.User;
import com.tcs.fwk.service.model.EventRequestEnvelope;
import com.tcs.fwk.util.GenericUtil;
import com.tcs.fwk.util.JSONUtil;

@Configuration
public class FSLEmailEventPublisher implements IFSLEmailEventPublisher {

	@Autowired Environment env;
	
	@Autowired TemplateProcessor templateProcessor;
	
	private static final String EMAIL_SVC_ID = "MessagingEmailSendG";
	private static final String EMAIL_REST_NAME = "messaging-email-send";
	private MWServiceEventPublisher producer;

	@Autowired
	private void populateEventPublisher(ApplicationContext context) {
		if (context.containsBean(FwkEventConfig.FwkEventConfigBeanName)) {
			this.producer = context.getBean(MWServiceEventPublisher.class);
		}
	}

	private User copyUserObject(ISessionVO sessVO, IMWRequestAddOn reqAddOn) {
		User user = null;
		if ((reqAddOn != null) && (reqAddOn.getUser() != null)) {
				user = new User(
						reqAddOn.getUser().getUserID(), 
						reqAddOn.getUser().getOrgID(), // TODO: Confirm if to set null
						reqAddOn.getUser().getUserType() // TODO: Confirm if to set null
				);
		}
		return user;
	}

	@Override
	public final boolean publishFSLEmailEvent(ISessionVO sessVO, EmailDataVO emailDataVO, IMWRequestAddOn reqAddOn,
			MWService mwService) {
		
		try {
			if (isEmailEventEnable(sessVO, env, mwService)) {
				MessagingEmailSendGReqBody emailReqbody = new MessagingEmailSendGReqBody();
				/* Populate only required data in email request body */
				MWRequest<MessagingEmailSendGReqBody> emailReq = new MWRequest<>();
				MWRequestAddOn emailReqAddOn = new MWRequestAddOn(sessVO.getTrcID());
	
				emailReqAddOn.setRestName(EMAIL_REST_NAME);
				emailReqAddOn.setInputSchemaValidated(reqAddOn.isInputSchemaValidated());
				emailReqAddOn.setUser(copyUserObject(sessVO, reqAddOn));
	
				emailReqAddOn.addHeader(FwkConstants.HEADER_SECRET,
						reqAddOn.getHeadersMap().get(FwkConstants.HEADER_SECRET));
				emailReqAddOn.addHeader(FwkConstants.HEADER_TRACE_ID,
						reqAddOn.getHeadersMap().get(FwkConstants.HEADER_TRACE_ID));
	
				emailReq.setTrcID(sessVO.getTrcID());
				
				if (emailDataVO != null) {
					
					emailReqbody.setFrom(emailDataVO.getFrom());
					emailReqbody.setTo(emailDataVO.getTo());
					emailReqbody.setCc(emailDataVO.getCc());
					emailReqbody.setBcc(emailDataVO.getBcc());
					emailReqbody.setSubject(emailDataVO.getSubject());
					emailReqbody.setBodyTemplateId(emailDataVO.getBodyTemplateId());
					emailReqbody.setBodyParams(processBodyParam(emailDataVO.getBodyParams()));
					emailReqbody.setAttachmentsFileLocation(emailDataVO.getAttachmentsFileLocation());
					emailReqbody.setAttachmentList(emailDataVO.getAttachmentList());
					emailReqbody.setPurgeAttachment(emailDataVO.isPurgeAttachment());
					validateEmailData(sessVO, emailReqbody);
					
					
				}
				emailReq.setBody(emailReqbody);
	
				AppLogger.debug(sessVO, "Publishing email event for service " + mwService.myServiceID() + " : " + JSONUtil.staticMaskedSerializeJSONObj(sessVO, emailReq));
				
				if (producer != null) {
					FwkResponseStatus eventStatus = producer.sendMessage(sessVO, EMAIL_SVC_ID, null,
							new EventRequestEnvelope(emailReq, emailReqAddOn), null);
					
					AppLogger.info(sessVO,
							"Email event published for service " + mwService.myServiceID() + " with stsCd: " + eventStatus.getCode());
					
					return FwkResponseStatus.ASYNC_REQUEST_SENT.equals(eventStatus);
				}
				else {
					AppLogger.info(sessVO, "Producer is null while Publishing Email event for service: " + mwService.myServiceID());
				}

			}
						     		
		} catch (Exception e) {
			AppLogger.error(sessVO, "Exception Occurred while Publishing Email event for service " + mwService.myServiceID(), e);
		}
		
		return false;
	}
	
	
		@Override
		public final void publishFSLEmailEventAsync(ISessionVO sessVO, EmailDataVO emailDataVO, IMWRequestAddOn reqAddOn,
				MWService mwService) {
			CompletableFuture.runAsync(() -> {
				publishFSLEmailEvent(sessVO, emailDataVO, reqAddOn, mwService);
			});
			
		}
		
		private void validateEmailData(ISessionVO sessVO, MessagingEmailSendGReqBody emailReqBody) {
			  			  
			  if (GenericUtil.isNullOrEmpty(emailReqBody.getTo()) || emailReqBody.getTo().contains(null)
			    || GenericUtil.isNullOrEmpty(emailReqBody.getFrom())
			    || GenericUtil.isNullOrEmpty(emailReqBody.getSubject())
			    || GenericUtil.isNullOrEmpty(emailReqBody.getBodyTemplateId())) {
			   throw new SystemException("Some Required field(s) [ to, from, subject, bodyTemplateId ] are missing");
			  }
			  
			  if (emailReqBody.getAttachmentList() != null) {
			   for (String fileName : emailReqBody.getAttachmentList()) {
			    File file = new File(emailReqBody.getAttachmentsFileLocation() + fileName);
			    if(!file.exists())
			     throw new SystemException("Attachment " + fileName + " does not exists!");
			   }
			  }
			  
			  String mailBody   = templateProcessor.processTemplate(emailReqBody.getBodyTemplateId(), emailReqBody.getBodyParams());
			  AppLogger.debug(sessVO, "Processed mail body ---------- \n" + mailBody);
			 }		
		
			
	private HashMap<String, String> processBodyParam(HashMap<String, String> bodyParam){
		bodyParam.forEach((k, v) -> {
			if (k == null)
				bodyParam.remove(k);
			if (v == null)
				bodyParam.put(k, "");
		});
		
		return bodyParam;
	}

}
