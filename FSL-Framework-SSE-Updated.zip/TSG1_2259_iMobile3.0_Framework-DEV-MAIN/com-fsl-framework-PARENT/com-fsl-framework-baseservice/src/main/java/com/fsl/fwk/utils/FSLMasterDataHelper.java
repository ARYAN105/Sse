package com.fsl.fwk.utils;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.model.FSLBankMstr;
import com.fsl.fwk.model.FSLBranchMstr;
import com.tcs.fwk.cache.master.MasterDataSearchConstants.SearchType;
import com.tcs.fwk.cache.master.client.MasterDataCacheClient;
import com.tcs.fwk.cache.master.model.IMasterRowEntity;
import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.util.GenericUtil;

public class FSLMasterDataHelper {

	@Autowired

	MasterDataCacheClient dataCacheClient;

	public Object BranchMstr(String key, String value) throws BusinessException {
		if (GenericUtil.isNullOrEmpty(value) || GenericUtil.isNullOrEmpty(key)) {
			return null;
		}
		Iterable<IMasterRowEntity> masterEntity = null;
		List<FSLBranchMstr> branchMstrsList=null;
		FSLBranchMstr branchMstr=null;
		if (GenericUtil.isNeitherNullNorEmpty(masterEntity)) {
			branchMstrsList=new ArrayList<>();
			for (IMasterRowEntity iMasterRowEntity : masterEntity) {
				branchMstr=new FSLBranchMstr();
				branchMstr.setBankRefNo(iMasterRowEntity.getAddtnlcols().get(0).toString());
				branchMstr.setBankNm(iMasterRowEntity.getAddtnlcols().get(1).toString());
				branchMstr.setBranchNm(iMasterRowEntity.getAddtnlcols().get(2).toString());
				branchMstr.setAddr(iMasterRowEntity.getAddtnlcols().get(3).toString());
				branchMstr.setIfscCd(iMasterRowEntity.getAddtnlcols().get(4).toString());
				branchMstr.setCity(iMasterRowEntity.getAddtnlcols().get(5).toString());
				branchMstr.setState(iMasterRowEntity.getAddtnlcols().get(6).toString());
				branchMstr.setZipCd(iMasterRowEntity.getAddtnlcols().get(7).toString());
				branchMstr.setCountry(iMasterRowEntity.getAddtnlcols().get(8).toString());
				branchMstrsList.add(branchMstr);
			}
		}
		return branchMstrsList;
	}
	public Object PopularBankMstr(String keyVal) throws BusinessException {
		
		if (GenericUtil.isNullOrEmpty(keyVal)) {
			return null;
		}
		String searchVal = keyVal;
		Iterable<IMasterRowEntity> masterEntity = null;
		List<FSLBankMstr> bankMstrList=null;
		FSLBankMstr bankMstr=null;
		masterEntity = dataCacheClient.findMasterRows_byCode(null, FSLConstants.MASTER_TYPE.POPBANKMSTR.toString() , searchVal, SearchType.EXACT_SEARCH,
				null);
		if (GenericUtil.isNeitherNullNorEmpty(masterEntity)) {
				bankMstrList=new ArrayList<>();
			for (IMasterRowEntity iMasterRowEntity : masterEntity) {
				bankMstr=new FSLBankMstr();
				int cnt=iMasterRowEntity.getDesc().toString().indexOf("-");
				String[] bnkDesc=iMasterRowEntity.getDesc().toString().split("-");
				bankMstr.setBankNm(bnkDesc[0].toString());
				bankMstr.setIfscCd(iMasterRowEntity.getPk().toString());
				bankMstr.setIfscInit(cnt>1?bnkDesc[1].toString():"");
				bankMstrList.add(bankMstr);
			}
		}
		return bankMstrList;
	}

	public Object AllBankMstr(String keyVal) throws BusinessException {

		
		if (GenericUtil.isNullOrEmpty(keyVal)) {
			return null;
		}
		String searchVal = keyVal;
		Iterable<IMasterRowEntity> masterEntity = null;
		List<FSLBankMstr> bankMstrList=null;
		FSLBankMstr bankMstr=null;
		masterEntity = dataCacheClient.findMasterRows_byCode(null, FSLConstants.MASTER_TYPE.ALLBANKMSTR.toString(), searchVal, SearchType.EXACT_SEARCH,
				null);
		if (GenericUtil.isNeitherNullNorEmpty(masterEntity)) {
				bankMstrList=new ArrayList<>();
			for (IMasterRowEntity iMasterRowEntity : masterEntity) {
				bankMstr=new FSLBankMstr();
				int cnt=iMasterRowEntity.getDesc().toString().indexOf("-");
				String[] bnkDesc=iMasterRowEntity.getDesc().toString().split("-");
				bankMstr.setBankNm(bnkDesc[0].toString());
				bankMstr.setIfscCd(iMasterRowEntity.getPk().toString());
				bankMstr.setIfscInit(cnt>1?bnkDesc[1].toString():"");
				bankMstrList.add(bankMstr);
			}
		}
		return bankMstrList;
	}
}
