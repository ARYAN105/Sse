package com.fsl.fwk.model;

import lombok.Data;

@Data
public class FSLProfileTimeTaken {
  Long devIdRecFetchTime      = null;
  Long imeiRecFetchTime       = null;
  Long userRecFetchTime       = null;
  Long carBIdRecFetchTime     = null;
  Long carUIdRecFetchTime     = null;
  Long carJSONDataProcessTime = null;
  Long carXMLDataProcessTime  = null;
  
  @Override
  public String toString() {
    return "DR:" + getOrDefault(devIdRecFetchTime, "-") + "#" 
        + "IR:" + getOrDefault(imeiRecFetchTime, "-") + "#" 
        + "UR:" + getOrDefault(userRecFetchTime, "-") + "#" 
        + "CBR:" + getOrDefault(carBIdRecFetchTime, "-") + "#" 
        + "CUR:" + getOrDefault(carUIdRecFetchTime, "-") + "#" 
        + "CJP:" + getOrDefault(carJSONDataProcessTime, "-") + "#" 
        + "CXP:" + getOrDefault(carXMLDataProcessTime, "-");
  }
  
  private String getOrDefault(Object ttValue, String defaultVal) {
    return (ttValue != null) ? ttValue+"" : (String) defaultVal;
  }
  
}
