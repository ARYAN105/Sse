package com.fsl.fwk.deh.model;

import com.tcs.fwk.model.BaseModel;

import lombok.Data;

@Data
public class DehResponsePagination extends BaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = DehResponsePagination.class.getCanonicalName().hashCode();
	String numRecReturned = "0";
	String hasMoreRecords = "N";
	String nextStartIndex="";

}
