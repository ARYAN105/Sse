package com.fsl.fwk.generic;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.tcs.fwk.exception.SystemException;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.util.GenericUtil;

/**
 * <p>
 * FSLInterServiceData is used in case of EmbeddedOrchService to pass the data between the services.<dd></dd>
 * It will only work for <b> mwlocal </b> calls and not <b> mwremote </b> calls 
 * </p>
 * @author Omkar Powar
 * @author Tata Consultancy Services
 */
public class FSLInterServiceData extends BaseModel {
	
	private static final long serialVersionUID = FSLInterServiceData.class.getCanonicalName().hashCode();


	private final Map<String, Object> attributes = new HashMap<>();
	
	public void put(String key, Object value) {
		if(GenericUtil.isNullOrEmpty(key)) {
			throw new SystemException("Key cannot be null or empty");
		}
		
		attributes.put(key, value);
	}
	
	public Object get(String key) {
		return attributes.get(key);
	}

	public Map<String, Object> getAttributes(){
		return Collections.unmodifiableMap(attributes);
	}
}
