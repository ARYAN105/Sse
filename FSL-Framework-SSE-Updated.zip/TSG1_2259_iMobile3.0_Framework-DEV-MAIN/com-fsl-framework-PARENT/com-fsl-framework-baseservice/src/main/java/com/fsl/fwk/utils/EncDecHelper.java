package com.fsl.fwk.utils;

import java.util.Base64;

import javax.crypto.spec.SecretKeySpec;

public class EncDecHelper {
  
  public byte[] encodeToBase64(byte[] input) {
    return Base64.getEncoder().encode(input);
  }
  
  public byte[] decodeFromBase64(byte[] input) {
    return Base64.getDecoder().decode(input);
  }
  
  public String encodeStrToBase64(byte[] input) {
    return Base64.getEncoder().encodeToString(input);
  }
  
  public SecretKeySpec getSecretKey(byte[] keyBytes, EncDecMode algorithm) {
    return new SecretKeySpec(keyBytes, algorithm.name());
  }
}