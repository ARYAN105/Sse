package com.fsl.fwk.controller.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tcs.fwk.model.BaseModel;

public class FSLError extends BaseModel {

	private static final long serialVersionUID = "com.fsl.fwk.controller.model.FSLError".hashCode();
	
	@JsonProperty(value="errCd")
	@JsonInclude(Include.NON_EMPTY)
	private String errCd = null;

	@JsonProperty(value="errMsg")
	//@JsonInclude(Include.NON_EMPTY)
	private String errMsg = null;
	
	@JsonProperty(value="errTitle")
	private String errTitle=null;
	
	@JsonProperty(value="actCd")
	private String actionCode=null;
	
	public String getErrCd() {
		return errCd;
	}

	public void setErrCd(String errCd) {
		this.errCd = errCd;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public String getErrTitle() {
		return errTitle;
	}

	public void setErrTitle(String errTitle) {
		this.errTitle = errTitle;
	}
	
	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
}
