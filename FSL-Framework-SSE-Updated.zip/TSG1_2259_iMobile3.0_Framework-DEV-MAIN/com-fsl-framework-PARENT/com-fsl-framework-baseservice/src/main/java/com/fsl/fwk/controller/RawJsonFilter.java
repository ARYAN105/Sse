
package com.fsl.fwk.controller;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.utils.HashUtil;
import com.tcs.fwk.constants.FwkConstants;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.SessionVO;
import com.tcs.fwk.util.GenericUtil;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;

@Component
public class RawJsonFilter implements Filter {

	@Autowired
	Environment env;

	@Autowired
	HashUtil hashUtil;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		if (request instanceof HttpServletRequest) {
			HttpServletRequest httpRequest = (HttpServletRequest) request;

			String contentType = httpRequest.getContentType();
			if (contentType != null && contentType.startsWith("multipart/form-data")) {
				chain.doFilter(request, response);
				return;
			}

			CachedBodyHttpServeletRequest wrappedRequest = new CachedBodyHttpServeletRequest(httpRequest);
			String body = new String(wrappedRequest.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

			String isValidated = wrappedRequest.getHeader(FSLConstants.IS_VALIDATED);
			String txnID = wrappedRequest.getHeader(FSLConstants.TXN_ID);
            String  hash = wrappedRequest.getHeader(FSLConstants.HEADER_HASH);

			if (GenericUtil.isNullOrEmpty(isValidated) && GenericUtil.isNullOrEmpty(txnID)) {
				if (!GenericUtil.isNullOrEmpty(hash)) {

					String calculatedHash = generateHash(
							new SessionVO(wrappedRequest.getHeader(FwkConstants.HEADER_TRACE_ID)), body,
							wrappedRequest.getHeader(FwkConstants.HEADER_TRACE_ID));
					wrappedRequest.setAttribute("FslHash", calculatedHash);
				}
			}
			chain.doFilter(wrappedRequest, response);
		} else {
			chain.doFilter(request, response);
		}
	}

	private String sortJson(ISessionVO sessVO, String jsonReq) {
		JsonMapper mapper = JsonMapper.builder().enable(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS)
				.enable(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY)
				.enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
				.enable(JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN).build();

		try {
			HashMap<String, Object> map = mapper.readValue(jsonReq, HashMap.class);
			String sortedJson = mapper.writeValueAsString(map);
			
			return sortedJson;
		} catch (JsonProcessingException e) {
			AppLogger.error(sessVO, "Error while sorting the jsonReq", e);
		}

		return null;
	}

	private String generateHash(ISessionVO sessionVO, String jsonReq, String trcID) {
		String hashMessage = sortJson(sessionVO, jsonReq) + "|" + trcID;
		
		AppLogger.info(sessionVO,"\nSorted Json : \n"+jsonReq);
		String secretKey = env.getProperty("FSL.EAIGATEWAY.HASH.SALT");
		String calculatedHash = "";

		try {
			String sha256 = HashUtil.generateSHA256Hash(hashMessage);
			calculatedHash = HashUtil.calculateHmacSHA256(sha256, secretKey);
		} catch (NoSuchAlgorithmException | InvalidKeyException e) {
			AppLogger.error(sessionVO, "Exception while Hashing", e);
		}
		AppLogger.info(sessionVO, "Calculated Hash: " + calculatedHash);
		return calculatedHash;
	}
}