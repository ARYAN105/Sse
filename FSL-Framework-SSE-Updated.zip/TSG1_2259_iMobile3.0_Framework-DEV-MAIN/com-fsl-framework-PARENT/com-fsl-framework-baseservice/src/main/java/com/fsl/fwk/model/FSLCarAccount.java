package com.fsl.fwk.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tcs.fwk.logger.masking.MaskRule;
import com.tcs.fwk.logger.masking.MaskSensitive;
import com.tcs.fwk.logger.masking.Sensitive;
import com.tcs.fwk.model.BaseModel;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@MaskSensitive
public class FSLCarAccount extends BaseModel {
	private static final long serialVersionUID = "com.fsl.fwk.model.FSLCarAccountList".hashCode();

  @JsonProperty("cId")
	private String custId;
  @JsonProperty("fsId")
	private String fsId;
  @Sensitive(rule = MaskRule.EXCLUDELAST, param = "4")
  @JsonProperty("aNo")
	private String accNo;
  @JsonProperty("aTp")
	private String accType;
  @JsonProperty("aSTp")
	private String accSubType;
  @JsonProperty("sNo")
	private String serNo;
  @JsonProperty("aNm")
	private String accName;
  @JsonProperty("pAFl")
	private String primaryAccFlg;
  @JsonProperty("bHSt")
	private String bankHomeStatus;
  @JsonProperty("mSt")
	private String minorStatus;
  @JsonProperty("nATp")
	private String nriAccountType;
  @JsonProperty("dATp")
	private String derivedAccountType;
  @JsonProperty("iJtA")
	private String isJntAcct;

}
