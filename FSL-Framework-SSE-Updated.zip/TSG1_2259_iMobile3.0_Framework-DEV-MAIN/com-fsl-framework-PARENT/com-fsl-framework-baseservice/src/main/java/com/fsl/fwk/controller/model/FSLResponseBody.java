package com.fsl.fwk.controller.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.tcs.fwk.model.BaseResponseBody;

/**
 * @author Tata Consultancy Services
 */
//@JsonInclude(Include.NON_EMPTY)
public class FSLResponseBody extends BaseResponseBody {

	private static final long serialVersionUID = "com.fsl.fwk.controller.model.FSLResponseBody".hashCode();

	@JsonProperty(value="errors")
	@JsonInclude(Include.NON_EMPTY)
	public List<FSLError> errors = null; //"errors":[{"errCd":"","errMsg":""},{}]
	
	//pagination elems can also be included here
	@JsonProperty(value="pagedData")
	@JsonInclude(Include.NON_EMPTY)
	private List<?> pagedData = null;
	
	@JsonIgnore
	private FSLAuditData auditData;

	
	public List<?> getPagedData() {
		return pagedData;
	}

	public void setPagedData(List<?> pagedData) {
		this.pagedData = pagedData;
	}

	public FSLAuditData getAuditData() {
		return auditData;
	}

	public void setAuditData(FSLAuditData auditData) {
		this.auditData = auditData;
	}
}
