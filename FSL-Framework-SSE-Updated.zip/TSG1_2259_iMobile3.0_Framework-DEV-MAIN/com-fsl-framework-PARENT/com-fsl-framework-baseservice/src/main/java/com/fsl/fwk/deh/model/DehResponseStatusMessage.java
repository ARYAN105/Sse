package com.fsl.fwk.deh.model;

import com.tcs.fwk.model.BaseModel;

import lombok.Data;

/**
 * @author Nikhil Bhumkar
 * @author Tata Consultancy Services
 */
@Data
public class DehResponseStatusMessage extends BaseModel{
	
	private static final long serialVersionUID = "com.fsl.fwk.integration.deh.DehResponseStatusMessage".hashCode();

	String message_TYPE = null ;

    String messageCode = null ;

    String messageDesc = null ;

    String messageAddlnInfo = null ;
    
    String nameSpaceInfo=null;
    
    String message_PARAM=null;
	
}
