# FSL in-process SSE implementation (POC)

This package contains the FSL framework module and the Integration microservice changes for the agreed architecture:

- The existing Integration microservice hosts the SSE GET endpoint.
- Existing Java business services inject `SseEventPublisher` and publish events in-process.
- The UI/Postman connects to `GET /fsl/sse/stream`.
- There is no separate SSE microservice, no publish HTTP endpoint, and no `ssedemo` package/controller.

## 1. Contents

### `framework/TSG1_2259_iMobile3.0_Framework-DEV-MAIN/`

Changes in the FSL Framework source tree:

- `com-fsl-framework-PARENT/pom.xml` — adds the new `com-fsl-framework-sse` Maven module.
- `com-fsl-framework-dependency-PARENT/pom.xml` — manages the new module version with the existing FSL version property.
- `com-fsl-framework-PARENT/com-fsl-framework-sse/` — SSE publisher API, connection manager, GET controller, Spring configuration, and the SSE-aware TCS response-filter registration.

### `integration/Integration/`

Changes in the supplied Integration project:

- `com-fsl-microservice-filteruserbank/pom.xml` — adds the SSE framework dependency.
- `.../bankusertypefind/BankUsertypeFindISvc.java` — injects `SseEventPublisher` and publishes a generic completion notification after the existing successful response is prepared.

`BankUsertypeFindICntlr.java`, the model modules, and the outbound model module are not changed.

## 2. Runtime flow

1. UI/Postman opens `GET /fsl/sse/stream` with `Accept: text/event-stream`.
2. The framework creates an `SseEmitter` and stores it in the local `SseConnectionManager`.
3. The existing `BankUsertypeFindISvc` completes its normal integration-response mapping.
4. It invokes `sseEventPublisher.publish(new SseEvent(...))` directly in Java. No HTTP publish call is made.
5. The manager writes the event to all SSE connections registered in that same Integration JVM.

The initial stream response contains a `CONNECTED` event with a generated connection ID. A business completion event has the event name `BANK_USERTYPE_FIND_COMPLETED` and the non-sensitive payload `{ "status": "SUCCESS" }`.

## 3. TCS response-caching filter compatibility

The supplied TCS 0.0.9 source for `com.tcs.fwk.service.MyFilter` wraps every response in `ContentCachingResponseWrapper` and copies the cached body after the filter chain returns. That pattern is not suitable for a long-lived SSE response because SSE needs to flush events incrementally.

The SSE module therefore conditionally replaces the servlet registration of the existing `myFilter` bean with `SseAwareResponseCachingFilter`. For ordinary requests it preserves the existing hostname check and content-caching/copy behavior. For `/fsl/sse/stream`, it preserves the hostname check but passes the original response through without `ContentCachingResponseWrapper`.

The original `MyFilter` bean remains in the Spring context; only its automatic servlet-filter registration is disabled. This configuration is conditional on the TCS `MyFilter` class and the `myFilter` bean being present.

## 4. Build / install

The FSL Framework source archive supplied for this task has these versions in its POMs:

- FSL parent: `0.0.7`
- `fsl.fwk.version`: `0.0.7`

The supplied Integration microservice POM instead declares FSL parent `0.0.9`. This is a real version mismatch in the input files. To avoid pretending the supplied FSL source is 0.0.9, the new module inherits `0.0.7`, and the Integration dependency explicitly requests `com-fsl-framework-sse:0.0.7`.

Build/install the FSL framework parent project with the new module included (the TCS 0.0.7 parent and internal dependencies must already be available through your configured Maven repository):

```bash
mvn -f com-fsl-framework-PARENT/pom.xml clean install -DskipTests
```

Then refresh Maven dependencies in Eclipse for the Integration project and build it against the installed `com-fsl-framework-sse:0.0.7` artifact. Keep the existing framework dependency order intact; the SSE dependency is added after `com-fsl-framework-integration`.

**Before using this mixed-version setup beyond the POC:** align the new SSE module to the FSL 0.0.9 framework source/release used by Integration. The exact 0.0.9 FSL parent POM was not included in the supplied framework source archive, so this package does not silently rewrite the supplied FSL source POMs to 0.0.9. Once you have the matching 0.0.9 FSL source, update the framework parent/module versions and the Integration dependency version together to `0.0.9`.

## 5. Test with Postman or curl

1. Start the existing Integration microservice.
2. Open the collection in `postman/FSL-SSE-Integration-POC.postman_collection.json`.
3. Run **Open SSE stream** first. Keep the request open. It should receive a `CONNECTED` event.
4. Run **Invoke existing Bank Usertype Find service**. Use the same authentication and required headers that the existing Integration endpoint needs in your environment.
5. The open stream should receive `BANK_USERTYPE_FIND_COMPLETED`.

The stream can also be opened with:

```bash
curl -N -H "Accept: text/event-stream" http://localhost:8080/fsl/sse/stream
```

The existing business POST endpoint is `/bank-usertype-find`; its request schema is already present in `src/main/resources/schemas/BankUsertypeFindI.yaml`.

## 6. Important POC boundaries

- **Broadcast scope:** this initial implementation broadcasts each event to every SSE connection in the same Integration JVM. The sample payload is deliberately generic. Do not publish account, customer, session, or other user-specific information until recipient-level routing and authorization are implemented.
- **Replica scope:** connections are held in memory. A publish call on one pod cannot reach a UI connected to another pod. Multi-replica delivery will require sticky routing or a distributed event mechanism.
- **Authentication:** this module does not invent or bypass FSL authentication. Protect the stream endpoint using the Integration application's existing security configuration and ensure the UI supplies the required credentials.
- **Heartbeat:** this POC does not schedule heartbeat events. Add heartbeats if the deployment's ingress/load balancer terminates idle streams.
- **Validation:** Maven was not available in the file-generation environment, and the proprietary/internal parent artifacts are not locally installed here. The XML and source structure were checked, but a Maven compile or live runtime test has not been claimed.
