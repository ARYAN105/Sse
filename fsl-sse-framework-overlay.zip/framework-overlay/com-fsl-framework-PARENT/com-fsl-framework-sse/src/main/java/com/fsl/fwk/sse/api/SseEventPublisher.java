package com.fsl.fwk.sse.api;

import com.fsl.fwk.sse.model.SsePublishRequest;
import com.fsl.fwk.sse.model.SsePublishResult;

/**
 * In-process publishing API for services running in the same FSL application
 * instance as the SSE connection registry.
 */
public interface SseEventPublisher {

    /**
     * Sends an event to the matching SSE connections registered in this JVM.
     * The result reports server-side emitter writes, not browser acknowledgement.
     */
    SsePublishResult publish(SsePublishRequest request);
}
