package com.fsl.fwk.sse.controller;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.fsl.fwk.sse.auth.SseClientAuthenticator;
import com.fsl.fwk.sse.auth.SsePrincipal;
import com.fsl.fwk.sse.core.SseConnectionManager;
import com.fsl.fwk.sse.core.SseConnectionLimitException;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@ConditionalOnProperty(prefix = "fsl.sse", name = "enabled", havingValue = "true")
public class SseConnectionController {
    private final SseClientAuthenticator authenticator;
    private final SseConnectionManager connectionManager;

    public SseConnectionController(SseClientAuthenticator authenticator,
                                   SseConnectionManager connectionManager) {
        this.authenticator = authenticator;
        this.connectionManager = connectionManager;
    }

    @GetMapping(path = "${fsl.sse.stream-path:/fsl/sse/stream}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public ResponseEntity<SseEmitter> connect(HttpServletRequest request) {
        SsePrincipal principal = authenticator.authenticate(request);
        if (principal == null) {
            throw new ResponseStatusException(org.springframework.http.HttpStatus.UNAUTHORIZED,
                    "SSE client authentication failed");
        }
        try {
            SseEmitter emitter = connectionManager.openConnection(principal);
            HttpHeaders headers = new HttpHeaders();
            headers.setCacheControl(CacheControl.noCache().getHeaderValue() + ", no-transform");
            headers.set("X-Accel-Buffering", "no");
            headers.setPragma("no-cache");
            return ResponseEntity.ok().headers(headers)
                    .contentType(MediaType.TEXT_EVENT_STREAM)
                    .body(emitter);
        } catch (SseConnectionLimitException limitException) {
            return ResponseEntity.status(429).build();
        }
    }
}
