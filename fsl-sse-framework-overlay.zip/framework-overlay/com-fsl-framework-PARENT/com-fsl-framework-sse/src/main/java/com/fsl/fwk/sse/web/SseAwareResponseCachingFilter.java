package com.fsl.fwk.sse.web;

import java.io.IOException;
import java.util.List;

import org.springframework.web.util.ContentCachingResponseWrapper;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Replacement for TCS MyFilter while SSE is enabled. It retains the allowed-host
 * check and ordinary response content-length calculation, but bypasses response
 * caching for the long-lived SSE stream.
 */
public class SseAwareResponseCachingFilter implements Filter {
    private final List<String> allowedHostnames;
    private final String streamPath;

    public SseAwareResponseCachingFilter(List<String> allowedHostnames, String streamPath) {
        this.allowedHostnames = allowedHostnames == null ? List.of("*") : List.copyOf(allowedHostnames);
        this.streamPath = streamPath;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        String hostname = httpRequest.getServerName();

        if (!allowedHostnames.contains("*") && !allowedHostnames.contains(hostname)) {
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        if (isSseStreamRequest(httpRequest)) {
            chain.doFilter(request, response);
            return;
        }

        ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(httpResponse);
        try {
            chain.doFilter(request, responseWrapper);
        } finally {
            responseWrapper.copyBodyToResponse();
        }
    }

    private boolean isSseStreamRequest(HttpServletRequest request) {
        String requestUri = request.getRequestURI();
        String contextPath = request.getContextPath();
        String applicationPath = requestUri.substring(Math.min(contextPath.length(), requestUri.length()));
        return streamPath.equals(applicationPath);
    }
}
