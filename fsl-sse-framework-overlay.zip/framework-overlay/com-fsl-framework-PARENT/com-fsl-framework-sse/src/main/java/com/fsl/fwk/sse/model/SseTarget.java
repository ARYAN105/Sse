package com.fsl.fwk.sse.model;

/** Exactly one target selector is used according to type. */
public record SseTarget(SseTargetType type, String userId, String sessionId, String connectionId) {

    public static SseTarget user(String userId) {
        return new SseTarget(SseTargetType.USER, userId, null, null);
    }

    public static SseTarget session(String userId, String sessionId) {
        return new SseTarget(SseTargetType.SESSION, userId, sessionId, null);
    }

    public static SseTarget connection(String connectionId) {
        return new SseTarget(SseTargetType.CONNECTION, null, null, connectionId);
    }

    public void validate() {
        if (type == null) {
            throw new IllegalArgumentException("target.type is required");
        }
        switch (type) {
            case USER -> {
                require(userId, "target.userId");
                reject(sessionId, "target.sessionId");
                reject(connectionId, "target.connectionId");
            }
            case SESSION -> {
                require(userId, "target.userId");
                require(sessionId, "target.sessionId");
                reject(connectionId, "target.connectionId");
            }
            case CONNECTION -> {
                require(connectionId, "target.connectionId");
                reject(userId, "target.userId");
                reject(sessionId, "target.sessionId");
            }
        }
    }

    private static void require(String value, String field) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(field + " is required");
        }
    }

    private static void reject(String value, String field) {
        if (value != null) {
            throw new IllegalArgumentException(field + " must not be supplied for this target type");
        }
    }
}
