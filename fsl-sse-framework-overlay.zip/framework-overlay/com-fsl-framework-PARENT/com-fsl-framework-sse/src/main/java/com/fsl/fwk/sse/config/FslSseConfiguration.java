package com.fsl.fwk.sse.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.fsl.fwk.sse.core.FslSseProperties;
import com.fsl.fwk.sse.core.SseConnectionManager;
import com.fsl.fwk.sse.web.SseAwareResponseCachingFilter;
import com.tcs.fwk.service.MyFilter;

import jakarta.servlet.DispatcherType;
import jakarta.servlet.Filter;

@Configuration
@EnableScheduling
@EnableConfigurationProperties(FslSseProperties.class)
@ConditionalOnProperty(prefix = "fsl.sse", name = "enabled", havingValue = "true")
public class FslSseConfiguration {

    @Bean(destroyMethod = "closeAllConnections")
    public SseConnectionManager sseConnectionManager(FslSseProperties properties) {
        return new SseConnectionManager(properties);
    }

    /**
     * TCS MyFilter caches the complete response body before copying it to the
     * servlet response. That is unsuitable for a never-ending SSE response.
     * Disable only its servlet registration and install an equivalent filter
     * that skips response wrapping for the configured SSE stream path.
     */
    @Bean
    @ConditionalOnBean(MyFilter.class)
    public FilterRegistrationBean<MyFilter> disableTcsMyFilterAutoRegistration(MyFilter myFilter) {
        FilterRegistrationBean<MyFilter> registration = new FilterRegistrationBean<>(myFilter);
        registration.setName("myFilter");
        registration.setEnabled(false);
        return registration;
    }

    @Bean
    @ConditionalOnBean(MyFilter.class)
    public FilterRegistrationBean<Filter> registerSseAwareResponseFilter(
            @Value("${FWK.SERVICE.allowed.hostnames:*}") List<String> allowedHostnames,
            FslSseProperties properties) {
        SseAwareResponseCachingFilter filter = new SseAwareResponseCachingFilter(
                allowedHostnames, properties.getStreamPath());
        FilterRegistrationBean<Filter> registration = new FilterRegistrationBean<>(filter);
        registration.setName("fslSseAwareResponseCachingFilter");
        registration.addUrlPatterns("/*");
        registration.setDispatcherTypes(DispatcherType.REQUEST);
        registration.setOrder(Ordered.LOWEST_PRECEDENCE);
        return registration;
    }
}
