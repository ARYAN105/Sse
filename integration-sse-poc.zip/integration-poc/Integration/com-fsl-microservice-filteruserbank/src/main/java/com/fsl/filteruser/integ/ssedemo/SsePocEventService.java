package com.fsl.filteruser.integ.ssedemo;

import java.time.Instant;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import com.fsl.fwk.sse.api.SseEventPublisher;
import com.fsl.fwk.sse.model.SsePublishRequest;
import com.fsl.fwk.sse.model.SsePublishResult;
import com.fsl.fwk.sse.model.SseTarget;

/** Demonstrates the intended business-service dependency: inject the publisher API, not the connection manager. */
@Service
@ConditionalOnProperty(name = "FSL.SSE.POC.ENABLED", havingValue = "true")
public class SsePocEventService {

    private final SseEventPublisher sseEventPublisher;

    public SsePocEventService(SseEventPublisher sseEventPublisher) {
        this.sseEventPublisher = sseEventPublisher;
    }

    public SsePublishResult publishToUser(SsePocPublishRequest request) {
        if (request == null || request.userId() == null || request.userId().isBlank()) {
            throw new IllegalArgumentException("userId is required");
        }
        if (request.eventType() == null || request.eventType().isBlank()) {
            throw new IllegalArgumentException("eventType is required");
        }

        SsePublishRequest event = new SsePublishRequest(
                null,
                request.eventType(),
                "IntegrationService",
                request.correlationId(),
                Instant.now(),
                SseTarget.user(request.userId()),
                request.payload());

        return sseEventPublisher.publish(event);
    }
}
