package com.fsl.filteruser.integ.ssedemo;

import java.util.Map;

public record SsePocPublishRequest(
        String userId,
        String eventType,
        String correlationId,
        Map<String, Object> payload) {
}
