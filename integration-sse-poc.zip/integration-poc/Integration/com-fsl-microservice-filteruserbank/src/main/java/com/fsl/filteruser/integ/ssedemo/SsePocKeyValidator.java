package com.fsl.filteruser.integ.ssedemo;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import jakarta.annotation.PostConstruct;

/** Local POC-only shared-key check. Replace with the approved gateway/FSL authentication adapter. */
@Component
@ConditionalOnProperty(name = "FSL.SSE.POC.ENABLED", havingValue = "true")
public class SsePocKeyValidator {

    @Value("${FSL.SSE.POC.SECRET:}")
    private String expectedKey;

    @PostConstruct
    void validateConfiguration() {
        if (expectedKey == null || expectedKey.isBlank()) {
            throw new IllegalStateException("FSL.SSE.POC.SECRET must be configured from FSL_SSE_POC_SECRET");
        }
    }

    public void validate(String suppliedKey) {
        if (suppliedKey == null || suppliedKey.isBlank()
                || !MessageDigest.isEqual(expectedKey.getBytes(StandardCharsets.UTF_8),
                        suppliedKey.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid SSE POC key");
        }
    }
}
