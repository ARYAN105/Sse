package com.fsl.filteruser.integ.ssedemo;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.fsl.fwk.constants.FSLConstants;
import com.fsl.fwk.sse.auth.SseClientAuthenticator;
import com.fsl.fwk.sse.auth.SsePrincipal;
import com.tcs.fwk.constants.FwkConstants;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Local Postman adapter only. The shared key is a test guard; the identity
 * headers simulate values a trusted gateway would inject after authentication.
 * This does not execute FSLControllerHelper's full profile/device/security flow.
 */
@Component
@ConditionalOnProperty(name = "FSL.SSE.POC.ENABLED", havingValue = "true")
public class IntegrationSsePocClientAuthenticator implements SseClientAuthenticator {

    private final SsePocKeyValidator keyValidator;

    public IntegrationSsePocClientAuthenticator(SsePocKeyValidator keyValidator) {
        this.keyValidator = keyValidator;
    }

    @Override
    public SsePrincipal authenticate(HttpServletRequest request) {
        keyValidator.validate(request.getHeader("X-SSE-POC-KEY"));

        String userId = request.getHeader(FwkConstants.HEADER_USERID);
        String deviceId = request.getHeader(FwkConstants.HEADER_DEVICEID);
        String idType = request.getHeader(FwkConstants.HEADER_USERID_TYPE);
        String channel = request.getHeader(FwkConstants.HEADER_CHANNEL);

        if (FSLConstants.USERID_TYPE.DID.toString().equalsIgnoreCase(idType)
                || FSLConstants.USERID_TYPE.MNL.toString().equalsIgnoreCase(idType)) {
            userId = deviceId;
        }
        if (userId == null || userId.isBlank() || deviceId == null || deviceId.isBlank()) {
            throw new org.springframework.web.server.ResponseStatusException(
                    org.springframework.http.HttpStatus.UNAUTHORIZED,
                    "userid and deviceid headers are required for the SSE POC");
        }
        if (channel == null || channel.isBlank()) {
            channel = FSLConstants.HEADERVAL_CHANNEL_DEFAULT;
        }

        // POC session key only. Replace with the authenticated session identifier supplied by the real gateway.
        String sessionId = deviceId.trim() + ":" + channel.trim();
        return new SsePrincipal(userId, sessionId, channel, deviceId);
    }
}
