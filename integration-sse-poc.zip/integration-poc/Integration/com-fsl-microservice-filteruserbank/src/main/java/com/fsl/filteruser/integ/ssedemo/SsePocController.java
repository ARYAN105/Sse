package com.fsl.filteruser.integ.ssedemo;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsl.fwk.sse.model.SsePublishResult;

/** Local Postman trigger only. Do not expose this test route in production. */
@RestController
@RequestMapping("/sse-poc")
@ConditionalOnProperty(name = "FSL.SSE.POC.ENABLED", havingValue = "true")
public class SsePocController {

    private final SsePocKeyValidator keyValidator;
    private final SsePocEventService eventService;

    public SsePocController(SsePocKeyValidator keyValidator, SsePocEventService eventService) {
        this.keyValidator = keyValidator;
        this.eventService = eventService;
    }

    @PostMapping(path = "/events", consumes = "application/json", produces = "application/json")
    public ResponseEntity<SsePublishResult> publish(
            @RequestHeader(name = "X-SSE-POC-KEY", required = false) String suppliedKey,
            @RequestBody SsePocPublishRequest request) {
        keyValidator.validate(suppliedKey);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(eventService.publishToUser(request));
    }
}
