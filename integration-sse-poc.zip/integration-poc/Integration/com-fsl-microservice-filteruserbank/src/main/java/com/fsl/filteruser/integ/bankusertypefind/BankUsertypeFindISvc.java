package com.fsl.filteruser.integ.bankusertypefind;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsl.fwk.cache.model.IMBUserDevicesVO;
import com.fsl.fwk.integration.EAIGWIntegrationResAddOn;
import com.fsl.fwk.integration.EAIGWIntegrationService;
import com.fsl.fwk.integration.FSLEAIGWIntegrationService;
import com.fsl.outbound.filteruser.bankusertypefindpost.BankUsertypeFindIInput;
import com.fsl.outbound.filteruser.bankusertypefindpost.BankUsertypeFindIOutput;
import com.fsl.outbound.filteruser.bankusertypefindpost.UserObject;
import com.tcs.fwk.cache.rtwb.client.ReadThruCacheClient;
import com.tcs.fwk.constants.FwkResponseStatus;
import com.tcs.fwk.db.filter.Simple;
import com.tcs.fwk.exception.BusinessException;
import com.tcs.fwk.integration.IntegrationRequestAddOn;
import com.tcs.fwk.logger.AppLogger;
import com.tcs.fwk.model.BaseModel;
import com.tcs.fwk.model.IMWRequest;
import com.tcs.fwk.model.IMWRequestAddOn;
import com.tcs.fwk.model.ISessionVO;
import com.tcs.fwk.model.MWResponse;
import com.tcs.fwk.service.exception.CustomValidationException;

/**
 * 
 *
 * @author Tata Consultancy Services
 * @author anurag.patil
 * */
 
@Service
public class BankUsertypeFindISvc  extends FSLEAIGWIntegrationService {
	
	@Autowired
	ReadThruCacheClient readThroughCacheClient;
	
	@Override
	public BaseModel customValidations(ISessionVO sessVO, IMWRequest<?> mwRequest, IMWRequestAddOn mwReqAddOn)
			throws CustomValidationException {
		return null;
	}

	
	@Override
	protected IntegrationRequestAddOn<?> prepareEAIGWRequest(ISessionVO sessVO, IMWRequest<?> mwRequest,
			IMWRequestAddOn mwRequestAddOn, BaseModel extraData) throws BusinessException {
		
//		AbstractFilter filter=Simple.of(IMBUserDevicesVO.class)
//		
//		readThroughCacheClient.findIdsByFilter(sessVO, null, null, null)
		
		
		BankUsertypeFindIReqBody bankUsertypeFindIReqBody = (BankUsertypeFindIReqBody) mwRequest.getBody();
		
		BankUsertypeFindIInput bankUsertypeFindIInput = new BankUsertypeFindIInput();
		 
		// CODEGEN: extract fields from reqBody and set to inputData below this line ================
		
		
		
		if (bankUsertypeFindIReqBody != null) {
		bankUsertypeFindIInput.setUserType(bankUsertypeFindIReqBody.getUserType());
		}
		
		
		
		
		
		// CODEGEN: ##### Following fields are not mapped yet #####
		///////////////////////////////////////////////////////////
		//===========================================================================================
		
		IntegrationRequestAddOn<BankUsertypeFindIInput> integReqAddOn = new IntegrationRequestAddOn<BankUsertypeFindIInput>(bankUsertypeFindIInput);
		
		return integReqAddOn;
		
	}
	
	@Override
	protected MWResponse<?> prepareEAIGWMWResponse(ISessionVO sessVO, EAIGWIntegrationResAddOn<?> integResAddOn,
			IMWRequest<?> mwRequest, IMWRequestAddOn mwReqAddOn, IntegrationRequestAddOn<?> integReqAddOn) {
		
		MWResponse<BankUsertypeFindIResBody> mwResponse = null;
		BankUsertypeFindIResBody bankUsertypeFindIResBody = new BankUsertypeFindIResBody();
		
		BankUsertypeFindIInput inputData = (BankUsertypeFindIInput) integReqAddOn.getInputPayload();
		
		BankUsertypeFindIOutput bankUsertypeFindIOutput = (BankUsertypeFindIOutput) integResAddOn.getData();
		// CODEGEN: extract fields from outputData & set to resBody below this line ================
		// ===================================================================================	
		
		AppLogger.info(sessVO, " test:"+bankUsertypeFindIOutput.getUserObject());
		
		BankUsertypeFindIReqBody bankUsertypeFindIReqBody = (BankUsertypeFindIReqBody) mwRequest.getBody();
		String userType = bankUsertypeFindIReqBody.getUserType();
		
		//AppLogger.error(sessVO, JSON.stringify({ name: "Aryannnn" }), null);
		AppLogger.info(sessVO, "({ name: Aryannnn })");
		
		ArrayList<String> res = new ArrayList<>();
		for(UserObject o: bankUsertypeFindIOutput.getUserObject()) {
			if(o.getUserType().equals(userType)) {
				res.add(o.getName());
			}
		
		}
		
		
		bankUsertypeFindIResBody.setUserList(res);
		mwResponse = new MWResponse<BankUsertypeFindIResBody>(sessVO, FwkResponseStatus.SUCCESS, null);
		mwResponse.setBody(bankUsertypeFindIResBody);
		return mwResponse;
		
	}
	
	@Override
	protected Class<? extends BaseModel> myRequestBodyType() {
		return BankUsertypeFindIReqBody.class;
		
	}
	
	@Override
	protected Class<? extends BaseModel> eaiOutputDataType() {
		return BankUsertypeFindIOutput.class;
		
	}
	
}
